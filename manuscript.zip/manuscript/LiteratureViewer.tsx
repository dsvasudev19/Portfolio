import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  Maximize, 
  Minimize, 
  ZoomIn, 
  ZoomOut,
  Download,
  Share,
  Bookmark,
  Highlighter,
  MessageSquare,
  Eye,
  EyeOff
} from "lucide-react";

interface LiteratureViewerProps {
  documentId: string;
}

export function LiteratureViewer({ documentId }: LiteratureViewerProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [isHighlightMode, setIsHighlightMode] = useState(false);
  const [showAnnotations, setShowAnnotations] = useState(true);

  // Mock article content
  const articleTitle = "Marker-assisted breeding for introgression of opaque-2 allele into elite maize inbred line BML-7";
  const authors = "Krishna, Reddy, Satyanarayana";
  const journal = "3 biotech";
  const year = 2017;

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 10, 200));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 10, 50));
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <div className={`${isFullscreen ? 'fixed inset-0 z-50 bg-background' : 'h-full'} flex flex-col`}>
      {/* Reader Toolbar */}
      <div className="border-b p-3 bg-background">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div>
              <h2 className="font-medium text-sm line-clamp-1">{articleTitle}</h2>
              <p className="text-xs text-muted-foreground">
                {authors} • {journal}, {year}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            {/* Reading Controls */}
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsHighlightMode(!isHighlightMode)}
              className={isHighlightMode ? 'bg-yellow-100 text-yellow-800' : ''}
            >
              <Highlighter className="h-4 w-4" />
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setShowAnnotations(!showAnnotations)}
            >
              {showAnnotations ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
            </Button>
            
            <div className="w-px h-6 bg-border mx-1" />
            
            {/* Zoom Controls */}
            <Button variant="ghost" size="sm" onClick={handleZoomOut}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <span className="text-xs px-2 py-1 bg-muted rounded">
              {zoomLevel}%
            </span>
            <Button variant="ghost" size="sm" onClick={handleZoomIn}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            
            <div className="w-px h-6 bg-border mx-1" />
            
            {/* Action Buttons */}
            <Button variant="ghost" size="sm">
              <Bookmark className="h-4 w-4" />
            </Button>
            
            
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4" />
            </Button>
            
            <Button variant="ghost" size="sm">
              <Share className="h-4 w-4" />
            </Button>
            
            <Button variant="ghost" size="sm" onClick={toggleFullscreen}>
              {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Article Content */}
      <div className="flex-1 overflow-auto bg-white">
        <div 
          className="max-w-4xl mx-auto p-8"
          style={{ fontSize: `${zoomLevel}%` }}
        >
          {/* Article Header */}
          <div className="mb-8 pb-6 border-b">
            <h1 className="text-2xl font-bold mb-4">{articleTitle}</h1>
            <div className="text-muted-foreground mb-2">
              <p className="font-medium">{authors}</p>
              <p className="text-sm">{journal} • {year}</p>
            </div>
          </div>

          {/* Article Content */}
          <div className="prose prose-lg max-w-none">
            <h2>Abstract</h2>
            <p>
              Protein quality of maize is low due to deficiency of lysine and tryptophan amino acids. 
              The opaque-2 (o2) mutant contains almost double the amount of lysine and tryptophan than 
              normal maize, but has undesirable phenotype with soft, chalky kernel. Several modifier 
              genes have been identified that restore the hard kernel phenotype while retaining the 
              enhanced protein quality. The present study was undertaken to introgress the o2 allele 
              into elite maize inbred line BML-7 through marker-assisted breeding.
            </p>
            
            <h2>Introduction</h2>
            <p>
              Maize (Zea mays L.) is the third most important cereal crop after wheat and rice and 
              constitutes the staple food for more than 1.2 billion people in Sub-Saharan Africa and 
              Latin America. However, the protein quality of normal maize is low due to deficiency 
              of essential amino acids, lysine and tryptophan, which are required for human nutrition.
            </p>
            
            <h2>Materials and Methods</h2>
            <p>
              The opaque-2 donor parent (o2o2) was crossed with the elite maize inbred line BML-7 
              (O2O2) during Rabi 2012. The F1 plants were self-pollinated to generate F2 population. 
              A total of 184 F2 plants were grown during Kharif 2013 and used for marker-assisted 
              selection of o2 allele.
            </p>
            
            {showAnnotations && (
              <div className="mt-8 p-4 bg-yellow-50 border-l-4 border-yellow-400">
                <h4 className="font-medium text-yellow-800 mb-2">Your Highlight</h4>
                <p className="text-sm text-yellow-700">
                  "The opaque-2 (o2) mutant contains almost double the amount of lysine and tryptophan than normal maize"
                </p>
                <p className="text-xs text-yellow-600 mt-1">
                  Note: Important nutritional improvement mechanism
                </p>
              </div>
            )}
            
            <h2>Results</h2>
            <p>
              Molecular marker analysis revealed that 45 out of 184 F2 plants (24.45%) were 
              homozygous for the o2 allele. These plants were advanced to F3 generation. 
              The F3 families showed segregation for kernel modification genes, and families 
              with hard kernel phenotype were selected.
            </p>
            
            <h2>Discussion</h2>
            <p>
              The successful introgression of the o2 allele into BML-7 demonstrates the 
              effectiveness of marker-assisted selection in quality protein maize breeding. 
              The use of molecular markers significantly reduced the time and resources 
              required for developing improved varieties.
            </p>
            
            <h2>Conclusion</h2>
            <p>
              Marker-assisted breeding proved to be an efficient approach for introgressing 
              the opaque-2 allele into elite maize germplasm. The developed lines with 
              enhanced protein quality can contribute to addressing malnutrition in 
              developing countries.
            </p>
          </div>
        </div>
      </div>

      {/* Reading Progress */}
      <div className="border-t p-2 bg-background">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Page 1 of 8</span>
          <div className="flex items-center gap-2">
            <div className="w-32 bg-muted rounded-full h-1">
              <div className="w-1/8 bg-primary rounded-full h-1"></div>
            </div>
            <span>12% read</span>
          </div>
        </div>
      </div>
    </div>
  );
}