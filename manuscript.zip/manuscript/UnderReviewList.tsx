import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  MoreVertical,
  Clock,
  AlertCircle,
  CheckCircle,
  Eye
} from "lucide-react";
import { ManuscriptUnderReviewModal } from "./ManuscriptUnderReviewModal";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ReviewDocument {
  id: string;
  title: string;
  journal: string;
  submittedDate: string;
  status: 'submitted' | 'under_review' | 'revision_required' | 'accepted' | 'rejected';
  reviewers: number;
  type: 'Research article' | 'Review' | 'Case report';
}

interface UnderReviewListProps {
  selectedDocument: string | null;
  onSelectDocument: (id: string) => void;
  onViewDocument?: (document: ReviewDocument) => void;
}

const mockReviewDocuments: ReviewDocument[] = [
  {
    id: 'r1',
    title: 'Gut Microbiota and Mental Health: A Comprehensive Review',
    journal: 'Nature Neuroscience',
    submittedDate: '15 May 2024',
    status: 'under_review',
    reviewers: 3,
    type: 'Research article'
  },
  {
    id: 'r2',
    title: 'Social Media Impact on Adolescent Psychology',
    journal: 'Journal of Digital Health',
    submittedDate: '3 May 2024',
    status: 'revision_required',
    reviewers: 2,
    type: 'Review'
  },
  {
    id: 'r3',
    title: 'Case Study: Treatment-Resistant Depression',
    journal: 'Clinical Psychology Review',
    submittedDate: '28 April 2024',
    status: 'accepted',
    reviewers: 2,
    type: 'Case report'
  }
];

export function UnderReviewList({ selectedDocument, onSelectDocument, onViewDocument }: UnderReviewListProps) {
  const [documents] = useState<ReviewDocument[]>(mockReviewDocuments);
  const [viewingDocument, setViewingDocument] = useState<ReviewDocument | null>(null);

  const getStatusColor = (status: ReviewDocument['status']) => {
    switch (status) {
      case 'submitted':
        return 'bg-blue-100 text-blue-800';
      case 'under_review':
        return 'bg-yellow-100 text-yellow-800';
      case 'revision_required':
        return 'bg-orange-100 text-orange-800';
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: ReviewDocument['status']) => {
    switch (status) {
      case 'submitted':
      case 'under_review':
        return <Clock className="h-4 w-4" />;
      case 'revision_required':
        return <AlertCircle className="h-4 w-4" />;
      case 'accepted':
        return <CheckCircle className="h-4 w-4" />;
      case 'rejected':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusText = (status: ReviewDocument['status']) => {
    switch (status) {
      case 'submitted':
        return 'Submitted';
      case 'under_review':
        return 'Under Review';
      case 'revision_required':
        return 'Revision Required';
      case 'accepted':
        return 'Accepted';
      case 'rejected':
        return 'Rejected';
      default:
        return status;
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 space-y-3">
        {documents.map((doc) => (
          <div 
            key={doc.id}
            className={`p-3 rounded-lg border cursor-pointer transition-colors ${
              selectedDocument === doc.id 
                ? 'bg-primary/10 border-primary' 
                : 'hover:bg-muted/50'
            }`}
            onClick={() => onViewDocument?.(doc)}
          >
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-medium text-sm line-clamp-2 flex-1 mr-2">
                {doc.title}
              </h3>
              <DropdownMenu>
                <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                    <MoreVertical className="h-3 w-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onViewDocument?.(doc)}>
                    <Eye className="h-4 w-4 mr-2" />
                    View with Comments
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setViewingDocument(doc)}>
                    View Details
                  </DropdownMenuItem>
                  <DropdownMenuItem>Contact Editor</DropdownMenuItem>
                  <DropdownMenuItem className="text-destructive">Withdraw</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className={`text-xs ${getStatusColor(doc.status)} flex items-center gap-1`}>
                  {getStatusIcon(doc.status)}
                  {getStatusText(doc.status)}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {doc.type}
                </Badge>
              </div>
              
              <div className="text-xs text-muted-foreground space-y-1">
                <div className="font-medium">{doc.journal}</div>
                <div className="flex items-center justify-between">
                  <span>Submitted: {doc.submittedDate}</span>
                  <span>{doc.reviewers} reviewer(s)</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <ManuscriptUnderReviewModal 
        open={!!viewingDocument}
        onOpenChange={(open) => !open && setViewingDocument(null)}
        document={viewingDocument}
      />
    </div>
  );
}