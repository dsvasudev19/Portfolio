import { useState } from "react";
import { ManuscriptSidebar } from "./ManuscriptSidebar";
import { EnhancedDocumentEditor } from "./EnhancedDocumentEditor";
import { UnderReviewViewer } from "./UnderReviewViewer";
import { useSidebar } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface ReviewDocument {
  id: string;
  title: string;
  journal: string;
  submittedDate: string;
  status: 'submitted' | 'under_review' | 'revision_required' | 'accepted' | 'rejected';
  reviewers: number;
  type: 'Research article' | 'Review' | 'Case report';
}

interface UnderReviewDocument {
  id: string;
  title: string;
  journal: string;
  type: string;
  content: string;
  comments: any[];
  reviewStatus: 'in-progress' | 'completed' | 'revision-required';
  liveCommentsEnabled: boolean;
  concurrentReviewers: number;
}

export function WriteManuscriptDashboard() {
  const [selectedDocument, setSelectedDocument] = useState<string | null>(null);
  const [isMinimized, setIsMinimized] = useState(false);
  const [documentType, setDocumentType] = useState<'manuscript' | 'literature' | 'review'>('manuscript');
  const [viewingUnderReview, setViewingUnderReview] = useState<UnderReviewDocument | null>(null);
  const { state } = useSidebar(); // Get main sidebar state

  const handleUpgrade = () => {
    // Navigate to upgrade page
    window.location.href = '/upgrade';
  };

  const handleStarDocument = (docId: string) => {
    console.log('Document starred:', docId);
  };

  const handleViewUnderReview = (document: ReviewDocument) => {
    // Convert ReviewDocument to UnderReviewDocument
    const underReviewDoc: UnderReviewDocument = {
      id: document.id,
      title: document.title,
      journal: document.journal,
      type: document.type,
      content: "", // Will be filled in the component
      comments: [],
      reviewStatus: document.status === 'under_review' ? 'in-progress' : 
                   document.status === 'revision_required' ? 'revision-required' : 'completed',
      liveCommentsEnabled: false,
      concurrentReviewers: document.reviewers
    };
    setViewingUnderReview(underReviewDoc);
  };

  if (viewingUnderReview) {
    return (
      <UnderReviewViewer 
        document={viewingUnderReview}
        onBack={() => setViewingUnderReview(null)}
      />
    );
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      {/* Header with Review Dashboard Link */}
      <div className="flex-shrink-0 border-b bg-background px-4 py-2">
        <div className="flex items-center justify-end">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => window.location.href = '/review-dashboard'}
            className="gap-2"
          >
            <ExternalLink className="w-4 h-4" />
            Review Dashboard
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <ManuscriptSidebar 
          selectedDocument={selectedDocument}
          onSelectDocument={(id) => {
            setSelectedDocument(id);
            // Determine document type based on context
            setDocumentType('manuscript');
          }}
          isMinimized={isMinimized}
          onToggleMinimize={() => setIsMinimized(!isMinimized)}
          onStarDocument={handleStarDocument}
          onViewUnderReview={handleViewUnderReview}
        />
        
        <div className={`flex-1 flex flex-col overflow-hidden transition-all duration-300 ${
          state === 'collapsed' ? 'ml-14' : 'ml-0'
        } ${isMinimized ? 'pl-16' : 'pl-0'}`}>
          <EnhancedDocumentEditor 
            documentId={selectedDocument}
            documentType={documentType}
            onUpgrade={handleUpgrade}
          />
        </div>
      </div>
    </div>
  );
}