import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter,
  ChevronDown,
  ChevronUp,
  MoreVertical
} from "lucide-react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface Highlight {
  id: string;
  text: string;
  color: 'yellow' | 'green' | 'blue' | 'purple' | 'red';
  note?: string;
  page?: number;
  expanded?: boolean;
}

interface HighlightsPanelProps {
  isVisible: boolean;
  onHighlightSelect?: (highlight: Highlight) => void;
}

const mockHighlights: Highlight[] = [
  {
    id: '1',
    text: 'The intricate relationship between the gut microbiome and mental health has garnered significant attention in recent years. Emerging evidence suggests that the gut microbiome...',
    color: 'yellow',
    note: 'Important finding about gut-brain connection',
    page: 1,
    expanded: false
  },
  {
    id: '2',
    text: 'Imbalances in the gut microbiome, known as dysbiosis, have been linked to a range of mental health disorders, such as anxiety, depression, and schizophrenia...',
    color: 'blue',
    note: 'Key definition and connection to mental health',
    page: 1,
    expanded: false
  },
  {
    id: '3',
    text: 'The intricate relationship between the gut microbiome and mental health has garnered significant attention in recent years. Emerging evidence suggests that the gut micro...',
    color: 'green',
    page: 2,
    expanded: false
  }
];

const colorMap = {
  yellow: 'bg-yellow-100 border-yellow-300',
  green: 'bg-green-100 border-green-300',
  blue: 'bg-blue-100 border-blue-300',
  purple: 'bg-purple-100 border-purple-300',
  red: 'bg-red-100 border-red-300'
};

const colorDots = {
  yellow: 'bg-yellow-400',
  green: 'bg-green-400',
  blue: 'bg-blue-400',
  purple: 'bg-purple-400',
  red: 'bg-red-400'
};

export function HighlightsPanel({ isVisible, onHighlightSelect }: HighlightsPanelProps) {
  const [highlights, setHighlights] = useState<Highlight[]>(mockHighlights);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedColors, setSelectedColors] = useState<string[]>([]);

  const filteredHighlights = highlights.filter(highlight => {
    const matchesSearch = highlight.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (highlight.note && highlight.note.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesColor = selectedColors.length === 0 || selectedColors.includes(highlight.color);
    return matchesSearch && matchesColor;
  });

  const toggleExpanded = (id: string) => {
    setHighlights(highlights.map(h => 
      h.id === id ? { ...h, expanded: !h.expanded } : h
    ));
  };

  const toggleColorFilter = (color: string) => {
    setSelectedColors(prev => 
      prev.includes(color) 
        ? prev.filter(c => c !== color)
        : [...prev, color]
    );
  };

  if (!isVisible) return null;

  return (
    <div className="w-72 border-l bg-background flex flex-col h-full">
      {/* Header */}
      <div className="p-3 border-b space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-medium">Highlights</h3>
          <Button variant="ghost" size="sm">
            <MoreVertical className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search highlights..." 
            className="pl-10 text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Color Filters */}
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <div className="flex gap-1">
            {Object.entries(colorDots).map(([color, className]) => (
              <button
                key={color}
                onClick={() => toggleColorFilter(color)}
                className={`w-6 h-6 rounded-full border-2 ${className} ${
                  selectedColors.includes(color) 
                    ? 'border-gray-800' 
                    : 'border-gray-300'
                } hover:border-gray-600 transition-colors`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Highlights List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {filteredHighlights.map((highlight) => (
          <Collapsible key={highlight.id}>
            <div 
              className={`relative p-3 rounded-lg border ${highlight.expanded ? 'h-auto' : 'h-28'} ${colorMap[highlight.color]} flex flex-col cursor-pointer hover:shadow-sm transition-shadow`}
              onClick={() => onHighlightSelect?.(highlight)}
            >
              <div className="flex items-start gap-2 flex-1">
                <div className={`w-2.5 h-2.5 rounded-full ${colorDots[highlight.color]} mt-1 flex-shrink-0`} />
                <div className="flex-1 overflow-hidden">
                  <p className="text-xs leading-relaxed mb-1">
                    {highlight.expanded ? highlight.text : `${highlight.text.substring(0, 70)}...`}
                  </p>
                  {highlight.note && (
                    <p className="text-xs text-muted-foreground italic">
                      {highlight.note}
                    </p>
                  )}
                  {highlight.page && (
                    <p className="text-xs text-muted-foreground">
                      Page {highlight.page}
                    </p>
                  )}
                </div>
              </div>
              
              <CollapsibleTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="absolute bottom-1 right-1 h-5 w-12 text-xs hover:bg-white/20 hover:text-foreground"
                  onClick={() => toggleExpanded(highlight.id)}
                >
                  {highlight.expanded ? (
                    <>Less <ChevronUp className="h-3 w-3 ml-1" /></>
                  ) : (
                    <>More <ChevronDown className="h-3 w-3 ml-1" /></>
                  )}
                </Button>
              </CollapsibleTrigger>
            </div>
          </Collapsible>
        ))}
      </div>
    </div>
  );
}