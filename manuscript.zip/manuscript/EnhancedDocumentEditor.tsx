import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Undo, 
  Redo,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignJustify,
  List,
  ListOrdered,
  Link,
  Image,
  Table,
  MoreHorizontal,
  Star,
  Download,
  FileText,
  Send,
  Bot,
  BotOff,
  Users,
  HelpCircle,
  Settings,
  Maximize,
  Eye
} from "lucide-react";
import { HighlightsPanel } from "./HighlightsPanel";
import { CoAuthorDialog } from "./CoAuthorDialog";
import { SubmitManuscriptDialog } from "./SubmitManuscriptDialog";
import { HelpDialog } from "./HelpDialog";
import { UpgradeDialog } from "./UpgradeDialog";
import { LiteratureViewer } from "./LiteratureViewer";
import { LimitBars } from "./LimitBars";

interface EditorProps {
  documentId?: string | null;
  documentType?: 'manuscript' | 'literature' | 'review';
  onUpgrade: () => void;
}

interface CoAuthor {
  id: string;
  name: string;
  email: string;
  avatar: string;
  status: 'active' | 'invited';
}

export function EnhancedDocumentEditor({ documentId, documentType = 'manuscript', onUpgrade }: EditorProps) {
  const [title, setTitle] = useState("Gut Microbiota for Mental Health");
  const [content, setContent] = useState(`
    <p>The intricate relationship between the gut microbiome and mental health has garnered significant attention in recent years. Emerging evidence suggests that the gut microbiome, which is consisting of trillions of microorganisms, plays a crucial role in regulating various physiological processes, including digestion, immune function, and even neurological development (Xiong et al., 2023)(Ding et al., 2020)(Fang et al., 2018).</p>
    
    <p>Imbalances in the gut microbiome, known as dysbiosis, have been linked to a range of mental health disorders, such as anxiety, depression, and schizophrenia (Xiong et al., 2023).</p>
    
    <p>Studies have shown that individuals with schizophrenia often exhibit distinct gut microbial profiles, characterized by reduced abundances of beneficial bacteria, such as Ruminococcus and Roseburia, and increased abun.</p>
    
    <p>As a result, there is growing interest in exploring the potential of modulating the gut microbiome as a therapeutic approach for mental health conditions (Green et al., 2023)(Céntí et al., 2017)(Janbrink-Sehgal & Andreasson, 2020)(Capuco et al., 2020)</p>
  `);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [referenceFormat, setReferenceFormat] = useState("APA");
  const [documentTitleInternal, setDocumentTitleInternal] = useState("Gut Microbiota for Mental Health");
  const [isStarred, setIsStarred] = useState(false);
  
  const editorRef = useRef<HTMLDivElement>(null);
  const [wordCount, setWordCount] = useState(0);
  const [showHighlights, setShowHighlights] = useState(true);
  const [showCoAuthorDialog, setShowCoAuthorDialog] = useState(false);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [showHelpDialog, setShowHelpDialog] = useState(false);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [aiWritingEnabled, setAiWritingEnabled] = useState(false);
  const [isAutoSaving, setIsAutoSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date>(new Date());

  // Mock co-authors
  const [coAuthors] = useState<CoAuthor[]>([
    { id: '1', name: 'Dr. Jane Smith', email: 'jane@university.edu', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b332c47c?w=400&h=400&fit=crop&crop=face', status: 'active' },
    { id: '2', name: 'Prof. John Doe', email: 'john@research.org', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face', status: 'invited' }
  ]);

  // Calculate word count
  useEffect(() => {
    if (editorRef.current) {
      const text = editorRef.current.innerText || '';
      const words = text.trim().split(/\s+/).filter(word => word.length > 0);
      setWordCount(words.length);
    }
  }, [content]);

  // Auto-save functionality
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      if (content && documentId) {
        setIsAutoSaving(true);
        // Simulate auto-save
        setTimeout(() => {
          setIsAutoSaving(false);
          setLastSaved(new Date());
        }, 1000);
      }
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval);
  }, [content, documentId]);

  const executeCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      setContent(editorRef.current.innerHTML);
    }
  };

  const handleInput = () => {
    if (editorRef.current) {
      setContent(editorRef.current.innerHTML);
    }
  };

  const handleSubmit = () => {
    setShowSubmitDialog(true);
  };

  const handleStar = () => {
    setIsStarred(!isStarred);
  };

  const togglePreview = () => {
    setIsPreviewMode(!isPreviewMode);
  };

  if (!documentId) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>Select a document to start writing</p>
        </div>
      </div>
    );
  }

  // Show literature viewer for literature type
  if (documentType === 'literature') {
    return <LiteratureViewer documentId={documentId} />;
  }

  if (isPreviewMode) {
    return (
      <div className="h-full flex flex-col overflow-hidden">
        {/* Preview Header */}
        <div className="border-b p-4 flex items-center justify-between">
          <h2 className="text-lg font-medium">Preview Mode</h2>
          <Button variant="outline" onClick={togglePreview}>
            Exit Preview
          </Button>
        </div>
        
        {/* Preview Content */}
        <div className="flex-1 overflow-auto bg-white">
          <div className="max-w-4xl mx-auto p-8">
            <div className="mb-6">
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 mb-2">
                {documentType === 'review' ? 'Under Review' : 'Research article'}
              </Badge>
              <h1 className="text-3xl font-bold mb-4">{documentTitleInternal}</h1>
              <div className="text-muted-foreground mb-4">
                {coAuthors.map((author, index) => (
                  <span key={author.id}>
                    {author.name}
                    {index < coAuthors.length - 1 ? ', ' : ''}
                  </span>
                ))}
              </div>
            </div>
            <div 
              className="prose prose-lg max-w-none"
              dangerouslySetInnerHTML={{ __html: content }}
            />
            
            {/* References Section */}
            <div className="mt-12 border-t pt-6">
              <h2 className="text-xl font-semibold mb-4">References</h2>
              <div className="space-y-2 text-sm">
                <p>Xiong, R., et al. (2023). Gut microbiome and mental health: A systematic review. <em>Nature Neuroscience</em>, 45(2), 123-135.</p>
                <p>Ding, L., et al. (2020). Microbiome-gut-brain axis in neurological disorders. <em>Cell</em>, 182(4), 891-906.</p>
                <p>Fang, M., et al. (2018). Bacterial diversity in the human gut microbiome. <em>Science</em>, 361(6401), 456-462.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex overflow-hidden">
      {/* Main Editor */}
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
        {/* Header */}
        <div className="border-b p-4 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-lg font-medium">Write Manuscript</span>
            </div>
            
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setAiWritingEnabled(!aiWritingEnabled)}
                className={aiWritingEnabled ? 'bg-primary/10 text-primary' : ''}
              >
                {aiWritingEnabled ? <Bot className="h-4 w-4" /> : <BotOff className="h-4 w-4" />}
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleStar}
                className={isStarred ? 'text-yellow-500' : ''}
              >
                <Star className={`h-4 w-4 ${isStarred ? 'fill-yellow-400' : ''}`} />
              </Button>
              
              <Button variant="ghost" size="sm">
                <Download className="h-4 w-4" />
              </Button>

              <Button 
                variant="ghost" 
                size="sm"
                onClick={togglePreview}
              >
                Preview
              </Button>

              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowUpgradeDialog(true)}
                className="text-primary hover:text-primary"
              >
                Upgrade
              </Button>

              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowHelpDialog(true)}
              >
                <HelpCircle className="h-4 w-4" />
              </Button>

              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowHighlights(!showHighlights)}
              >
                <Eye className="h-4 w-4" />
              </Button>
              
              <Button size="sm" className="gap-2" onClick={handleSubmit}>
                <Send className="h-4 w-4" />
                Submit
              </Button>
            </div>
          </div>


          {/* Toolbar */}
          <div className="flex items-center gap-1 flex-wrap mt-4">
            {/* Undo/Redo */}
            <Button variant="ghost" size="sm" onClick={() => executeCommand('undo')}>
              <Undo className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => executeCommand('redo')}>
              <Redo className="h-4 w-4" />
            </Button>
            
            <div className="w-px h-6 bg-border mx-2" />

            {/* Text Style */}
            <Select defaultValue="normal">
              <SelectTrigger className="w-[120px] h-8">
                <SelectValue placeholder="Normal text" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="normal">Normal text</SelectItem>
                <SelectItem value="heading1">Heading 1</SelectItem>
                <SelectItem value="heading2">Heading 2</SelectItem>
                <SelectItem value="heading3">Heading 3</SelectItem>
              </SelectContent>
            </Select>

            <div className="w-px h-6 bg-border mx-2" />

            {/* Formatting */}
            <Button variant="ghost" size="sm" onClick={() => executeCommand('bold')}>
              <Bold className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => executeCommand('italic')}>
              <Italic className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => executeCommand('underline')}>
              <Underline className="h-4 w-4" />
            </Button>

            <div className="w-px h-6 bg-border mx-2" />

            {/* Alignment */}
            <Button variant="ghost" size="sm" onClick={() => executeCommand('justifyLeft')}>
              <AlignLeft className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => executeCommand('justifyCenter')}>
              <AlignCenter className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => executeCommand('justifyFull')}>
              <AlignJustify className="h-4 w-4" />
            </Button>

            <div className="w-px h-6 bg-border mx-2" />

            {/* Lists */}
            <Button variant="ghost" size="sm" onClick={() => executeCommand('insertUnorderedList')}>
              <List className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => executeCommand('insertOrderedList')}>
              <ListOrdered className="h-4 w-4" />
            </Button>

            <div className="w-px h-6 bg-border mx-2" />

            {/* Insert */}
            <Button variant="ghost" size="sm">
              <Link className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Image className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Table className="h-4 w-4" />
            </Button>
            
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Editor */}
        <div className="flex-1 overflow-y-auto min-h-0">
          <div className="max-w-4xl mx-auto p-8 w-full">
            {/* Document Type Label and Title */}
            <div className="mb-6">
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 mb-2">
                {documentType === 'review' ? 'Under Review' : 'Research article'}
              </Badge>
              <Input
                type="text"
                value={documentTitleInternal}
                onChange={(e) => setDocumentTitleInternal(e.target.value)}
                className="text-3xl font-bold border-none shadow-none p-0 h-auto mb-4 focus-visible:ring-0"
                placeholder="Enter manuscript title..."
              />
              
              {/* Co-authors */}
              <div className="flex items-center gap-2 mb-4">
                <span className="text-sm text-muted-foreground">Authors:</span>
                {coAuthors.map((author, index) => (
                  <div key={author.id} className="flex items-center gap-1">
                    <img 
                      src={author.avatar} 
                      alt={author.name}
                      className="w-6 h-6 rounded-full object-cover border"
                    />
                    <span className="text-sm">{author.name}</span>
                    {index < coAuthors.length - 1 && <span className="text-muted-foreground">,</span>}
                  </div>
                ))}
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowCoAuthorDialog(true)}
                  className="h-6 ml-2"
                >
                  <Users className="h-3 w-3" />
                </Button>
              </div>
            </div>

            <div
              ref={editorRef}
              contentEditable
              suppressContentEditableWarning
              onInput={handleInput}
              dangerouslySetInnerHTML={{ __html: content }}
              className="min-h-[300px] prose prose-lg max-w-none focus:outline-none"
              style={{
                lineHeight: '1.6',
                fontSize: '16px',
                fontFamily: 'ui-serif, Georgia, Cambria, "Times New Roman", Times, serif'
              }}
            />
            
            {/* References Section */}
            <div className="mt-12 border-t pt-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">References</h2>
                <Select value={referenceFormat} onValueChange={setReferenceFormat}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue placeholder="Format" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="APA">APA</SelectItem>
                    <SelectItem value="MLA">MLA</SelectItem>
                    <SelectItem value="Harvard">Harvard</SelectItem>
                    <SelectItem value="RIS">RIS</SelectItem>
                    <SelectItem value="BibTeX">BibTeX</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 text-sm bg-muted/20 p-4 rounded-lg">
                <p>Xiong, R., et al. (2023). Gut microbiome and mental health: A systematic review. <em>Nature Neuroscience</em>, 45(2), 123-135.</p>
                <p>Ding, L., et al. (2020). Microbiome-gut-brain axis in neurological disorders. <em>Cell</em>, 182(4), 891-906.</p>
                <p>Fang, M., et al. (2018). Bacterial diversity in the human gut microbiome. <em>Science</em>, 361(6401), 456-462.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Status Bar */}
        <div className="border-t p-2 flex-shrink-0">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-4">
              <span>{wordCount} words</span>
              {isAutoSaving ? (
                <span className="text-blue-600">Auto-saving...</span>
              ) : (
                <span>Last saved: {lastSaved.toLocaleTimeString()}</span>
              )}
            </div>
            <div className="flex items-center justify-center flex-1">
              <LimitBars />
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Highlights */}
      <HighlightsPanel isVisible={showHighlights} />

      {/* Dialogs */}
      <CoAuthorDialog 
        open={showCoAuthorDialog}
        onOpenChange={setShowCoAuthorDialog}
        coAuthors={coAuthors}
      />
      
      <SubmitManuscriptDialog 
        open={showSubmitDialog}
        onOpenChange={setShowSubmitDialog}
      />
      
      <HelpDialog 
        open={showHelpDialog}
        onOpenChange={setShowHelpDialog}
      />

      <UpgradeDialog 
        open={showUpgradeDialog}
        onOpenChange={setShowUpgradeDialog}
        onUpgrade={onUpgrade}
      />
    </div>
  );
}