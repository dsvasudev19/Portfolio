import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Send, ArrowRight, FileText } from "lucide-react";

interface SubmitManuscriptDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SubmitManuscriptDialog({ open, onOpenChange }: SubmitManuscriptDialogProps) {
  const handleConfirmSubmit = () => {
    // Handle manuscript submission
    onOpenChange(false);
    // Navigate to submission section
    window.location.href = '/submit-manuscript';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="h-5 w-5" />
            Submit Manuscript
          </DialogTitle>
          <DialogDescription>
            You're about to leave the writing interface and proceed to the manuscript submission process.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="flex items-center gap-3 p-4 border rounded-lg bg-muted/50">
            <FileText className="h-8 w-8 text-primary" />
            <div>
              <h4 className="font-medium">Ready to Submit?</h4>
              <p className="text-sm text-muted-foreground">
                Your manuscript will be prepared for journal submission with all formatting and references.
              </p>
            </div>
          </div>
          
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>What happens next:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Review and finalize your manuscript</li>
              <li>Select target journals</li>
              <li>Complete submission requirements</li>
              <li>Submit to your chosen journal</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Continue Writing
          </Button>
          <Button onClick={handleConfirmSubmit} className="gap-2">
            Proceed to Submit
            <ArrowRight className="h-4 w-4" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}