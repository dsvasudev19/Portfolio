import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Plus, 
  FileText, 
  MoreVertical,
  Folder,
  Calendar
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Document {
  id: string;
  title: string;
  type: 'Research article' | 'Thesis' | 'Report' | 'Proposal';
  lastModified: string;
  wordCount?: number;
}

interface DocumentListProps {
  selectedDocument: string | null;
  onSelectDocument: (id: string) => void;
}

const mockDocuments: Document[] = [
  {
    id: '1',
    title: 'Gut Microbiota for Mental Health',
    type: 'Research article',
    lastModified: '12 June',
    wordCount: 2847
  },
  {
    id: '2',
    title: 'Psychological Impact of Social Media',
    type: 'Research article',
    lastModified: '8 June',
    wordCount: 1523
  },
  {
    id: '3',
    title: 'Research Proposal Draft',
    type: 'Proposal',
    lastModified: '3 June',
    wordCount: 890
  }
];

export function DocumentList({ selectedDocument, onSelectDocument }: DocumentListProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [documents] = useState<Document[]>(mockDocuments);

  const filteredDocuments = documents.filter(doc =>
    doc.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getTypeColor = (type: Document['type']) => {
    switch (type) {
      case 'Research article':
        return 'bg-blue-100 text-blue-800';
      case 'Thesis':
        return 'bg-purple-100 text-purple-800';
      case 'Report':
        return 'bg-green-100 text-green-800';
      case 'Proposal':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-4">
          <Button className="gap-2" size="sm">
            <Plus className="h-4 w-4" />
            New
          </Button>
          <Button variant="ghost" size="sm">
            <MoreVertical className="h-4 w-4" />
          </Button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search docs" 
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Folders Section */}
      <div className="p-4 border-b">
        <div className="space-y-2">
          <div className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted/50 cursor-pointer">
            <Folder className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">Documents</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted/50 cursor-pointer">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">My literature</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted/50 cursor-pointer">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">Under review</span>
          </div>
        </div>
      </div>

      {/* Documents List */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-3">
          {filteredDocuments.map((doc) => (
            <div 
              key={doc.id}
              className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                selectedDocument === doc.id 
                  ? 'bg-primary/10 border-primary' 
                  : 'hover:bg-muted/50'
              }`}
              onClick={() => onSelectDocument(doc.id)}
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-medium text-sm line-clamp-2">{doc.title}</h3>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                      <MoreVertical className="h-3 w-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>Rename</DropdownMenuItem>
                    <DropdownMenuItem>Duplicate</DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              
              <Badge variant="secondary" className={`text-xs ${getTypeColor(doc.type)}`}>
                {doc.type}
              </Badge>
              
              <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                <span>{doc.lastModified}</span>
                {doc.wordCount && <span>{doc.wordCount.toLocaleString()} words</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}