import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MessageSquare, 
  PlayCircle, 
  BookOpen,
  Send,
  ExternalLink
} from "lucide-react";

interface HelpDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function HelpDialog({ open, onOpenChange }: HelpDialogProps) {
  const [message, setMessage] = useState("");
  const [email, setEmail] = useState("");

  const handleSendMessage = () => {
    // Handle message sending
    console.log('Sending message:', { email, message });
    setMessage("");
    setEmail("");
    onOpenChange(false);
  };

  const tutorials = [
    {
      title: "Getting Started with Manuscript Writing",
      duration: "5 min",
      description: "Learn the basics of creating and formatting your manuscript"
    },
    {
      title: "Collaborating with Co-Authors",
      duration: "3 min",
      description: "How to invite and work with collaborators in real-time"
    },
    {
      title: "Managing References and Citations",
      duration: "7 min",
      description: "Add, format, and manage citations in your document"
    },
    {
      title: "Using AI Writing Assistant",
      duration: "4 min",
      description: "Leverage AI to improve your writing and research"
    }
  ];

  const documentationLinks = [
    {
      title: "Manuscript Writing Guide",
      description: "Comprehensive guide to academic writing",
      url: "#"
    },
    {
      title: "Formatting Requirements",
      description: "Journal-specific formatting guidelines",
      url: "#"
    },
    {
      title: "Collaboration Features",
      description: "Working with co-authors and reviewers",
      url: "#"
    },
    {
      title: "Submission Process",
      description: "How to submit your manuscript to journals",
      url: "#"
    }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Help & Support</DialogTitle>
          <DialogDescription>
            Get help with manuscript writing and platform features.
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="message" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="message" className="gap-1">
              <MessageSquare className="h-4 w-4" />
              Message
            </TabsTrigger>
            <TabsTrigger value="tutorials" className="gap-1">
              <PlayCircle className="h-4 w-4" />
              Tutorials
            </TabsTrigger>
            <TabsTrigger value="docs" className="gap-1">
              <BookOpen className="h-4 w-4" />
              Documentation
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="message" className="space-y-4">
            <div className="space-y-3">
              <div>
                <Label htmlFor="help-email">Your Email</Label>
                <Input
                  id="help-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@university.edu"
                />
              </div>
              
              <div>
                <Label htmlFor="help-message">Message</Label>
                <Textarea
                  id="help-message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe your question or issue..."
                  rows={6}
                />
              </div>
              
              <Button onClick={handleSendMessage} className="w-full gap-2">
                <Send className="h-4 w-4" />
                Send Message
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="tutorials" className="space-y-3">
            {tutorials.map((tutorial, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50">
                <div className="flex items-center gap-3">
                  <PlayCircle className="h-8 w-8 text-primary" />
                  <div>
                    <h4 className="font-medium text-sm">{tutorial.title}</h4>
                    <p className="text-xs text-muted-foreground">{tutorial.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">{tutorial.duration}</p>
                  <Button size="sm" variant="outline">Watch</Button>
                </div>
              </div>
            ))}
          </TabsContent>
          
          <TabsContent value="docs" className="space-y-3">
            {documentationLinks.map((doc, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50">
                <div className="flex items-center gap-3">
                  <BookOpen className="h-8 w-8 text-primary" />
                  <div>
                    <h4 className="font-medium text-sm">{doc.title}</h4>
                    <p className="text-xs text-muted-foreground">{doc.description}</p>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="gap-1">
                  Open
                  <ExternalLink className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}