import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Undo, 
  Redo,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignJustify,
  List,
  ListOrdered,
  Link,
  Image,
  Table,
  MoreHorizontal,
  Share,
  Star,
  Download,
  FileText
} from "lucide-react";

interface DocumentEditorProps {
  documentId?: string | null;
}

export function DocumentEditor({ documentId }: DocumentEditorProps) {
  const [title, setTitle] = useState("Gut Microbiota for Mental Health");
  const [content, setContent] = useState(`
    <p>The intricate relationship between the gut microbiome and mental health has garnered significant attention in recent years. Emerging evidence suggests that the gut microbiome, which is consisting of trillions of microorganisms, plays a crucial role in regulating various physiological processes, including digestion, immune function, and even neurological development (Xiong et al., 2023)(Ding et al., 2020)(Fang et al., 2018).</p>
    
    <p>Imbalances in the gut microbiome, known as dysbiosis, have been linked to a range of mental health disorders, such as anxiety, depression, and schizophrenia (Xiong et al., 2023).</p>
    
    <p>Studies have shown that individuals with schizophrenia often exhibit distinct gut microbial profiles, characterized by reduced abundances of beneficial bacteria, such as Ruminococcus and Roseburia, and increased abun.</p>
    
    <p>As a result, there is growing interest in exploring the potential of modulating the gut microbiome as a therapeutic approach for mental health conditions (Green et al., 2023)(Céntí et al., 2017)(Janbrink-Sehgal & Andreasson, 2020)(Capuco et al., 2020)</p>
  `);
  
  const editorRef = useRef<HTMLDivElement>(null);
  const [wordCount, setWordCount] = useState(0);

  // Calculate word count
  useEffect(() => {
    if (editorRef.current) {
      const text = editorRef.current.innerText || '';
      const words = text.trim().split(/\s+/).filter(word => word.length > 0);
      setWordCount(words.length);
    }
  }, [content]);

  const executeCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      setContent(editorRef.current.innerHTML);
    }
  };

  const handleInput = () => {
    if (editorRef.current) {
      setContent(editorRef.current.innerHTML);
    }
  };

  if (!documentId) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>Select a document to start writing</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <input 
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="text-xl font-medium bg-transparent border-none outline-none focus:bg-muted/50 rounded px-2 py-1"
            />
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              Research article
            </Badge>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <Star className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4" />
            </Button>
            <Button size="sm" className="gap-2">
              <Share className="h-4 w-4" />
              Share
            </Button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-1 flex-wrap">
          {/* Undo/Redo */}
          <Button variant="ghost" size="sm" onClick={() => executeCommand('undo')}>
            <Undo className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => executeCommand('redo')}>
            <Redo className="h-4 w-4" />
          </Button>
          
          <div className="w-px h-6 bg-border mx-2" />

          {/* Text Style */}
          <Select defaultValue="normal">
            <SelectTrigger className="w-[120px] h-8">
              <SelectValue placeholder="Normal text" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">Normal text</SelectItem>
              <SelectItem value="heading1">Heading 1</SelectItem>
              <SelectItem value="heading2">Heading 2</SelectItem>
              <SelectItem value="heading3">Heading 3</SelectItem>
            </SelectContent>
          </Select>

          <div className="w-px h-6 bg-border mx-2" />

          {/* Formatting */}
          <Button variant="ghost" size="sm" onClick={() => executeCommand('bold')}>
            <Bold className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => executeCommand('italic')}>
            <Italic className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => executeCommand('underline')}>
            <Underline className="h-4 w-4" />
          </Button>

          <div className="w-px h-6 bg-border mx-2" />

          {/* Alignment */}
          <Button variant="ghost" size="sm" onClick={() => executeCommand('justifyLeft')}>
            <AlignLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => executeCommand('justifyCenter')}>
            <AlignCenter className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => executeCommand('justifyFull')}>
            <AlignJustify className="h-4 w-4" />
          </Button>

          <div className="w-px h-6 bg-border mx-2" />

          {/* Lists */}
          <Button variant="ghost" size="sm" onClick={() => executeCommand('insertUnorderedList')}>
            <List className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => executeCommand('insertOrderedList')}>
            <ListOrdered className="h-4 w-4" />
          </Button>

          <div className="w-px h-6 bg-border mx-2" />

          {/* Insert */}
          <Button variant="ghost" size="sm">
            <Link className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Image className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Table className="h-4 w-4" />
          </Button>
          
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto p-8">
          <div
            ref={editorRef}
            contentEditable
            suppressContentEditableWarning
            onInput={handleInput}
            dangerouslySetInnerHTML={{ __html: content }}
            className="min-h-[500px] prose prose-lg max-w-none focus:outline-none"
            style={{
              lineHeight: '1.6',
              fontSize: '16px',
              fontFamily: 'ui-serif, Georgia, Cambria, "Times New Roman", Times, serif'
            }}
          />
        </div>
      </div>

      {/* Status Bar */}
      <div className="border-t p-2">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>{wordCount} words</span>
          <div className="flex items-center gap-4">
            <span>APA</span>
            <Button variant="link" size="sm" className="text-blue-600">
              Upgrade
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}