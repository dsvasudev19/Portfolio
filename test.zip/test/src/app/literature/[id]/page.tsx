'use client';

import { use } from 'react';
import { LiteratureViewer } from '@/components/literature/LiteratureViewer';

export default function LiteratureViewerPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params) as { id: string };

  // Replace with real fetch later
  return <LiteratureViewer documentId={id} />;
}
