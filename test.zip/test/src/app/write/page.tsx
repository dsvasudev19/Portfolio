'use client';

import { WriteManuscriptDashboard } from "@/components/documents/WriteManuscriptDashboard";


export default function WritePage() {
  return <WriteManuscriptDashboard />;
}
