'use client';

import { DocumentList } from "@/components/documents/DocumentList";
import { useRouter } from "next/navigation";



export default function DocumentsPage() {
    const router=useRouter();
  return  <DocumentList
      selectedDocument={null}
      onSelectDocument={(doc) => {
        console.log('Document selected:', doc);
        router.push(`/documents/${doc}`);
      }}
    />;
}
