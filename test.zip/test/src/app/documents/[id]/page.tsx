'use client';

import { EnhancedDocumentEditor } from '@/components/documents/EnhancedDocumentEditor';
import { use } from 'react';

export default function EditorPage({ params }: { params: Promise<{ id: string }>; }) {
  const { id } = use(params) as { id: string }; // ✅ type assertion fixes TS error
  console.log(id)
  return<EnhancedDocumentEditor
      documentId={id}
      documentType="manuscript"
      onUpgrade={() => {
        console.log('Upgrade clicked');
      }}
    />
  
}
