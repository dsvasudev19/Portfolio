'use client';

import { UnderReviewViewer } from '@/components/under-review/UnderReviewViewer';
import { use } from 'react';

interface Comment {
  id: string;
  position: number;
  text: string;
  highlight: string;
  commentType: 'incorrect' | 'irrelevant' | 'needs-explanation' | 'improvement-required' | 'others';
  severity: 'major' | 'medium' | 'minor';
  reviewer: string;
  timestamp: string;
  isAddressed?: boolean;
  addressedText?: string;
}

interface UnderReviewDocument {
  id: string;
  title: string;
  journal: string;
  type: string;
  content: string;
  comments: Comment[];
  reviewStatus: 'in-progress' | 'completed' | 'revision-required';
  liveCommentsEnabled: boolean;
  concurrentReviewers: number;
}


const mockDocuments: UnderReviewDocument[] = [
  {
    id: 'r1',
    title: 'Gut Microbiota and Mental Health: A Comprehensive Review',
    journal: 'Nature Neuroscience',
    type: 'manuscript',
    content: 'This is the full content for r1...',
    comments: [],
    reviewStatus: 'in-progress',
    liveCommentsEnabled: true,
    concurrentReviewers: 3,
  },
  {
    id: 'r2',
    title: 'Social Media Impact on Adolescent Psychology',
    journal: 'Journal of Digital Health',
    type: 'manuscript',
    content: 'This is the full content for r2...',
    comments: [],
    reviewStatus: 'revision-required',
    liveCommentsEnabled: true,
    concurrentReviewers: 2,
  },
  {
    id: 'r3',
    title: 'Case Study: Treatment-Resistant Depression',
    journal: 'Clinical Psychology Review',
    type: 'manuscript',
    content: 'This is the full content for r3...',
    comments: [],
    reviewStatus: 'completed',
    liveCommentsEnabled: false,
    concurrentReviewers: 2,
  },
];


const getMockDocumentById = (id: string): UnderReviewDocument => {
  return (
    mockDocuments.find((doc) => doc.id === id) ?? {
      id,
      title: 'Unknown Document',
      journal: 'Unknown',
      type: 'manuscript',
      content: 'No content available.',
      comments: [],
      reviewStatus: 'in-progress',
      liveCommentsEnabled: false,
      concurrentReviewers: 0,
    }
  );
};


export default function UnderReviewViewerPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params) as { id: string };

  const document: UnderReviewDocument = getMockDocumentById(id);

  return (
    <UnderReviewViewer
      document={document}
      onBack={() => window.history.back()}
    />
  );
}