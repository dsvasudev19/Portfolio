'use client';

import { UnderReviewList } from '@/components/under-review/UnderReviewList';
import { useRouter } from 'next/navigation';


export default function UnderReviewPage() {
const router = useRouter();

  return  <UnderReviewList
      selectedDocument={null}
      onSelectDocument={(doc) => console.log('Select', doc)}
      onViewDocument={(doc) => {
        console.log('View', doc);
        router.push(`/under-review/${doc.id}`);
      }}
    />;
}
