import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

interface CreateManuscriptDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const manuscriptTypes = [
  { value: "research", label: "Research Article" },
  { value: "review", label: "Review Article" },
  { value: "case_report", label: "Case Report" },
  { value: "editorial", label: "Editorial" },
  { value: "conference", label: "Conference Proceedings" },
  { value: "grant", label: "Grant Proposal" },
];

// Mock projects - in real app, this would come from Design Research data
const mockProjects = [
  { id: "1", name: "Mental Health Research" },
  { id: "2", name: "Microbiome Studies" },
  { id: "3", name: "Social Media Impact" },
];

export function CreateManuscriptDialog({ open, onOpenChange }: CreateManuscriptDialogProps) {
  const [title, setTitle] = useState("");
  const [project, setProject] = useState("");
  const [type, setType] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle manuscript creation
    console.log({ title, project, type });

    toast("Manuscript created successfully")
    onOpenChange(false);
    // Reset form
    setTitle("");
    setProject("");
    setType("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Create New Manuscript</DialogTitle>
          <DialogDescription>
            Fill in the details to create a new manuscript document.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Manuscript Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter manuscript title"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="project">Project</Label>
            <Select value={project} onValueChange={setProject} required>
              <SelectTrigger>
                <SelectValue placeholder="Select a project" />
              </SelectTrigger>
              <SelectContent>
                {mockProjects.map((proj) => (
                  <SelectItem key={proj.id} value={proj.id}>
                    {proj.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Type of Manuscript</Label>
            <Select value={type} onValueChange={setType} required>
              <SelectTrigger>
                <SelectValue placeholder="Select manuscript type" />
              </SelectTrigger>
              <SelectContent>
                {manuscriptTypes.map((t) => (
                  <SelectItem key={t.value} value={t.value}>
                    {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              Create Manuscript
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}