import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Search, 
  Mail, 
  UserPlus, 
  Check, 
  Clock,
  X
} from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface CoAuthor {
  id: string;
  name: string;
  email: string;
  avatar: string;
  status: 'active' | 'invited' | 'pending';
}

interface CoAuthorDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  coAuthors: CoAuthor[];
}

export function CoAuthorDialog({ open, onOpenChange, coAuthors }: CoAuthorDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [inviteEmail, setInviteEmail] = useState("");

  const getStatusIcon = (status: CoAuthor['status']) => {
    switch (status) {
      case 'active':
        return <Check className="h-3 w-3 text-green-600" />;
      case 'invited':
        return <Clock className="h-3 w-3 text-yellow-600" />;
      case 'pending':
        return <Clock className="h-3 w-3 text-blue-600" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: CoAuthor['status']) => {
    switch (status) {
      case 'active':
        return 'Active';
      case 'invited':
        return 'Invited';
      case 'pending':
        return 'Pending';
      default:
        return status;
    }
  };

  const getStatusColor = (status: CoAuthor['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'invited':
        return 'bg-yellow-100 text-yellow-800';
      case 'pending':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleInviteByEmail = () => {
    if (inviteEmail) {
      // Handle email invitation
      console.log('Inviting:', inviteEmail);
      setInviteEmail("");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Co-Authors</DialogTitle>
          <DialogDescription>
            Invite collaborators to work on this manuscript together.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Search existing users */}
          <div className="space-y-3">
            <Label>Search Scholar Bench Members</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by name or email..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            {/* Mock search results */}
            {searchQuery && (
              <div className="border rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between p-2 hover:bg-muted/50 rounded">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-sm font-medium">
                      JS
                    </div>
                    <div>
                      <p className="font-medium text-sm">Dr. James Smith</p>
                      <p className="text-xs text-muted-foreground">james.smith@university.edu</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="gap-1">
                    <UserPlus className="h-3 w-3" />
                    Invite
                  </Button>
                </div>
              </div>
            )}
          </div>

          <Separator />

          {/* Invite by email */}
          <div className="space-y-3">
            <Label>Invite by Email</Label>
            <div className="flex gap-2">
              <Input 
                type="email"
                placeholder="colleague@university.edu"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
              />
              <Button onClick={handleInviteByEmail} className="gap-1">
                <Mail className="h-4 w-4" />
                Send Invite
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              They&aposll receive an email invitation to join Scholar Bench and collaborate on this manuscript.
            </p>
          </div>

          <Separator />

          {/* Current co-authors */}
          <div className="space-y-3">
            <Label>Current Co-Authors ({coAuthors.length})</Label>
            <div className="space-y-2">
              {coAuthors.map((author) => (
                <div key={author.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                      {author.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{author.name}</p>
                      <p className="text-xs text-muted-foreground">{author.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className={`text-xs ${getStatusColor(author.status)} flex items-center gap-1`}>
                      {getStatusIcon(author.status)}
                      {getStatusText(author.status)}
                    </Badge>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive">
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}