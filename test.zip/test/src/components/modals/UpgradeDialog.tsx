import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Check, Crown, Zap, Users, FileText } from "lucide-react";

interface UpgradeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpgrade: () => void;
}

const features = [
  "Unlimited AI generations",
  "Unlimited AI Chat messages", 
  "Unlimited citations",
  "Unlimited library storage"
];

export function UpgradeDialog({ open, onOpenChange, onUpgrade }: UpgradeDialogProps) {
  const [selectedPlan, setSelectedPlan] = useState<'annual' | 'monthly'>('annual');

  const handleUpgrade = () => {
    onOpenChange(false);
    onUpgrade();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl">Upgrade to Unlimited</DialogTitle>
          <DialogDescription className="text-center">
            Create without limits by upgrading to an unlimited plan.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Features */}
          <div className="space-y-3">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center">
                  <Check className="h-3 w-3 text-green-600" />
                </div>
                <span className="text-sm">{feature}</span>
              </div>
            ))}
          </div>

          {/* Pricing Options */}
          <div className="space-y-3">
            {/* Annual Plan */}
            <div 
              className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                selectedPlan === 'annual' 
                  ? 'border-primary bg-primary/5' 
                  : 'border-border hover:border-primary/50'
              }`}
              onClick={() => setSelectedPlan('annual')}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    selectedPlan === 'annual' 
                      ? 'border-primary bg-primary' 
                      : 'border-border'
                  }`} />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Annual</span>
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                        Save 60%
                      </span>
                    </div>
                  </div>
                </div>
                <span className="font-bold">INR 1039.33/mo</span>
              </div>
            </div>

            {/* Monthly Plan */}
            <div 
              className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                selectedPlan === 'monthly' 
                  ? 'border-primary bg-primary/5' 
                  : 'border-border hover:border-primary/50'
              }`}
              onClick={() => setSelectedPlan('monthly')}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    selectedPlan === 'monthly' 
                      ? 'border-primary bg-primary' 
                      : 'border-border'
                  }`} />
                  <span className="font-medium">Monthly</span>
                </div>
                <span className="font-bold">INR 2598.00/mo</span>
              </div>
            </div>
          </div>

          {/* Upgrade Button */}
          <Button onClick={handleUpgrade} className="w-full py-6 text-lg">
            Upgrade Now
          </Button>

          {/* Social Proof */}
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <div className="flex -space-x-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="w-6 h-6 rounded-full bg-primary/20 border-2 border-background" />
              ))}
            </div>
            <span>Join 37,102 researchers improving their writing with Scholarbench</span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}