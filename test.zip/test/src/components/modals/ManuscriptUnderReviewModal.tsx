import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Eye,
  Lock,
  Users,
  Clock
} from "lucide-react";
import flagIcon from "@/assets/flag-icon.png";

interface Comment {
  id: string;
  position: number;
  text: string;
  highlight: string;
  commentType: 'incorrect' | 'irrelevant' | 'needs-explanation' | 'improvement-required' | 'others';
  severity: 'major' | 'medium' | 'minor';
  reviewer: string;
  timestamp: string;
}

interface ReviewDocument {
  id: string;
  title: string;
  journal: string;
  submittedDate: string;
  status: 'submitted' | 'under_review' | 'revision_required' | 'accepted' | 'rejected';
  reviewers: number;
  type: 'Research article' | 'Review' | 'Case report';
}

interface ManuscriptUnderReviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  document: ReviewDocument | null;
}

const mockComments: Comment[] = [
  {
    id: "1",
    position: 0.2,
    text: "This methodology section needs more detail about the data preprocessing steps.",
    highlight: "We analyzed data from 5,000 patients",
    commentType: "needs-explanation",
    severity: "medium",
    reviewer: "Reviewer #2",
    timestamp: "2024-01-15 14:30"
  },
  {
    id: "2",
    position: 0.5,
    text: "The statistical analysis approach seems inappropriate for this type of data.",
    highlight: "CNNs achieved 94.2% accuracy",
    commentType: "incorrect",
    severity: "major",
    reviewer: "Reviewer #1",
    timestamp: "2024-01-15 16:45"
  }
];

const mockContent = `
Abstract

Background: Machine learning (ML) applications in medical diagnosis have shown significant promise in recent years [1]. This study examines the effectiveness of various ML algorithms in diagnosing cardiovascular diseases.

Methods: We analyzed data from 5,000 patients across multiple hospitals, implementing convolutional neural networks (CNNs), random forests, and support vector machines (SVMs) for diagnostic accuracy comparison [2,3].

Results: Our findings demonstrate that CNNs achieved 94.2% accuracy in detecting cardiovascular abnormalities, significantly outperforming traditional diagnostic methods by 12% (Smith et al., 2023).

Conclusion: Machine learning algorithms, particularly CNNs, show substantial potential for improving cardiovascular disease diagnosis accuracy and could be implemented in clinical settings [4].

Introduction

Cardiovascular diseases remain the leading cause of mortality worldwide, accounting for approximately 17.9 million deaths annually according to the World Health Organization [5]. Early and accurate diagnosis is crucial for effective treatment and improved patient outcomes. Traditional diagnostic methods, while reliable, often require extensive expertise and can be subject to human error.

The advent of machine learning technologies has opened new avenues for medical diagnosis [6]. These technologies can process vast amounts of data quickly and identify patterns that might be missed by human observation. In the field of cardiovascular medicine, several studies have explored the application of ML algorithms for diagnosis, with varying degrees of success (Johnson et al., 2022).

This study aims to evaluate the performance of different machine learning algorithms in diagnosing cardiovascular diseases and compare their effectiveness with traditional diagnostic methods [7].
`;

const getCommentTypeColor = (commentType: string) => {
  switch (commentType) {
    case 'incorrect': return 'bg-red-500';
    case 'irrelevant': return 'bg-orange-500';
    case 'needs-explanation': return 'bg-yellow-500';
    case 'improvement-required': return 'bg-blue-500';
    case 'others': return 'bg-purple-500';
    default: return 'bg-gray-500';
  }
};

const getSeverityBorder = (severity: string) => {
  switch (severity) {
    case 'major': return 'border-red-500 border-2';
    case 'medium': return 'border-orange-500 border-2';
    case 'minor': return 'border-green-500 border-2';
    default: return 'border-gray-300';
  }
};

export function ManuscriptUnderReviewModal({ open, onOpenChange, document }: ManuscriptUnderReviewModalProps) {
  const [selectedComment, setSelectedComment] = useState<Comment | null>(null);
  
  if (!document) return null;

  const renderContentWithComments = (content: string) => {
    let renderedContent = content;
    
    // Add flags for comments in text with respective colors
    mockComments.forEach(comment => {
      const flagColor = getCommentTypeColor(comment.commentType);
      const severityBorder = getSeverityBorder(comment.severity);
      const flagSpan = `<span class="comment-flag inline-flex items-center ml-1 cursor-pointer" data-comment-id="${comment.id}"><img src="${flagIcon}" alt="Flag" class="w-3 h-3 ${flagColor} ${severityBorder} rounded-sm" title="${comment.text}"/></span>`;
      
      if (renderedContent.includes(comment.highlight)) {
        renderedContent = renderedContent.replace(
          comment.highlight, 
          `<mark class="bg-yellow-200 cursor-pointer" data-comment-id="${comment.id}">${comment.highlight}</mark>${flagSpan}`
        );
      }
    });
    
    return renderedContent;
  };

  const handleCommentClick = (commentId: string) => {
    const comment = mockComments.find(c => c.id === commentId);
    if (comment) {
      setSelectedComment(comment);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            {document.title} - Under Review
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex h-[80vh]">
          {/* Main Content */}
          <div className="flex-1 flex flex-col mr-4">
            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
              <span>{document.journal}</span>
              <Badge variant="outline">{document.type}</Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Under Review
              </Badge>
              {document.reviewers > 0 && (
                <div className="flex items-center gap-1 text-orange-600">
                  <Users className="w-4 h-4" />
                  <span>{document.reviewers} reviewer(s) active</span>
                </div>
              )}
            </div>

            <ScrollArea className="flex-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="w-5 h-5" />
                    Manuscript with Review Comments
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div 
                    className="prose max-w-none"
                    onClick={(e) => {
                      const target = e.target as HTMLElement;
                      const commentId = target.getAttribute('data-comment-id') || 
                                       target.closest('[data-comment-id]')?.getAttribute('data-comment-id');
                      if (commentId) {
                        handleCommentClick(commentId);
                      }
                    }}
                    style={{ whiteSpace: 'pre-line' }}
                    dangerouslySetInnerHTML={{ __html: renderContentWithComments(mockContent) }}
                  />
                </CardContent>
              </Card>
              
              <Card className="mt-4 border-amber-200 bg-amber-50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-amber-800">
                    <Lock className="w-5 h-5" />
                    <div>
                      <p className="font-medium">Document is locked for editing</p>
                      <p className="text-sm">You can view reviewer comments but cannot make changes until the review process is complete and the Managing Editor enables live review comments.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </ScrollArea>
          </div>

          {/* Comments Sidebar */}
          <div className="w-80 border-l pl-4">
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Review Comments ({mockComments.length})</h3>
                <div className="text-sm text-muted-foreground">
                  Click on highlighted text or flags to view comment details
                </div>
              </div>
              
              <Separator />
              
              {selectedComment ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Selected Comment</h4>
                    <Button variant="ghost" size="sm" onClick={() => setSelectedComment(null)}>
                      ×
                    </Button>
                  </div>
                  
                  <div className={`p-3 border rounded ${getSeverityBorder(selectedComment.severity)}`}>
                    <div className="flex items-center gap-2 mb-2">
                      {/* <img src={flagIcon} alt="Flag" className={`w-3 h-3 ${getCommentTypeColor(selectedComment.commentType)}`} /> */}
                      <Badge variant="outline" className="text-xs">{selectedComment.commentType}</Badge>
                      <Badge variant={selectedComment.severity === 'major' ? 'destructive' : selectedComment.severity === 'medium' ? 'default' : 'secondary'} className="text-xs">
                        {selectedComment.severity}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-xs font-medium text-muted-foreground">
                        {selectedComment.highlight}
                      </div>
                      <div className="text-sm">{selectedComment.text}</div>
                      <div className="text-xs text-muted-foreground border-t pt-2">
                        {selectedComment.reviewer} • {selectedComment.timestamp}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {mockComments.map((comment) => (
                      <div 
                        key={comment.id} 
                        className={`p-2 border rounded text-sm space-y-1 cursor-pointer hover:bg-muted/50 ${getSeverityBorder(comment.severity)}`}
                        onClick={() => setSelectedComment(comment)}
                      >
                        <div className="flex items-center gap-2">
                          {/* <img src={flagIcon} alt="Flag" className={`w-3 h-3 ${getCommentTypeColor(comment.commentType)}`} /> */}
                          <Badge variant="outline" className="text-xs">{comment.commentType}</Badge>
                          <Badge variant={comment.severity === 'major' ? 'destructive' : comment.severity === 'medium' ? 'default' : 'secondary'} className="text-xs">
                            {comment.severity}
                          </Badge>
                        </div>
                        <div className="font-medium text-xs text-muted-foreground">
                          {comment.highlight}
                        </div>
                        <div className="line-clamp-2">{comment.text}</div>
                        <div className="text-xs text-muted-foreground">
                          {comment.reviewer}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}