import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { 
  ArrowLeft, 
  Eye,
  Lock,
  Users,
  Clock,
  MessageSquare,
  BarChart3,
  ExternalLink,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Trash2,
  RefreshCw,
  Lightbulb
} from "lucide-react";
import flagIcon from "@/assets/flag-icon.png";
import { HighlightsPanel } from "../literature/HighlightsPanel";
import { toast } from "sonner";

interface Comment {
  id: string;
  position: number;
  text: string;
  highlight: string;
  commentType: 'incorrect' | 'irrelevant' | 'needs-explanation' | 'improvement-required' | 'others';
  severity: 'major' | 'medium' | 'minor';
  reviewer: string;
  timestamp: string;
  isAddressed?: boolean;
  addressedText?: string;
}

interface CitationReference {
  id: string;
  title: string;
  authors: string[];
  journal: string;
  year: number;
  publishingCompany: string;
  logo: string;
  highlightedText: string;
  fullText: string;
  isPertinent?: boolean | null;
  isSelfCitation?: boolean;
}

interface UnderReviewDocument {
  id: string;
  title: string;
  journal: string;
  type: string;
  content: string;
  comments: Comment[];
  reviewStatus: 'in-progress' | 'completed' | 'revision-required';
  liveCommentsEnabled: boolean;
  concurrentReviewers: number;
}

interface UnderReviewViewerProps {
  document: UnderReviewDocument;
  onBack: () => void;
}

const mockComments: Comment[] = [
  {
    id: "1",
    position: 0.2,
    text: "This methodology section needs more detail about the data preprocessing steps.",
    highlight: "We analyzed data from 5,000 patients",
    commentType: "needs-explanation",
    severity: "medium",
    reviewer: "Reviewer #2",
    timestamp: "2024-01-15 14:30"
  },
  {
    id: "2",
    position: 0.5,
    text: "The statistical analysis approach seems inappropriate for this type of data.",
    highlight: "CNNs achieved 94.2% accuracy",
    commentType: "incorrect",
    severity: "major",
    reviewer: "Reviewer #1",
    timestamp: "2024-01-15 16:45"
  }
];

const mockCitations: CitationReference[] = [
  {
    id: "1",
    title: "Machine Learning Applications in Medical Diagnosis: A Comprehensive Review",
    authors: ["Johnson, A.", "Smith, B.", "Williams, C."],
    journal: "Nature Medicine",
    year: 2023,
    publishingCompany: "Nature Publishing Group",
    logo: "/journal-covers/nature-medicine.jpg",
    highlightedText: "Machine learning (ML) applications in medical diagnosis have shown significant promise in recent years",
    fullText: "Background: Machine learning (ML) applications in medical diagnosis have shown significant promise in recent years [1].",
    isPertinent: true,
    isSelfCitation: false
  },
  {
    id: "2", 
    title: "Convolutional Neural Networks for Cardiovascular Disease Detection",
    authors: ["Anderson, P.", "Davis, M."],
    journal: "Scientific Reports",
    year: 2022,
    publishingCompany: "Nature Publishing Group",
    logo: "/journal-covers/scientific-reports.jpg",
    highlightedText: "convolutional neural networks (CNNs), random forests, and support vector machines (SVMs)",
    fullText: "Methods: We analyzed data from 5,000 patients across multiple hospitals, implementing convolutional neural networks (CNNs), random forests, and support vector machines (SVMs) for diagnostic accuracy comparison [2,3].",
    isPertinent: false,
    isSelfCitation: false
  },
  {
    id: "3",
    title: "Cardiovascular Disease Diagnosis Using Machine Learning",
    authors: ["Smith, J.", "Brown, K.", "Lee, S."],
    journal: "The Lancet",
    year: 2023,
    publishingCompany: "Elsevier",
    logo: "/journal-covers/lancet.jpg",
    highlightedText: "CNNs achieved 94.2% accuracy in detecting cardiovascular abnormalities, significantly outperforming traditional diagnostic methods by 12%",
    fullText: "Results: Our findings demonstrate that CNNs achieved 94.2% accuracy in detecting cardiovascular abnormalities, significantly outperforming traditional diagnostic methods by 12% (Smith et al., 2023).",
    isPertinent: null,
    isSelfCitation: true
  }
];

const getCommentTypeColor = (commentType: string) => {
  switch (commentType) {
    case 'incorrect': return 'bg-red-500';
    case 'irrelevant': return 'bg-orange-500';
    case 'needs-explanation': return 'bg-yellow-500';
    case 'improvement-required': return 'bg-blue-500';
    case 'others': return 'bg-purple-500';
    default: return 'bg-gray-500';
  }
};

const getSeverityBorder = (severity: string) => {
  switch (severity) {
    case 'major': return 'border-red-500 border-2';
    case 'medium': return 'border-orange-500 border-2';
    case 'minor': return 'border-green-500 border-2';
    default: return 'border-gray-300';
  }
};

export function UnderReviewViewer({ document, onBack }: UnderReviewViewerProps) {
  // const { toast } = useToast();
  const [selectedComment, setSelectedComment] = useState<Comment | null>(null);
  const [selectedCitation, setSelectedCitation] = useState<CitationReference | null>(null);
  const [sidebarTab, setSidebarTab] = useState<'comments' | 'citations'>('comments');
  const [showCitationDialog, setShowCitationDialog] = useState(false);
  const [showCommentActionDialog, setShowCommentActionDialog] = useState(false);
  const [commentAction, setCommentAction] = useState<'accept' | 'reject' | null>(null);
  const [actionExplanation, setActionExplanation] = useState('');
  const [showCitationActionDialog, setShowCitationActionDialog] = useState(false);
  const [showHighlightsPanel, setShowHighlightsPanel] = useState(false);
  const [comments, setComments] = useState<Comment[]>(mockComments);
  const [editingComment, setEditingComment] = useState<string | null>(null);
  
  const mockDocument: UnderReviewDocument = {
    id: document.id,
    title: document.title,
    journal: document.journal,
    type: document.type,
    content: `
Abstract

Background: Machine learning (ML) applications in medical diagnosis have shown significant promise in recent years [1]. This study examines the effectiveness of various ML algorithms in diagnosing cardiovascular diseases.

Methods: We analyzed data from 5,000 patients across multiple hospitals, implementing convolutional neural networks (CNNs), random forests, and support vector machines (SVMs) for diagnostic accuracy comparison [2,3].

Results: Our findings demonstrate that CNNs achieved 94.2% accuracy in detecting cardiovascular abnormalities, significantly outperforming traditional diagnostic methods by 12% (Smith et al., 2023).

Conclusion: Machine learning algorithms, particularly CNNs, show substantial potential for improving cardiovascular disease diagnosis accuracy and could be implemented in clinical settings [4].

Introduction

Cardiovascular diseases remain the leading cause of mortality worldwide, accounting for approximately 17.9 million deaths annually according to the World Health Organization [5]. Early and accurate diagnosis is crucial for effective treatment and improved patient outcomes. Traditional diagnostic methods, while reliable, often require extensive expertise and can be subject to human error.

The advent of machine learning technologies has opened new avenues for medical diagnosis [6]. These technologies can process vast amounts of data quickly and identify patterns that might be missed by human observation. In the field of cardiovascular medicine, several studies have explored the application of ML algorithms for diagnosis, with varying degrees of success (Johnson et al., 2022).

This study aims to evaluate the performance of different machine learning algorithms in diagnosing cardiovascular diseases and compare their effectiveness with traditional diagnostic methods [7].
    `,
    comments: comments,
    reviewStatus: 'in-progress',
    liveCommentsEnabled: false,
    concurrentReviewers: 2
  };

  const renderContentWithComments = (content: string) => {
    let renderedContent = content;
    
    // Add flags for comments in text with respective colors
    comments.forEach(comment => {
      const flagColor = getCommentTypeColor(comment.commentType);
      const severityBorder = getSeverityBorder(comment.severity);
      const flagSpan = `<span class="comment-flag inline-flex items-center ml-1 cursor-pointer" data-comment-id="${comment.id}"><img src="${flagIcon}" alt="Flag" class="w-3 h-3 ${flagColor} ${severityBorder} rounded-sm" title="${comment.text}"/></span>`;
      
      if (renderedContent.includes(comment.highlight)) {
        renderedContent = renderedContent.replace(
          comment.highlight, 
          `<mark class="bg-yellow-200 cursor-pointer" data-comment-id="${comment.id}">${comment.highlight}</mark>${flagSpan}`
        );
      }
    });
    
    return renderedContent;
  };

  const handleCommentClick = (commentId: string) => {
    const comment = comments.find(c => c.id === commentId);
    if (comment) {
      setSelectedComment(comment);
    }
  };

  const handleCommentAction = (action: 'accept' | 'reject') => {
    setCommentAction(action);
    setShowCommentActionDialog(true);
  };

  const submitCommentAction = () => {
    if (selectedComment && commentAction) {
      // Update the comment with addressed status
      setComments(prevComments => 
        prevComments.map(comment => 
          comment.id === selectedComment.id 
            ? { 
                ...comment, 
                isAddressed: true, 
                addressedText: actionExplanation 
              }
            : comment
        )
      );

      toast( `Comment ${commentAction}ed The comment "${selectedComment.highlight}" has been ${commentAction}ed successfully.`);
      
      // Reset states
      setShowCommentActionDialog(false);
      setCommentAction(null);
      setActionExplanation('');
      setSelectedComment(null);
      
      console.log(`${commentAction} comment ${selectedComment.id} with explanation: ${actionExplanation}`);
    }
  };

  const handleEditAddressedComment = (comment: Comment) => {
    setSelectedComment(comment);
    setActionExplanation(comment.addressedText || '');
    setEditingComment(comment.id);
    setShowCommentActionDialog(true);
  };

  const updateAddressedComment = () => {
    if (selectedComment && editingComment) {
      setComments(prevComments => 
        prevComments.map(comment => 
          comment.id === editingComment 
            ? { 
                ...comment, 
                addressedText: actionExplanation 
              }
            : comment
        )
      );

      toast( "Reply updated,your addressed comment response has been updated successfully.");
      
      // Reset states
      setShowCommentActionDialog(false);
      setEditingComment(null);
      setActionExplanation('');
      setSelectedComment(null);
    }
  };

  const handleCitationRemove = (citationId: string) => {
    console.log(`Removing citation ${citationId} from text and references`);
    // Implementation would remove citation from content and references
  };

  const handleCitationReplace = (citationId: string) => {
    setSelectedCitation(mockCitations.find(c => c.id === citationId) || null);
    setShowHighlightsPanel(true);
    console.log(`Opening highlights panel to replace citation ${citationId}`);
  };

  const handleHighlightSelect = (highlight: any) => {
    console.log(`Replacing citation with highlight: ${highlight.text}`);
    toast(
     "Citation replaced successfully, The selected highlight has been used to replace the impertinent citation."
    );
    setShowHighlightsPanel(false);
  };

  // Citation metrics calculation
  const citationMetrics = {
    total: mockCitations.length,
    pertinent: mockCitations.filter(c => c.isPertinent === true).length,
    impertinent: mockCitations.filter(c => c.isPertinent === false).length,
    pending: mockCitations.filter(c => c.isPertinent === null).length,
    selfCitations: mockCitations.filter(c => c.isSelfCitation).length
  };

  return (
    <div className="flex h-screen">
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={onBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Documents
              </Button>
              <div className="flex items-center gap-4">
                <Badge variant="secondary" className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  Under Review
                </Badge>
                {mockDocument.concurrentReviewers > 0 && (
                  <div className="flex items-center gap-1 text-orange-600">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">{mockDocument.concurrentReviewers} active reviewer{mockDocument.concurrentReviewers > 1 ? 's' : ''}</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!mockDocument.liveCommentsEnabled && (
                <div className="flex items-center gap-1 text-amber-600 text-sm">
                  <Lock className="w-4 h-4" />
                  <span>Editing locked during review</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Document Content */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="p-6 max-w-4xl mx-auto">
                <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="w-5 h-5" />
                    Manuscript with Review Comments
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Document metadata */}
                  <div className="mb-6 pb-4 border-b">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div>
                          <Badge variant="outline" className="mb-2">{mockDocument.type}</Badge>
                          <h1 className="text-2xl font-semibold">{mockDocument.title}</h1>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-muted-foreground">{mockDocument.journal}</div>
                      </div>
                    </div>
                  </div>
                  <div 
                    className="prose max-w-none"
                    onClick={(e) => {
                      const target = e.target as HTMLElement;
                      const commentId = target.getAttribute('data-comment-id') || 
                                       target.closest('[data-comment-id]')?.getAttribute('data-comment-id');
                      if (commentId) {
                        handleCommentClick(commentId);
                      }
                    }}
                    style={{ whiteSpace: 'pre-line' }}
                    dangerouslySetInnerHTML={{ __html: renderContentWithComments(mockDocument.content) }}
                  />
                </CardContent>
              </Card>
              
              {!mockDocument.liveCommentsEnabled && (
                <Card className="mt-4 border-amber-200 bg-amber-50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-amber-800">
                      <Lock className="w-5 h-5" />
                      <div>
                        <p className="font-medium">Document is locked for editing</p>
                        <p className="text-sm">You can view reviewer comments but cannot make changes until the review process is complete and the Managing Editor enables live review comments.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </ScrollArea>
        </div>
      </div>

      {/* Review Sidebar with Tabs OR Highlights Panel */}
        {showHighlightsPanel ? (
        <div className="w-80 border-l bg-background flex flex-col">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-medium text-lg">Highlights</h3>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setShowHighlightsPanel(false)}
              className="text-sm"
            >
              Back to Citations
            </Button>
          </div>
          
          {selectedCitation && (
            <div className="p-4">
              <div className="bg-muted p-3 rounded text-sm">
                <div className="text-muted-foreground mb-1">Replacing citation:</div>
                <div className="font-medium">{selectedCitation.title}</div>
                <div className="text-muted-foreground mt-1 text-xs">
                  {selectedCitation.highlightedText}
                </div>
              </div>
            </div>
          )}
          
          <HighlightsPanel 
            isVisible={true} 
            onHighlightSelect={handleHighlightSelect}
          />
        </div>
      ) : (
        /* Regular Review Sidebar with Tabs */
        <div className="w-96 border-l bg-background flex flex-col">
          <div className="p-4 border-b">
            <Tabs value={sidebarTab} onValueChange={(value) => setSidebarTab(value as 'comments' | 'citations')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="comments" className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Comments ({comments.length})
                </TabsTrigger>
                <TabsTrigger value="citations" className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Citations ({mockCitations.length})
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="flex-1 overflow-hidden">
            <Tabs value={sidebarTab} className="h-full">
              <TabsContent value="comments" className="h-full m-0 p-4 space-y-4">
                <div className="text-sm text-muted-foreground">
                  Click on highlighted text or flags to view comment details
                </div>
                
                {selectedComment ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">Selected Comment</h4>
                        <Button variant="ghost" size="sm" onClick={() => setSelectedComment(null)}>
                          ×
                        </Button>
                      </div>
                      
                      <div className={`p-3 border rounded ${getSeverityBorder(selectedComment.severity)}`}>
                        <div className="flex items-center gap-2 mb-2">
                          {/* <img src={flagIcon} alt="Flag" className={`w-3 h-3 ${getCommentTypeColor(selectedComment.commentType)}`} /> */}
                          <Badge variant="outline" className="text-xs">{selectedComment.commentType}</Badge>
                          <Badge variant={selectedComment.severity === 'major' ? 'destructive' : selectedComment.severity === 'medium' ? 'default' : 'secondary'} className="text-xs">
                            {selectedComment.severity}
                          </Badge>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="text-xs font-medium text-muted-foreground">
                            {selectedComment.highlight}
                          </div>
                          <div className="text-sm">{selectedComment.text}</div>
                          <div className="text-xs text-muted-foreground border-t pt-2">
                            {selectedComment.reviewer} • {selectedComment.timestamp}
                          </div>
                        </div>
                      </div>

                      {/* Show addressed status or Accept/Reject Actions */}
                      {selectedComment.isAddressed ? (
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                            <span className="text-sm text-green-700 font-medium">Comment Addressed</span>
                          </div>
                          <div className="p-3 bg-muted rounded">
                            <div className="text-xs font-medium text-muted-foreground mb-1">Your response:</div>
                            <div className="text-sm">{selectedComment.addressedText}</div>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleEditAddressedComment(selectedComment)}
                            className="w-full"
                          >
                            Edit Reply
                          </Button>
                        </div>
                      ) : (
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleCommentAction('accept')}
                            className="flex-1"
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Accept
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleCommentAction('reject')}
                            className="flex-1"
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                ) : (
                  <ScrollArea className="h-full">
                    <div className="space-y-2 pr-2">
                      {comments.map((comment) => (
                        <div 
                          key={comment.id} 
                          className={`p-2 border rounded text-sm space-y-1 cursor-pointer hover:bg-muted/50 ${getSeverityBorder(comment.severity)} ${comment.isAddressed ? 'bg-green-50 border-green-200' : ''}`}
                          onClick={() => setSelectedComment(comment)}
                        >
                          <div className="flex items-center gap-2">
                            {comment.isAddressed && (
                              <CheckCircle className="w-3 h-3 text-green-600" />
                            )}
                            {/* <img src={flagIcon} alt="Flag" className={`w-3 h-3 ${getCommentTypeColor(comment.commentType)}`} /> */}
                            <Badge variant="outline" className="text-xs">{comment.commentType}</Badge>
                            <Badge variant={comment.severity === 'major' ? 'destructive' : comment.severity === 'medium' ? 'default' : 'secondary'} className="text-xs">
                              {comment.severity}
                            </Badge>
                          </div>
                          <div className="font-medium text-xs text-muted-foreground">
                            {comment.highlight}
                          </div>
                          <div className="line-clamp-2">{comment.text}</div>
                          <div className="text-xs text-muted-foreground">
                            {comment.reviewer}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </TabsContent>

              <TabsContent value="citations" className="h-full m-0 p-4">
                <div className="space-y-4 h-full">
                  <div className="text-sm text-muted-foreground">
                    Citation analysis and pertinence review for this manuscript
                  </div>

                  {/* Citation Metrics */}
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-muted p-2 rounded">
                      <div className="font-medium text-center">{citationMetrics.total}</div>
                      <div className="text-muted-foreground text-center">Total</div>
                    </div>
                    <div className="bg-green-50 p-2 rounded">
                      <div className="font-medium text-center text-green-700">{citationMetrics.pertinent}</div>
                      <div className="text-green-600 text-center">Pertinent</div>
                    </div>
                    <div className="bg-red-50 p-2 rounded">
                      <div className="font-medium text-center text-red-700">{citationMetrics.impertinent}</div>
                      <div className="text-red-600 text-center">Impertinent</div>
                    </div>
                    <div className="bg-yellow-50 p-2 rounded">
                      <div className="font-medium text-center text-yellow-700">{citationMetrics.selfCitations}</div>
                      <div className="text-yellow-600 text-center">Self-cite</div>
                    </div>
                  </div>
                  
                  <ScrollArea className="h-full">
                    <div className="space-y-3 pr-2">
                      {mockCitations.map((citation) => (
                        <div key={citation.id} className="border rounded-lg p-3 space-y-2">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h4 className="font-medium text-sm line-clamp-2 mb-1">{citation.title}</h4>
                              <p className="text-xs text-muted-foreground">
                                {citation.authors.join(", ")} ({citation.year})
                              </p>
                              <p className="text-xs text-muted-foreground">{citation.journal}</p>
                            </div>
                            <div className="flex flex-col items-end gap-1">
                              {citation.isSelfCitation && (
                                <Badge variant="secondary" className="text-xs">
                                  Self-citation
                                </Badge>
                              )}
                              {citation.isPertinent !== null && (
                                <div className="text-lg">
                                  {citation.isPertinent ? "✓" : "✗"}
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <div className="text-xs bg-muted p-2 rounded italic">
                            {citation.highlightedText}
                          </div>

                          <div className="flex items-center justify-between">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedCitation(citation);
                                setShowCitationDialog(true);
                              }}
                              className="text-xs"
                            >
                              <ExternalLink className="w-3 h-3 mr-1" />
                              View Details
                            </Button>
                            
                            {citation.isPertinent === null && (
                              <div className="text-xs text-amber-600 flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3" />
                                Pending Review
                              </div>
                            )}
                          </div>

                          {/* Remove/Replace actions for impertinent citations */}
                          {citation.isPertinent === false && (
                            <div className="flex gap-2 pt-2 border-t">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => handleCitationRemove(citation.id)}
                                className="flex-1 text-xs"
                              >
                                <Trash2 className="w-3 h-3 mr-1" />
                                Remove
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => handleCitationReplace(citation.id)}
                                className="flex-1 text-xs"
                              >
                                <RefreshCw className="w-3 h-3 mr-1" />
                                Replace
                              </Button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}

      {/* Comment Action Dialog */}
      <Dialog open={showCommentActionDialog} onOpenChange={setShowCommentActionDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingComment 
                ? 'Edit Reply' 
                : commentAction === 'accept' 
                  ? 'Accept Comment' 
                  : 'Reject Comment'
              }
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedComment && (
              <div className="p-3 bg-muted rounded">
                <div className="text-sm font-medium mb-1">Comment:</div>
                <div className="text-sm text-muted-foreground">{selectedComment.highlight}</div>
                <div className="text-sm mt-2">{selectedComment.text}</div>
              </div>
            )}
            <div className="space-y-2">
              <label className="text-sm font-medium">
                {editingComment 
                  ? 'Update your response:' 
                  : commentAction === 'accept' 
                    ? 'Implementation notes:' 
                    : 'Rejection reason:'
                }
              </label>
              <Textarea
                placeholder={
                  editingComment
                    ? "Update your response to this comment..."
                    : commentAction === 'accept' 
                      ? "Describe how you will implement this feedback..."
                      : "Explain why you are rejecting this comment..."
                }
                value={actionExplanation}
                onChange={(e) => setActionExplanation(e.target.value)}
                rows={3}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowCommentActionDialog(false);
                  setEditingComment(null);
                }}
              >
                Cancel
              </Button>
              <Button 
                onClick={editingComment ? updateAddressedComment : submitCommentAction}
                variant={editingComment ? 'default' : commentAction === 'accept' ? 'default' : 'destructive'}
                disabled={!actionExplanation.trim()}
              >
                {editingComment 
                  ? 'Update Reply' 
                  : commentAction === 'accept' 
                    ? 'Accept' 
                    : 'Reject'
                } {!editingComment && 'Comment'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Citation Dialog */}
      <Dialog open={showCitationDialog} onOpenChange={setShowCitationDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Citation Details</DialogTitle>
          </DialogHeader>
          {selectedCitation && (
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-lg">{selectedCitation.title}</h3>
                <p className="text-muted-foreground">
                  {selectedCitation.authors.join(", ")} ({selectedCitation.year})
                </p>
                <p className="text-muted-foreground">{selectedCitation.journal}</p>
              </div>
              <div className="bg-muted p-3 rounded">
                <div className="text-sm font-medium mb-1">Highlighted text in manuscript:</div>
                <div className="text-sm italic">{selectedCitation.highlightedText}</div>
              </div>
              <div className="bg-muted p-3 rounded">
                <div className="text-sm font-medium mb-1">Full context:</div>
                <div className="text-sm">{selectedCitation.fullText}</div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}