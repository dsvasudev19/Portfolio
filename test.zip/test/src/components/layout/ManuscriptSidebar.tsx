import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Plus, 
  FileText, 
  MoreVertical,
  BookOpen,
  Eye,
  ChevronLeft,
  ChevronRight,
  Minimize2,
  Star
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CreateManuscriptDialog } from "../modals/CreateManuscriptDialog";
import { UnderReviewList } from "../under-review/UnderReviewList";
import { LiteratureList } from "../literature/LiteratureList";

interface Document {
  id: string;
  title: string;
  type: 'Research article' | 'Review' | 'Case report' | 'Editorial' | 'Conference proceedings' | 'Grant Proposal';
  lastModified: string;
  wordCount?: number;
  status?: 'draft' | 'under_review' | 'published';
  isStarred?: boolean;
}

interface ReviewDocument {
  id: string;
  title: string;
  journal: string;
  submittedDate: string;
  status: 'submitted' | 'under_review' | 'revision_required' | 'accepted' | 'rejected';
  reviewers: number;
  type: 'Research article' | 'Review' | 'Case report';
}

interface ManuscriptSidebarProps {
  selectedDocument: string | null;
  onSelectDocument: (id: string) => void;
  isMinimized: boolean;
  onToggleMinimize: () => void;
  onStarDocument?: (id: string) => void;
  onViewUnderReview?: (document: ReviewDocument) => void;
}

const mockDocuments: Document[] = [
  {
    id: '1',
    title: 'Gut Microbiota for Mental Health',
    type: 'Research article',
    lastModified: '12 June',
    wordCount: 2847,
    status: 'draft',
    isStarred: false
  },
  {
    id: '2',
    title: 'Psychological Impact of Social Media',
    type: 'Research article',
    lastModified: '8 June',
    wordCount: 1523,
    status: 'draft',
    isStarred: false
  },
  {
    id: '3',
    title: 'Research Proposal Draft',
    type: 'Grant Proposal',
    lastModified: '3 June',
    wordCount: 890,
    status: 'draft',
    isStarred: false
  }
];

export function ManuscriptSidebar({ 
  selectedDocument, 
  onSelectDocument, 
  isMinimized, 
  onToggleMinimize,
  onStarDocument,
  onViewUnderReview
}: ManuscriptSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [documents, setDocuments] = useState<Document[]>(mockDocuments);
  const [activeTab, setActiveTab] = useState("documents");
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  const handleViewUnderReview = (document: ReviewDocument) => {
    onViewUnderReview?.(document);
  };

  const toggleStar = (docId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDocuments(docs => docs.map(doc => 
      doc.id === docId ? { ...doc, isStarred: !doc.isStarred } : doc
    ));
    onStarDocument?.(docId);
  };

  const filteredDocuments = documents.filter(doc =>
    doc.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getTypeColor = (type: Document['type']) => {
    switch (type) {
      case 'Research article':
        return 'bg-blue-100 text-blue-800';
      case 'Review':
        return 'bg-purple-100 text-purple-800';
      case 'Case report':
        return 'bg-green-100 text-green-800';
      case 'Editorial':
        return 'bg-orange-100 text-orange-800';
      case 'Conference proceedings':
        return 'bg-red-100 text-red-800';
      case 'Grant Proposal':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isMinimized) {
    return (
      <div className="w-12 border-r bg-muted/30 flex flex-col items-center py-4">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onToggleMinimize}
          className="mb-4"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
        <div className="space-y-2">
          <Button variant="ghost" size="sm" className="w-8 h-8 p-0">
            <FileText className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="w-8 h-8 p-0">
            <BookOpen className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="w-8 h-8 p-0">
            <Eye className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 border-r bg-muted/30 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Button 
              className="gap-2" 
              size="sm"
              onClick={() => setShowCreateDialog(true)}
            >
              <Plus className="h-4 w-4" />
              New
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onToggleMinimize}
            >
              <Minimize2 className="h-4 w-4" />
            </Button>
          </div>
          <Button variant="ghost" size="sm">
            <MoreVertical className="h-4 w-4" />
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search..." 
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Horizontal Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="documents" className="text-xs">Documents</TabsTrigger>
            <TabsTrigger value="literature" className="text-xs">Literature</TabsTrigger>
            <TabsTrigger value="review" className="text-xs">Under Review</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        <Tabs value={activeTab} className="h-full">
          <TabsContent value="documents" className="h-full m-0">
            <div className="p-4 space-y-3">
              {filteredDocuments.map((doc) => (
                <div 
                  key={doc.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                    selectedDocument === doc.id 
                      ? 'bg-primary/10 border-primary' 
                      : 'hover:bg-muted/50'
                  }`}
                  onClick={() => onSelectDocument(doc.id)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-medium text-sm line-clamp-2">{doc.title}</h3>
                    <div className="flex items-center gap-1">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-6 w-6 p-0"
                        onClick={(e) => toggleStar(doc.id, e)}
                      >
                        <Star className={`h-3 w-3 ${doc.isStarred ? 'fill-yellow-400 text-yellow-400' : ''}`} />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-3 w-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Rename</DropdownMenuItem>
                          <DropdownMenuItem>Duplicate</DropdownMenuItem>
                          <DropdownMenuItem>Invite Co-author</DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                  
                  <Badge variant="secondary" className={`text-xs ${getTypeColor(doc.type)}`}>
                    {doc.type}
                  </Badge>
                  
                  <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                    <span>{doc.lastModified}</span>
                    {doc.wordCount && <span>{doc.wordCount.toLocaleString()} words</span>}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="literature" className="h-full m-0">
            <LiteratureList />
          </TabsContent>
          
          <TabsContent value="review" className="h-full m-0">
            <UnderReviewList 
              selectedDocument={selectedDocument}
              onSelectDocument={onSelectDocument}
              onViewDocument={handleViewUnderReview}
            />
          </TabsContent>
        </Tabs>
      </div>

      <CreateManuscriptDialog 
        open={showCreateDialog}
        onOpenChange={setShowCreateDialog}
      />
    </div>
  );
}