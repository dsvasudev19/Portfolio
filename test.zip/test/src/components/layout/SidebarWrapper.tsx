'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ManuscriptSidebar } from './ManuscriptSidebar';

export function SidebarWrapper() {
  const [selectedDocument, setSelectedDocument] = useState<string | null>(null);
  const [isMinimized, setIsMinimized] = useState(false);
  const router = useRouter();

  return (
    <ManuscriptSidebar
      selectedDocument={selectedDocument}
      onSelectDocument={(id) => {
        setSelectedDocument(id);
        router.push(`/documents/${id}`);
      }}
      isMinimized={isMinimized}
      onToggleMinimize={() => setIsMinimized(!isMinimized)}
      onViewUnderReview={(doc) => {
        router.push(`/under-review/${doc.id}`);
      }}
    />
  );
}
