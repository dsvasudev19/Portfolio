import { Progress } from "@/components/ui/progress";
import { Zap, Upload } from "lucide-react";

export function LimitBars() {
  const aiUsage = 75; // 75% used
  const uploadUsage = 45; // 45% used

  return (
    <div className="flex items-center gap-4">
      {/* AI Limit */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <Zap className="h-3 w-3" />
          <span className="text-xs">AI</span>
        </div>
        <Progress value={aiUsage} className="h-2 w-16" />
        <span className="text-xs text-muted-foreground">{aiUsage}/100</span>
      </div>

      {/* Upload Limit */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <Upload className="h-3 w-3" />
          <span className="text-xs">Upload</span>
        </div>
        <Progress value={uploadUsage} className="h-2 w-16" />
        <span className="text-xs text-muted-foreground">{uploadUsage}/100</span>
      </div>
    </div>
  );
}