import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, MessageSquare, Plus, ExternalLink } from "lucide-react";
import { useRouter } from "next/navigation";

interface LiteratureItem {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  type: 'journal' | 'conference' | 'book';
}

const mockLiterature: LiteratureItem[] = [
  {
    id: '1',
    title: 'Marker-assisted breeding for introgression of opaque-2 allele into elite maize inbred line BML-7',
    authors: 'Krishna, Reddy, Satyanarayana',
    journal: '3 biotech',
    year: 2017,
    type: 'journal'
  },
  {
    id: '2',
    title: 'Marker-assisted breeding for introgression of opaque-2 allele into elite maize inbred line BML-7',
    authors: 'Krishna, Reddy, Satyanarayana',
    journal: '3 biotech',
    year: 2017,
    type: 'journal'
  },
  {
    id: '3',
    title: 'Marker-assisted breeding for introgression of opaque-2 allele into elite maize inbred line BML-7',
    authors: 'Krishna, Reddy, Satyanarayana',
    journal: '3 biotech',
    year: 2017,
    type: 'journal'
  },
  {
    id: '4',
    title: 'Marker-assisted breeding for introgression of opaque-2 allele into elite maize inbred line BML-7',
    authors: 'Krishna, Reddy, Satyanarayana',
    journal: '3 biotech',
    year: 2017,
    type: 'journal'
  }
];

export function LiteratureList() {
    const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");
  const [literature] = useState<LiteratureItem[]>(mockLiterature);

  const filteredLiterature = literature.filter(item =>
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.authors.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getTypeIcon = (type: LiteratureItem['type']) => {
    switch (type) {
      case 'journal':
        return '📄';
      case 'conference':
        return '🎤';
      case 'book':
        return '📚';
      default:
        return '📄';
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search sources..." 
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {filteredLiterature.map((item) => (
          <div 
            key={item.id}
            className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
             onClick={() => router.push(`/literature/${item.id}`)}
          >
            <div className="flex items-start gap-3">
              <div className="text-2xl">{getTypeIcon(item.type)}</div>
              <div className="flex-1 space-y-2">
                <h3 className="font-medium text-sm leading-tight line-clamp-2">
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {item.authors}
                </p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>{item.journal}, {item.year}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}