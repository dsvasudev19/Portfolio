(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_44ca4603._.js",
  "static/chunks/node_modules_65745137._.js"
],
    source: "dynamic"
});
