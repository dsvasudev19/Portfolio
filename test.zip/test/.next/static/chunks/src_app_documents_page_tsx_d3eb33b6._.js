(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_bc54f9ba._.js",
  "static/chunks/src_3bee1277._.js"
],
    source: "dynamic"
});
