(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__7db745e8._.css",
  "static/chunks/node_modules_14c79e62._.js",
  "static/chunks/src_46618ce7._.js"
],
    source: "dynamic"
});
