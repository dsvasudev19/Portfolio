(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_2ee46f80._.js",
  "static/chunks/node_modules_0f31cf89._.js"
],
    source: "dynamic"
});
