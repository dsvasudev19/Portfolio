(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_457095fe._.js",
  "static/chunks/node_modules_87d7e944._.js"
],
    source: "dynamic"
});
