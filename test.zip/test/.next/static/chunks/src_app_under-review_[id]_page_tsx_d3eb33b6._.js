(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_4468e785._.js",
  "static/chunks/node_modules_69ec0c4b._.js"
],
    source: "dynamic"
});
