(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_3491e02c._.js",
  "static/chunks/node_modules_76a8b0f7._.js"
],
    source: "dynamic"
});
