(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_fb88db58._.js",
  "static/chunks/node_modules_ba36d6cf._.js"
],
    source: "dynamic"
});
