// import React, { useState, useEffect } from "react";
// import { Outlet, useLocation, useNavigate } from "react-router-dom";
// import {
//   Menu,
//   X,
//   ChevronLeft,
//   ChevronRight,
//   Bell,
//   Home,
//   Package,
//   Users,
//   Settings,
//   HelpCircle,
//   LogOut,
//   ShoppingCart,
//   CreditCard,
//   HeartHandshake,
//   BadgeIndianRupee,
//   SquarePen,
//   Tickets,
//   Tag,
//   Sun,
//   Moon,
// } from "lucide-react";

// const Dashboard = () => {
//   const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
//   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
//   const [isDarkMode, setIsDarkMode] = useState(false);
//   const location = useLocation();
//   const navigate = useNavigate();

//   // Extract the current active route segment after "/dashboard/"
//   const currentPath = location.pathname.split("/")[2] || "home"; // Adjusted to capture the segment after "/dashboard"

//   // Check if screen is mobile size
//   const [isMobile, setIsMobile] = useState(false);

//   useEffect(() => {
//     const handleResize = () => {
//       setIsMobile(window.innerWidth < 768);
//       if (window.innerWidth >= 768) {
//         setMobileMenuOpen(false);
//       }
//     };

//     handleResize();
//     window.addEventListener("resize", handleResize);

//     return () => {
//       window.removeEventListener("resize", handleResize);
//     };
//   }, []);

//   useEffect(() => {
//     // Check for system preference
//     if (
//       window.matchMedia &&
//       window.matchMedia("(prefers-color-scheme: dark)").matches
//     ) {
//       setIsDarkMode(true);
//       document.documentElement.classList.add("dark");
//     }

//     // Listen for changes
//     const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
//     const handleChange = (e) => {
//       setIsDarkMode(e.matches);
//       if (e.matches) {
//         document.documentElement.classList.add("dark");
//       } else {
//         document.documentElement.classList.remove("dark");
//       }
//     };

//     mediaQuery.addEventListener("change", handleChange);
//     return () => mediaQuery.removeEventListener("change", handleChange);
//   }, []);

//   const toggleDarkMode = () => {
//     setIsDarkMode(!isDarkMode);
//     if (isDarkMode) {
//       document.documentElement.classList.remove("dark");
//     } else {
//       document.documentElement.classList.add("dark");
//     }
//   };

//   // Menu items for e-commerce dashboard
//   const menuItems = [
//     {
//       id: "home",
//       label: "Dashboard",
//       icon: <Home size={20} />,
//       path: "/dashboard/home",
//     },
//     {
//       id: "bookings",
//       label: "Orders",
//       icon: <Package size={20} />,
//       path: "/dashboard/bookings",
//     },
//     {
//       id: "vehicles",
//       label: "Products",
//       icon: <ShoppingCart size={20} />,
//       path: "/dashboard/vehicles",
//     },
//     {
//       id: "users",
//       label: "Customers",
//       icon: <Users size={20} />,
//       path: "/dashboard/users",
//     },
//     {
//       id: "coupons",
//       icon: <CreditCard size={20} />,
//       label: "Coupons",
//       path: "/dashboard/coupons", // Changed from href to path
//     },
//     {
//       id: "deals",
//       icon: <HeartHandshake size={20} />,
//       label: "Deals or Offers",
//       path: "/dashboard/deals", // Changed from href to path
//     },
//     {
//       id: "transactions",
//       icon: <BadgeIndianRupee size={20} />,
//       label: "Transactions",
//       path: "/dashboard/transactions", // Changed from href to path
//     },
//     {
//       id: "reviews",
//       icon: <SquarePen size={20} />,
//       label: "Reviews",
//       path: "/dashboard/reviews", // Changed from href to path
//     },
//     {
//       id: "support",
//       icon: <Tickets size={20} />,
//       label: "Support",
//       path: "/dashboard/support", // Changed from href to path
//     },
//     {
//       id: "categories",
//       icon: <Tag size={20} />,
//       label: "Categories",
//       path: "/dashboard/categories", // Changed from href to path
//     },
//   ];

//   const toggleSidebar = () => {
//     setSidebarCollapsed(!sidebarCollapsed);
//   };

//   const toggleMobileMenu = () => {
//     setMobileMenuOpen(!mobileMenuOpen);
//   };

//   const navigateTo = (path) => {
//     navigate(path);
//     if (isMobile) {
//       setMobileMenuOpen(false);
//     }
//   };

//   return (
//     <div className="flex flex-col h-screen bg-neutral-50 dark:bg-primary-900 font-dramatic overflow-hidden">
//       {/* Main Header - Fixed at the top */}
//       <header className="bg-primary-900 dark:bg-primary-900 shadow-dramatic z-20">
//         {/* Main Header Bar */}
//         <div className="px-6 h-16 flex items-center justify-between">
//           {/* Left Section - Logo & Title */}
//           <div className="flex items-center">
//             <div className="flex items-center">
//               <span className="text-2xl font-dramatic font-medium text-neutral-50">
//                 Luxe
//               </span>
//               <span className="text-2xl font-dramatic text-accent-600">
//                 Commerce
//               </span>
//               <span className="ml-2 px-2 py-0.5 text-xs font-bold bg-crimson text-neutral-50 rounded">
//                 ADMIN
//               </span>
//             </div>
//           </div>

//           {/* Right Section - Actions & Profile */}
//           <div className="flex items-center space-x-5">
//             {/* System Status Indicator */}
//             <div className="hidden md:flex items-center">
//               <span className="h-2 w-2 rounded-full bg-green-400 mr-2"></span>
//               <span className="text-xs text-secondary-200">
//                 Platform Online
//               </span>
//             </div>

//             {/* Theme Toggle */}
//             <button
//               onClick={toggleDarkMode}
//               className="p-1.5 rounded-full text-neutral-50 bg-primary-800 hover:bg-accent-600 transition-colors duration-400 hover:scale-108 "
//             >
//               {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
//             </button>

//             {/* Notifications */}
//             <button className="p-1.5 rounded-full text-neutral-50 bg-primary-800 hover:bg-accent-600 transition-colors duration-400 hover:scale-108 relative">
//               <Bell size={18} />
//               <span className="absolute top-0 right-0 w-2 h-2 bg-crimson rounded-full"></span>
//             </button>

//             {/* Quick Settings */}
//             <button className="p-1.5 rounded-full text-neutral-50 bg-primary-800 hover:bg-accent-600 transition-colors duration-400 hover:scale-108">
//               <Settings size={18} />
//             </button>

//             {/* Profile */}
//             <div className="flex items-center cursor-pointer">
//               <div className="h-8 w-8 rounded-full bg-accent-600 flex items-center justify-center text-neutral-50 overflow-hidden">
//                 <Users size={16} />
//               </div>
//               <div className="ml-2 hidden md:block">
//                 <p className="text-neutral-50 text-sm font-medium">Admin</p>
//                 <p className="text-secondary-200 text-xs">E-Commerce Manager</p>
//               </div>
//             </div>

//             {/* Mobile menu button */}
//             <button
//               onClick={toggleMobileMenu}
//               className="md:hidden p-1.5 rounded-full text-neutral-50 hover:bg-accent-600 transition-colors duration-400"
//             >
//               <Menu size={22} />
//             </button>
//           </div>
//         </div>
//       </header>

//       {/* Content Area with Sidebar and Main Content */}
//       <div className="flex flex-1 overflow-hidden">
//         {/* Sidebar - Desktop */}
//         <aside
//           className={`${
//             sidebarCollapsed ? "w-16" : "w-64"
//           } hidden md:block bg-neutral-50 dark:bg-primary-900 border-r border-primary-800 dark:border-primary-800 transition-all duration-400 ease-in-out z-10 shadow-dramatic`}
//         >
//           <div className="flex flex-col h-full">
//             {/* Sidebar Toggle Button */}
//             <div className="flex justify-end px-4 py-2 border-b border-primary-800 dark:border-primary-800">
//               <button
//                 onClick={toggleSidebar}
//                 className="p-1.5 rounded-full text-crimson hover:bg-accent-50 dark:hover:bg-primary-800 transition-colors duration-400 hover:scale-108"
//               >
//                 {sidebarCollapsed ? (
//                   <ChevronRight size={20} />
//                 ) : (
//                   <ChevronLeft size={20} />
//                 )}
//               </button>
//             </div>

//             {/* Navigation Menu */}
//             <nav className="flex-1 overflow-y-auto py-3">
//               <div
//                 className={`${!sidebarCollapsed ? "px-4 py-2" : "px-3 py-2"}`}
//               >
//                 <span className="text-xs font-medium text-crimson dark:text-secondary-200 uppercase">
//                   {!sidebarCollapsed ? "Main Navigation" : ""}
//                 </span>
//               </div>
//               <ul className="space-y-1 px-3">
//                 {menuItems.map((item) => (
//                   <li key={item.id}>
//                     <button
//                       onClick={() => navigateTo(item.path)}
//                       className={`flex items-center w-full px-3 py-2 rounded-lg text-left transition-colors duration-400 hover:bg-accent-50 dark:hover:bg-primary-800 hover:scale-102 ${
//                         currentPath === item.id
//                           ? "dark:bg-primary-800 text-primary-900 dark:text-neutral-50 border-2 border-burgundy"
//                           : "text-crimson dark:text-secondary-200"
//                       }`}
//                     >
//                       <span
//                         className={`${
//                           currentPath === item.id
//                             ? "text-accent-600 dark:text-accent-600"
//                             : "text-crimson dark:text-secondary-200"
//                         }`}
//                       >
//                         {item.icon}
//                       </span>
//                       {!sidebarCollapsed && (
//                         <span
//                           className={`ml-3 ${
//                             currentPath === item.id ? "font-medium" : ""
//                           }`}
//                         >
//                           {item.label}
//                         </span>
//                       )}
//                     </button>
//                   </li>
//                 ))}
//               </ul>
//             </nav>

//             {/* Sidebar Footer */}
//             <div className="border-t border-primary-800 dark:border-primary-800 py-4 px-3">
//               {!sidebarCollapsed ? (
//                 <>
//                   <button className="flex items-center w-full px-3 py-2 text-crimson dark:text-secondary-200 hover:bg-accent-50 dark:hover:bg-primary-800 rounded-lg transition-colors duration-400 hover:scale-102">
//                     <HelpCircle size={20} />
//                     <span className="ml-3">Help & Support</span>
//                   </button>
//                   <button className="flex items-center w-full px-3 py-2 text-crimson dark:text-crimson hover:bg-accent-50 dark:hover:bg-primary-800 rounded-lg transition-colors duration-400 hover:scale-102">
//                     <LogOut size={20} />
//                     <span className="ml-3">Sign Out</span>
//                   </button>
//                 </>
//               ) : (
//                 <>
//                   <button className="flex justify-center w-full p-2 text-crimson dark:text-secondary-200 hover:bg-accent-50 dark:hover:bg-primary-800 rounded-lg transition-colors duration-400 hover:scale-102">
//                     <HelpCircle size={20} />
//                   </button>
//                   <button className="flex justify-center w-full p-2 text-crimson dark:text-crimson hover:bg-accent-50 dark:hover:bg-primary-800 rounded-lg transition-colors duration-400 hover:scale-102">
//                     <LogOut size={20} />
//                   </button>
//                 </>
//               )}
//             </div>
//           </div>
//         </aside>

//         {/* Mobile Sidebar - Overlay */}
//         {mobileMenuOpen && (
//           <div className="md:hidden fixed inset-0 z-50">
//             {/* Backdrop */}
//             <div
//               className="fixed inset-0 bg-primary-900/50 backdrop-blur-sm transition-opacity"
//               onClick={toggleMobileMenu}
//             ></div>

//             {/* Sidebar Menu */}
//             <div className="fixed inset-y-0 left-0 w-3/4 max-w-xs bg-neutral-50 dark:bg-primary-900 shadow-dramatic flex flex-col">
//               <div className="flex items-center justify-between h-16 px-4 border-b border-primary-800 dark:border-primary-800">
//                 <div className="flex items-center">
//                   <span className="text-xl font-dramatic font-medium text-primary-900 dark:text-neutral-50">
//                     Luxe
//                   </span>
//                   <span className="text-xl font-dramatic text-accent-600 dark:text-accent-600">
//                     Commerce
//                   </span>
//                   <span className="ml-2 px-1.5 py-0.5 text-xs font-bold bg-crimson text-neutral-50 rounded">
//                     ADMIN
//                   </span>
//                 </div>
//                 <button
//                   onClick={toggleMobileMenu}
//                   className="p-1.5 rounded-full hover:bg-accent-50 dark:hover:bg-primary-800 text-crimson dark:text-secondary-200"
//                 >
//                   <X size={22} />
//                 </button>
//               </div>

//               {/* Mobile Navigation Menu */}
//               <nav className="flex-1 overflow-y-auto py-4">
//                 <div className="px-4 py-2">
//                   <span className="text-xs font-medium text-crimson dark:text-secondary-200 uppercase">
//                     Main Navigation
//                   </span>
//                 </div>
//                 <ul className="space-y-1 px-3">
//                   {menuItems.map((item) => (
//                     <li key={item.id}>
//                       <button
//                         onClick={() => navigateTo(item.path)}
//                         className={`flex items-center w-full px-3 py-2 rounded-lg text-left transition-colors duration-400 hover:bg-accent-50 dark:hover:bg-primary-800 hover:scale-102 ${
//                           currentPath === item.id
//                             ? "bg-accent-50 dark:bg-primary-800 text-primary-900 dark:text-neutral-50"
//                             : "text-crimson dark:text-secondary-200"
//                         }`}
//                       >
//                         <span
//                           className={`${
//                             currentPath === item.id
//                               ? "text-accent-600 dark:text-accent-600"
//                               : "text-crimson dark:text-secondary-200"
//                           }`}
//                         >
//                           {item.icon}
//                         </span>
//                         <span
//                           className={`ml-3 ${
//                             currentPath === item.id ? "font-medium" : ""
//                           }`}
//                         >
//                           {item.label}
//                         </span>
//                       </button>
//                     </li>
//                   ))}
//                 </ul>
//               </nav>

//               {/* Mobile Sidebar Footer */}
//               <div className="border-t border-primary-800 dark:border-primary-800 p-4 space-y-2">
//                 <button className="flex items-center w-full px-3 py-2 text-crimson dark:text-secondary-200 hover:bg-accent-50 dark:hover:bg-primary-800 rounded-lg transition-colors duration-400 hover:scale-102">
//                   <HelpCircle size={20} />
//                   <span className="ml-3">Help & Support</span>
//                 </button>
//                 <button className="flex items-center w-full px-3 py-2 text-crimson dark:text-crimson hover:bg-accent-50 dark:hover:bg-primary-800 rounded-lg transition-colors duration-400 hover:scale-102">
//                   <LogOut size={20} />
//                   <span className="ml-3">Sign Out</span>
//                 </button>
//               </div>
//             </div>
//           </div>
//         )}

//         {/* Main Content Area */}
//         <div className="flex flex-col flex-1 overflow-hidden">
//           {/* Main Content */}
//           <main className="flex-1 overflow-auto bg-neutral-50 dark:bg-primary-900 p-6">
//             <div className="mx-auto">
//               <Outlet />
//             </div>
//           </main>
//         </div>
//       </div>

//       {/* Status bar */}
//       <div className="h-6 bg-neutral-50 dark:bg-primary-900 border-t border-primary-800 dark:border-primary-800 px-4 flex items-center justify-between text-xs text-crimson dark:text-secondary-200">
//         <div>© 2025 LuxeCommerce - Admin Console</div>
//         <div className="flex items-center">
//           <span className="flex items-center mr-4">
//             <span className="h-1.5 w-1.5 rounded-full bg-green-500 mr-1"></span>
//             Inventory: Synced
//           </span>
//           <span className="flex items-center mr-4">
//             <span className="h-1.5 w-1.5 rounded-full bg-green-500 mr-1"></span>
//             Orders: Live
//           </span>
//           <span>Last updated: 15 Jul 2025</span>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;

import React, { useState, useEffect } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  Bell,
  Home,
  Package,
  Users,
  Settings,
  HelpCircle,
  LogOut,
  ShoppingCart,
  CreditCard,
  HeartHandshake,
  BadgeIndianRupee,
  SquarePen,
  Ticket,
  Tag,
  Sun,
  Moon,
  User,
  UserCog,
  LayoutDashboard,
} from "lucide-react";
import { useAuth } from "../../AuthContext";

const Dashboard = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // Extract the current active route segment after "/dashboard/"
  const currentPath = location.pathname.split("/")[2] || "home";

  // Check if screen is mobile size
  const [isMobile, setIsMobile] = useState(false);

  const { user, isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth >= 768) {
        setMobileMenuOpen(false);
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  useEffect(() => {
    // Check for system preference
    if (
      window.matchMedia &&
      window.matchMedia("(prefers-color-scheme: dark)").matches
    ) {
      setIsDarkMode(true);
      document.documentElement.classList.add("dark");
    }

    // Listen for changes
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleChange = (e) => {
      setIsDarkMode(e.matches);
      if (e.matches) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    };

    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    if (isDarkMode) {
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.add("dark");
    }
  };

  // Menu items for e-commerce dashboard
  const menuItems = [
    {
      id: "home",
      label: "Dashboard",
      icon: <Home size={20} />,
      path: "/dashboard/home",
    },
    {
      id: "orders",
      label: "Orders",
      icon: <Package size={20} />,
      path: "/dashboard/orders",
    },
    {
      id: "products",
      label: "Products",
      icon: <ShoppingCart size={20} />,
      path: "/dashboard/products",
    },
    {
      id: "users",
      label: "Customers",
      icon: <Users size={20} />,
      path: "/dashboard/users",
    },
    {
      id: "coupons",
      icon: <CreditCard size={20} />,
      label: "Coupons",
      path: "/dashboard/coupons",
    },
    // {
    //   id: "deals",
    //   icon: <HeartHandshake size={20} />,
    //   label: "Deals or Offers",
    //   path: "/dashboard/deals",
    // },
    {
      id: "transactions",
      icon: <BadgeIndianRupee size={20} />,
      label: "Transactions",
      path: "/dashboard/transactions",
    },
    {
      id: "reviews",
      icon: <SquarePen size={20} />,
      label: "Reviews",
      path: "/dashboard/reviews",
    },
    // {
    //   id: "support",
    //   icon: <Ticket size={20} />,
    //   label: "Support",
    //   path: "/dashboard/support",
    // },
    {
      id: "categories",
      icon: <LayoutDashboard size={20} />,
      label: "Categories",
      path: "/dashboard/categories",
    },
    {
      id: "wallets",
      icon: <CreditCard size={20} />,
      label: "Wallets",
      path: "/dashboard/wallets",
    },
    {
      id: "vendors",
      icon: <UserCog size={20} />,
      label: "Vendors",
      path: "/dashboard/vendors",
    },
  ];

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const navigateTo = (path) => {
    navigate(path);
    if (isMobile) {
      setMobileMenuOpen(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-neutral-50 dark:bg-primary-900 font-dramatic overflow-hidden">
      {/* Main Header - Fixed at the top */}
      <header className="bg-primary-900 dark:bg-primary-900 shadow-2xl z-20 relative">
        {/* Subtle gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary-900 via-primary-800 to-primary-900 opacity-50"></div>

        {/* Main Header Bar */}
        <div className="relative px-6 h-16 flex items-center justify-between">
          {/* Left Section - Logo & Title */}
          <div className="flex items-center">
            <div className="flex items-center">
              <span className="text-2xl font-dramatic font-medium text-neutral-50 drop-shadow-sm">
                E-
              </span>
              <span className="text-2xl font-dramatic text-accent-600 drop-shadow-sm">
                Commerce
              </span>
              <span className="ml-2 px-2 py-0.5 text-xs font-bold bg-crimson text-neutral-50 rounded shadow-lg">
                ADMIN
              </span>
            </div>
          </div>

          {/* Right Section - Actions & Profile */}
          <div className="flex items-center space-x-5">
            {/* System Status Indicator */}
            <div className="hidden md:flex items-center bg-primary-800/30 px-3 py-1 rounded-full backdrop-blur-sm">
              <span className="h-2 w-2 rounded-full bg-green-400 mr-2 animate-pulse"></span>
              <span className="text-xs text-secondary-200 font-medium">
                Platform Online
              </span>
            </div>

            {/* Theme Toggle */}
            {/* <button
              onClick={toggleDarkMode}
              className="p-1.5 rounded-full text-neutral-50 bg-primary-800/50 hover:bg-accent-600 transition-all duration-300 hover:scale-110 shadow-lg backdrop-blur-sm"
            >
              {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button> */}

            {/* Notifications */}
            {/* <button className="p-1.5 rounded-full text-neutral-50 bg-primary-800/50 hover:bg-accent-600 transition-all duration-300 hover:scale-110 relative shadow-lg backdrop-blur-sm">
              <Bell size={18} />
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-crimson rounded-full animate-pulse shadow-sm"></span>
            </button> */}

            {/* Quick Settings */}
            <button
              onClick={() => {
                window.location.href = "settings";
              }}
              className="p-1.5 rounded-full text-neutral-50 bg-primary-800/50 hover:bg-accent-600 transition-all duration-300 hover:scale-110 shadow-lg backdrop-blur-sm"
            >
              <Settings size={18} />
            </button>

            {/* Profile */}
            <div className="flex items-center cursor-pointer hover:bg-primary-800/30 px-3 py-1 rounded-full transition-all duration-300 backdrop-blur-sm">
              <div className="h-8 w-8 rounded-full bg-gradient-to-br from-accent-600 to-accent-700 flex items-center justify-center text-neutral-50 overflow-hidden shadow-lg">
                <Users size={16} />
              </div>
              <div className="ml-2 hidden md:block">
                {
                  user && !isLoading && (<p className="text-neutral-50 text-sm font-medium">
                  {user?.fullName}
                </p>)
                }
                {user && !isLoading && (
                  <p className="text-secondary-200 text-xs">
                    {user.email}
                  </p>
                )}
              </div>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={toggleMobileMenu}
              className="md:hidden p-1.5 rounded-full text-neutral-50 hover:bg-accent-600 transition-all duration-300 shadow-lg backdrop-blur-sm"
            >
              <Menu size={22} />
            </button>
          </div>
        </div>
      </header>

      {/* Content Area with Sidebar and Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Desktop */}
        <aside
          className={`${
            sidebarCollapsed ? "w-24" : "w-64"
          } hidden md:block bg-neutral-50 dark:bg-primary-900 border-r border-primary-800/20 dark:border-primary-800/30 transition-all duration-400 ease-in-out z-10 shadow-2xl relative`}
        >
          {/* Sidebar gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-neutral-50 via-neutral-50 to-neutral-100 dark:from-primary-900 dark:via-primary-900 dark:to-primary-800 opacity-50"></div>

          <div className="flex flex-col h-full relative">
            {/* Sidebar Toggle Button */}
            <div className="flex justify-end px-4 py-3 border-b border-primary-800/20 dark:border-primary-800/30">
              <button
                onClick={toggleSidebar}
                className="p-2 rounded-full text-crimson hover:bg-accent-50 dark:hover:bg-primary-800/50 transition-all duration-300 hover:scale-110 shadow-md backdrop-blur-sm"
              >
                {sidebarCollapsed ? (
                  <ChevronRight size={20} />
                ) : (
                  <ChevronLeft size={20} />
                )}
              </button>
            </div>

            {/* Navigation Menu */}
            <nav className="flex-1 overflow-y-auto py-2">
              <div
                className={`${!sidebarCollapsed ? "px-4 py-2" : "px-3 py-2"}`}
              >
                <span className="text-xs font-semibold text-crimson dark:text-secondary-200 uppercase tracking-wider">
                  {!sidebarCollapsed ? "Main Navigation" : ""}
                </span>
              </div>
              <ul className="space-y-2 px-3">
                {menuItems.map((item) => (
                  <li key={item.id}>
                    <button
                      onClick={() => navigateTo(item.path)}
                      className={`relative flex items-center w-full px-2 py-1.5 rounded-xl text-left transition-all duration-300 group ${
                        currentPath === item.id
                          ? "bg-accent-50 dark:bg-primary-800 text-primary-900 dark:text-neutral-50 border border-burgundy"
                          : "text-crimson dark:text-secondary-200 hover:bg-accent-50/50 dark:hover:bg-primary-800/50 hover:scale-102 hover:shadow-md"
                      }`}
                    >
                      {/* Active indicator dot */}
                      {currentPath === item.id && (
                        <div className="absolute right-2 top-1/2 transform -translate-y-1/2 w-2 h-5 bg-burgundy rounded-full"></div>
                      )}

                      {/* Icon container with enhanced styling */}
                      <div
                        className={`flex items-center justify-center w-8 h-8 rounded-lg transition-all duration-300 ${
                          currentPath === item.id
                            ? "bg-gradient-to-br from-accent-600 to-accent-700 text-neutral-50 shadow-lg"
                            : "text-crimson dark:text-secondary-200 group-hover:bg-accent-100 dark:group-hover:bg-primary-700"
                        }`}
                      >
                        {item.icon}
                      </div>

                      {!sidebarCollapsed && (
                        <span
                          className={`ml-3 transition-all duration-300 ${
                            currentPath === item.id
                              ? "font-semibold"
                              : "font-medium"
                          }`}
                        >
                          {item.label}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </nav>

            {/* Sidebar Footer */}
            <div className="border-t border-primary-800/20 dark:border-primary-800/30 py-4 px-3">
              {!sidebarCollapsed ? (
                <>
                  <button
                    onClick={() => {
                      window.location.href = "help-and-support";
                    }}
                    className="flex items-center w-full px-3 py-1.5 text-crimson dark:text-secondary-200 hover:bg-accent-50/50 dark:hover:bg-primary-800/50 rounded-xl transition-all duration-300 hover:scale-102 hover:shadow-md group"
                  >
                    <div className="flex items-center justify-center w-8 h-8 rounded-lg group-hover:bg-accent-100 dark:group-hover:bg-primary-700 transition-all duration-300">
                      <HelpCircle size={20} />
                    </div>
                    <span className="ml-3 font-medium">Help & Support</span>
                  </button>
                  <button className="flex items-center w-full px-3 py-1.5 text-crimson dark:text-crimson hover:bg-accent-50/50 dark:hover:bg-primary-800/50 rounded-xl transition-all duration-300 hover:scale-102 hover:shadow-md group">
                    <div className="flex items-center justify-center w-8 h-8 rounded-lg group-hover:bg-accent-100 dark:group-hover:bg-primary-700 transition-all duration-300">
                      <LogOut size={20} />
                    </div>
                    <span className="ml-3 font-medium">Sign Out</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => {
                      window.location.href = "help-and-support";
                    }}
                    className="flex justify-center w-full p-1.5 text-crimson dark:text-secondary-200 hover:bg-accent-50/50 dark:hover:bg-primary-800/50 rounded-xl transition-all duration-300 hover:scale-102 hover:shadow-md"
                  >
                    <HelpCircle size={20} />
                  </button>
                  <button className="flex justify-center w-full p-1.5 text-crimson dark:text-crimson hover:bg-accent-50/50 dark:hover:bg-primary-800/50 rounded-xl transition-all duration-300 hover:scale-102 hover:shadow-md">
                    <LogOut size={20} />
                  </button>
                </>
              )}
            </div>
          </div>
        </aside>

        {/* Mobile Sidebar - Overlay */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-50">
            {/* Backdrop */}
            <div
              className="fixed inset-0 bg-primary-900/60 backdrop-blur-sm transition-opacity"
              onClick={toggleMobileMenu}
            ></div>

            {/* Sidebar Menu */}
            <div className="fixed inset-y-0 left-0 w-3/4 max-w-xs bg-neutral-50 dark:bg-primary-900 shadow-2xl flex flex-col">
              <div className="flex items-center justify-between h-16 px-4 border-b border-primary-800/20 dark:border-primary-800/30 bg-gradient-to-r from-neutral-50 to-neutral-100 dark:from-primary-900 dark:to-primary-800">
                <div className="flex items-center">
                  <span className="text-xl font-dramatic font-medium text-primary-900 dark:text-neutral-50">
                    E-
                  </span>
                  <span className="text-xl font-dramatic text-accent-600 dark:text-accent-600">
                    Commerce
                  </span>
                  <span className="ml-2 px-1.5 py-0.5 text-xs font-bold bg-crimson text-neutral-50 rounded shadow-lg">
                    ADMIN
                  </span>
                </div>
                <button
                  onClick={toggleMobileMenu}
                  className="p-1.5 rounded-full hover:bg-accent-50 dark:hover:bg-primary-800/50 text-crimson dark:text-secondary-200 transition-all duration-300"
                >
                  <X size={22} />
                </button>
              </div>

              {/* Mobile Navigation Menu */}
              <nav className="flex-1 overflow-y-auto py-4">
                <div className="px-4 py-2">
                  <span className="text-xs font-semibold text-crimson dark:text-secondary-200 uppercase tracking-wider">
                    Main Navigation
                  </span>
                </div>
                <ul className="space-y-2 px-3">
                  {menuItems.map((item) => (
                    <li key={item.id}>
                      <button
                        onClick={() => navigateTo(item.path)}
                        className={`relative flex items-center w-full px-3 py-2.5 rounded-xl text-left transition-all duration-300 group ${
                          currentPath === item.id
                            ? "bg-accent-50 dark:bg-primary-800 text-primary-900 dark:text-neutral-50 border border-burgundy"
                            : "text-crimson dark:text-secondary-200 hover:bg-accent-50/50 dark:hover:bg-primary-800/50 hover:scale-102 hover:shadow-md"
                        }`}
                      >
                        {/* Active indicator dot */}
                        {currentPath === item.id && (
                          <div className="absolute right-2 top-1/2 transform -translate-y-1/2 w-2 h-4 bg-burgundy rounded-full"></div>
                        )}

                        {/* Icon container with enhanced styling */}
                        <div
                          className={`flex items-center justify-center w-8 h-8 rounded-lg transition-all duration-300 ${
                            currentPath === item.id
                              ? "bg-gradient-to-br from-accent-600 to-accent-700 text-neutral-50 shadow-lg"
                              : "text-crimson dark:text-secondary-200 group-hover:bg-accent-100 dark:group-hover:bg-primary-700"
                          }`}
                        >
                          {item.icon}
                        </div>

                        <span
                          className={`ml-3 transition-all duration-300 ${
                            currentPath === item.id
                              ? "font-semibold"
                              : "font-medium"
                          }`}
                        >
                          {item.label}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </nav>

              {/* Mobile Sidebar Footer */}
              <div className="border-t border-primary-800/20 dark:border-primary-800/30 p-4 space-y-2">
                <button className="flex items-center w-full px-3 py-2.5 text-crimson dark:text-secondary-200 hover:bg-accent-50/50 dark:hover:bg-primary-800/50 rounded-xl transition-all duration-300 hover:scale-102 hover:shadow-md group">
                  <div className="flex items-center justify-center w-8 h-8 rounded-lg group-hover:bg-accent-100 dark:group-hover:bg-primary-700 transition-all duration-300">
                    <HelpCircle size={20} />
                  </div>
                  <span className="ml-3 font-medium">Help & Support</span>
                </button>
                <button className="flex items-center w-full px-3 py-2.5 text-crimson dark:text-crimson hover:bg-accent-50/50 dark:hover:bg-primary-800/50 rounded-xl transition-all duration-300 hover:scale-102 hover:shadow-md group">
                  <div className="flex items-center justify-center w-8 h-8 rounded-lg group-hover:bg-accent-100 dark:group-hover:bg-primary-700 transition-all duration-300">
                    <LogOut size={20} />
                  </div>
                  <span className="ml-3 font-medium">Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex flex-col flex-1 overflow-hidden">
          {/* Main Content */}
          <main className="flex-1 overflow-auto bg-neutral-50 dark:bg-primary-900 p-6">
            <div className="mx-auto">
              <Outlet />
            </div>
          </main>
        </div>
      </div>

      {/* Status bar */}
      <div className="h-6 bg-gradient-to-r from-neutral-50 via-neutral-100 to-neutral-50 dark:from-primary-900 dark:via-primary-800 dark:to-primary-900 border-t border-primary-800/20 dark:border-primary-800/30 px-4 flex items-center justify-between text-xs text-crimson dark:text-secondary-200 shadow-lg">
        <div className="font-medium">© 2025 Commerce - Admin Console</div>
        <div className="flex items-center space-x-4">
          <span className="flex items-center">
            <span className="h-1.5 w-1.5 rounded-full bg-green-500 mr-1 animate-pulse"></span>
            <span className="font-medium">Inventory: Synced</span>
          </span>
          <span className="flex items-center">
            <span className="h-1.5 w-1.5 rounded-full bg-green-500 mr-1 animate-pulse"></span>
            <span className="font-medium">Orders: Live</span>
          </span>
          <span className="font-medium">Last updated: 15 Jul 2025</span>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
