import {
  BadgeIndianRupee,
  PackageSearch,
  ChartNoAxesColumnDecreasing,
  CreditCard,
  LayoutDashboard,
  SquarePen,
  Users,
  Tickets,
  CalendarHeart,
  HeartHandshake,
  X,
  Menu,
  Component,
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
  currentPath: string;
}

const sidebarItems = [
  {
    icon: LayoutDashboard,
    label: "Dashboard",
    href: "/dashboard/home",
  },
  {
    icon: ChartNoAxesColumnDecreasing,
    label: "Orders",
    href: "/dashboard/bookings",
  },
  {
    icon: Users,
    label: "Users",
    href: "/dashboard/users",
  },
  {
    icon: Component,
    label: "Categories",
    href: "/dashboard/categories",
  },
  {
    icon: PackageSearch,
    label: "Products",
    href: "/dashboard/vehicles",
  },
  {
    icon: CreditCard,
    label: "Coupons",
    href: "/dashboard/coupons",
  },
  {
    icon: HeartHandshake,
    label: "Deals or Offers",
    href: "/dashboard/deals",
  },
  {
    icon: BadgeIndianRupee,
    label: "Transactions",
    href: "/dashboard/transactions",
  },
  {
    icon: SquarePen,
    label: "Reviews",
    href: "/dashboard/reviews",
  },
  {
    icon: Tickets,
    label: "Support",
    href: "/dashboard/support",
  },
  {
    icon: CalendarHeart,
    label: "News Letter Subscriptions",
    href: "/dashboard/subscriptions",
  }
];

const Sidebar = ({ isOpen, toggleSidebar, currentPath }: SidebarProps) => {
  return (
    <>
      {/* Mobile Sidebar Toggle */}
      <button 
        onClick={toggleSidebar}
        className="fixed top-4 left-4 z-50 p-2 bg-gradient-to-r from-rose-800 to-amber-700 text-white rounded-full shadow-lg hover:opacity-90 transition-opacity sm:hidden"
      >
        {isOpen ? <X /> : <Menu />}
      </button>
      
      {/* Sidebar */}
      <aside 
        className={`
          fixed inset-y-0 left-0 z-40 w-64 bg-white/90 backdrop-blur-md shadow-2xl rounded-r-3xl transform transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
          sm:relative sm:translate-x-0
        `}
      >
        <div className="h-full overflow-y-auto py-6 px-4">
          {/* Logo or Brand */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-rose-800 to-amber-700 hover:from-amber-700 hover:to-rose-800 transition-all duration-300 drop-shadow-lg">
              Dashboard
            </h1>
            {/* <div className="h-[2px] w-32 bg-gradient-to-r from-rose-800/40 to-amber-700/40 mt-1 rounded-full"></div> */}
          </div>
          <nav>
            <ul className="space-y-2">
              {sidebarItems.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className={`
                      flex items-center p-[6px] transition-all duration-200 group
                      ${currentPath === item.href 
                        ? 'bg-gradient-to-r from-rose-800 to-amber-700 text-white' 
                        : 'text-gray-700 hover:bg-rose-50 hover:text-rose-800'}
                    `}
                  >
                    <item.icon 
                      className={`
                        w-5 h-5 transition-all duration-200
                        ${currentPath === item.href 
                          ? 'text-white' 
                          : 'text-amber-700 group-hover:scale-110 group-hover:text-rose-800'}
                      `} 
                    />
                    <span className="ml-3 font-medium">{item.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
