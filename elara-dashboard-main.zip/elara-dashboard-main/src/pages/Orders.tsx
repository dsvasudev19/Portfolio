// import React, { useState } from 'react';
// import { ChevronDown, ChevronUp, Package, CreditCard, Tag, User, Calendar, MapPin, TrendingUp, ShoppingCart, DollarSign, Clock } from 'lucide-react';

// const OrderManagement = () => {
//   const [expandedRows, setExpandedRows] = useState({});
//   const [activeAccordion, setActiveAccordion] = useState({});

//   const toggleRow = (orderId) => {
//     setExpandedRows(prev => ({
//       ...prev,
//       [orderId]: !prev[orderId]
//     }));
//   };

//   const toggleAccordion = (orderId, type) => {
//     setActiveAccordion(prev => ({
//       ...prev,
//       [`${orderId}-${type}`]: !prev[`${orderId}-${type}`]
//     }));
//   };

//   const orders = [
//     {
//       id: 'ORD-2024-001',
//       customer: 'Alexandra Sterling',
//       date: '2024-07-12',
//       status: 'Delivered',
//       total: 1247.99,
//       coupon: { code: 'SUMMER25', discount: 312.00 },
//       address: '425 Park Ave, New York, NY 10022',
//       products: [
//         {
//           id: 'PRD-001',
//           name: 'Premium Leather Briefcase',
//           sku: 'LB-2024-BLK',
//           quantity: 1,
//           price: 799.99,
//           image: '🎒'
//         },
//         {
//           id: 'PRD-002',
//           name: 'Executive Pen Set',
//           sku: 'PS-2024-GLD',
//           quantity: 2,
//           price: 124.99,
//           image: '✒️'
//         },
//         {
//           id: 'PRD-003',
//           name: 'Silk Pocket Square',
//           sku: 'SQ-2024-NVY',
//           quantity: 3,
//           price: 89.99,
//           image: '👔'
//         }
//       ],
//       transactions: [
//         {
//           id: 'TXN-001',
//           type: 'Payment',
//           method: 'Visa ****4532',
//           amount: 1247.99,
//           status: 'Completed',
//           timestamp: '2024-07-12 14:23:45'
//         },
//         {
//           id: 'TXN-002',
//           type: 'Refund',
//           method: 'Visa ****4532',
//           amount: -45.00,
//           status: 'Processed',
//           timestamp: '2024-07-13 09:15:22'
//         }
//       ]
//     },
//     {
//       id: 'ORD-2024-002',
//       customer: 'Marcus Chen',
//       date: '2024-07-14',
//       status: 'Processing',
//       total: 2156.50,
//       address: '1200 5th Ave, Seattle, WA 98101',
//       products: [
//         {
//           id: 'PRD-004',
//           name: 'Mahogany Executive Desk',
//           sku: 'DK-2024-MAH',
//           quantity: 1,
//           price: 1899.99,
//           image: '🪑'
//         },
//         {
//           id: 'PRD-005',
//           name: 'Ergonomic Desk Lamp',
//           sku: 'LM-2024-BRS',
//           quantity: 1,
//           price: 256.51,
//           image: '💡'
//         }
//       ],
//       transactions: [
//         {
//           id: 'TXN-003',
//           type: 'Payment',
//           method: 'Amex ****1009',
//           amount: 2156.50,
//           status: 'Completed',
//           timestamp: '2024-07-14 11:45:33'
//         }
//       ]
//     },
//     {
//       id: 'ORD-2024-003',
//       customer: 'Isabella Rodriguez',
//       date: '2024-07-15',
//       status: 'Pending',
//       total: 567.75,
//       address: '890 Market St, San Francisco, CA 94102',
//       products: [
//         {
//           id: 'PRD-006',
//           name: 'Italian Leather Portfolio',
//           sku: 'PF-2024-TAN',
//           quantity: 1,
//           price: 345.00,
//           image: '📁'
//         },
//         {
//           id: 'PRD-007',
//           name: 'Mont Blanc Fountain Pen',
//           sku: 'FP-2024-BLK',
//           quantity: 1,
//           price: 222.75,
//           image: '🖋️'
//         }
//       ],
//       transactions: [
//         {
//           id: 'TXN-004',
//           type: 'Authorization',
//           method: 'Mastercard ****7843',
//           amount: 567.75,
//           status: 'Pending',
//           timestamp: '2024-07-15 16:30:12'
//         }
//       ]
//     }
//   ];

//   const metrics = [
//     {
//       title: 'Total Orders',
//       value: orders.length,
//       icon: ShoppingCart,
//       color: '#335C67'
//     },
//     {
//       title: 'Total Revenue',
//       value: `₹${orders.reduce((sum, order) => sum + order.total, 0).toFixed(2)}`,
//       icon: DollarSign,
//       color: '#E09F3E'
//     },
//     {
//       title: 'Avg Order Value',
//       value: `₹${(orders.reduce((sum, order) => sum + order.total, 0) / orders.length).toFixed(2)}`,
//       icon: TrendingUp,
//       color: '#9E2A2B'
//     },
//     {
//       title: 'Pending Orders',
//       value: orders.filter(order => order.status === 'Pending').length,
//       icon: Clock,
//       color: '#540B0E'
//     }
//   ];

//   const getStatusColor = (status) => {
//     switch (status) {
//       case 'Delivered': return 'bg-green-100 text-green-800 border-green-200';
//       case 'Processing': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
//       case 'Pending': return 'bg-red-100 text-red-800 border-red-200';
//       default: return 'bg-gray-100 text-gray-800 border-gray-200';
//     }
//   };

//   const getTransactionColor = (type) => {
//     switch (type) {
//       case 'Payment': return '#335C67';
//       case 'Refund': return '#9E2A2B';
//       case 'Authorization': return '#E09F3E';
//       default: return '#540B0E';
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-50 p-4">
//       <div className="mx-auto">
//         {/* Header */}
//         <div className="mb-6">
//           <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
//             Order Management Dashboard
//           </h1>
//           <p className="text-sm text-gray-600">
//             Executive Overview • Real-time Order Tracking
//           </p>
//         </div>

//         {/* Metrics Cards */}
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
//           {metrics.map((metric, index) => (
//             <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
//                     {metric.title}
//                   </p>
//                   <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
//                     {metric.value}
//                   </p>
//                 </div>
//                 <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
//                   <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
//                 </div>
//               </div>
//             </div>
//           ))}
//         </div>

//         {/* Orders Table */}
//         <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
//           <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
//             <h2 className="text-sm font-semibold text-white">Recent Orders</h2>
//           </div>
          
//           <div className="overflow-x-auto">
//             <table className="w-full">
//               <thead className="bg-gray-50">
//                 <tr>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Order Details
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Customer
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Date
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Status
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Total
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Actions
//                   </th>
//                 </tr>
//               </thead>
//               <tbody className="bg-white divide-y divide-gray-200">
//                 {orders.map((order) => (
//                   <React.Fragment key={order.id}>
//                     <tr className="hover:bg-gray-50">
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-2">
//                           <Package className="h-4 w-4" style={{ color: '#540B0E' }} />
//                           <div>
//                             <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                               {order.id}
//                             </p>
//                             <p className="text-xs text-gray-500">
//                               {order.products.length} item(s)
//                             </p>
//                           </div>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-1">
//                           <User className="h-3 w-3" style={{ color: '#9E2A2B' }} />
//                           <span className="text-sm" style={{ color: '#9E2A2B' }}>
//                             {order.customer}
//                           </span>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-1">
//                           <Calendar className="h-3 w-3" style={{ color: '#335C67' }} />
//                           <span className="text-sm" style={{ color: '#335C67' }}>
//                             {order.date}
//                           </span>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-2">
//                           <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(order.status)}`}>
//                             {order.status}
//                           </span>
//                           {order.coupon && (
//                             <div className="flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium text-white" style={{ backgroundColor: '#E09F3E' }}>
//                               <Tag className="h-2 w-2" />
//                               <span>{order.coupon.code}</span>
//                             </div>
//                           )}
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <span className="text-sm font-bold" style={{ color: '#540B0E' }}>
//                           ₹{order.total.toFixed(2)}
//                         </span>
//                       </td>
//                       <td className="px-4 py-3">
//                         <button
//                           onClick={() => toggleRow(order.id)}
//                           className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors"
//                           style={{ color: '#335C67', borderColor: '#335C67' }}
//                         >
//                           {expandedRows[order.id] ? (
//                             <>
//                               <ChevronUp className="h-3 w-3 inline mr-1" />
//                               Hide
//                             </>
//                           ) : (
//                             <>
//                               <ChevronDown className="h-3 w-3 inline mr-1" />
//                               View
//                             </>
//                           )}
//                         </button>
//                       </td>
//                     </tr>
                    
//                     {/* Expanded Row Content */}
//                     {expandedRows[order.id] && (
//                       <tr>
//                         <td colSpan="6" className="px-4 py-4 bg-gray-50">
//                           <div className="space-y-4">
//                             {/* Address */}
//                             <div className="flex items-center space-x-2 text-sm" style={{ color: '#9E2A2B' }}>
//                               <MapPin className="h-4 w-4" />
//                               <span>{order.address}</span>
//                             </div>

//                             {/* Accordions */}
//                             <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
//                               {/* Products Accordion */}
//                               <div className="border rounded-lg overflow-hidden">
//                                 <button
//                                   onClick={() => toggleAccordion(order.id, 'products')}
//                                   className="w-full px-4 py-3 bg-white border-b text-left flex items-center justify-between hover:bg-gray-50"
//                                 >
//                                   <div className="flex items-center space-x-2">
//                                     <Package className="h-4 w-4" style={{ color: '#540B0E' }} />
//                                     <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                                       Products ({order.products.length})
//                                     </span>
//                                   </div>
//                                   {activeAccordion[`${order.id}-products`] ? (
//                                     <ChevronUp className="h-4 w-4" style={{ color: '#335C67' }} />
//                                   ) : (
//                                     <ChevronDown className="h-4 w-4" style={{ color: '#335C67' }} />
//                                   )}
//                                 </button>
                                
//                                 {activeAccordion[`${order.id}-products`] && (
//                                   <div className="bg-white">
//                                     {order.products.map((product, index) => (
//                                       <div key={product.id} className={`px-4 py-3 ${index !== order.products.length - 1 ? 'border-b' : ''}`}>
//                                         <div className="flex items-center justify-between">
//                                           <div className="flex items-center space-x-3">
//                                             <span className="text-lg">{product.image}</span>
//                                             <div>
//                                               <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                                                 {product.name}
//                                               </p>
//                                               <p className="text-xs text-gray-500">SKU: {product.sku}</p>
//                                             </div>
//                                           </div>
//                                           <div className="text-right">
//                                             <p className="text-sm" style={{ color: '#9E2A2B' }}>
//                                               {product.quantity} × ${product.price.toFixed(2)}
//                                             </p>
//                                             <p className="text-sm font-bold" style={{ color: '#335C67' }}>
//                                               ₹{(product.quantity * product.price).toFixed(2)}
//                                             </p>
//                                           </div>
//                                         </div>
//                                       </div>
//                                     ))}
//                                   </div>
//                                 )}
//                               </div>

//                               {/* Transactions Accordion */}
//                               <div className="border rounded-lg overflow-hidden">
//                                 <button
//                                   onClick={() => toggleAccordion(order.id, 'transactions')}
//                                   className="w-full px-4 py-3 bg-white border-b text-left flex items-center justify-between hover:bg-gray-50"
//                                 >
//                                   <div className="flex items-center space-x-2">
//                                     <CreditCard className="h-4 w-4" style={{ color: '#540B0E' }} />
//                                     <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                                       Transactions ({order.transactions.length})
//                                     </span>
//                                   </div>
//                                   {activeAccordion[`${order.id}-transactions`] ? (
//                                     <ChevronUp className="h-4 w-4" style={{ color: '#335C67' }} />
//                                   ) : (
//                                     <ChevronDown className="h-4 w-4" style={{ color: '#335C67' }} />
//                                   )}
//                                 </button>
                                
//                                 {activeAccordion[`${order.id}-transactions`] && (
//                                   <div className="bg-white">
//                                     {order.transactions.map((transaction, index) => (
//                                       <div key={transaction.id} className={`px-4 py-3 ${index !== order.transactions.length - 1 ? 'border-b' : ''}`}>
//                                         <div className="flex items-center justify-between">
//                                           <div className="flex items-center space-x-3">
//                                             <CreditCard className="h-4 w-4" style={{ color: getTransactionColor(transaction.type) }} />
//                                             <div>
//                                               <p className="text-sm font-medium" style={{ color: getTransactionColor(transaction.type) }}>
//                                                 {transaction.type}
//                                               </p>
//                                               <p className="text-xs text-gray-500">
//                                                 {transaction.method}
//                                               </p>
//                                               <p className="text-xs text-gray-400">
//                                                 {transaction.timestamp}
//                                               </p>
//                                             </div>
//                                           </div>
//                                           <div className="text-right">
//                                             <p className="text-sm font-bold" style={{ color: getTransactionColor(transaction.type) }}>
//                                               {transaction.amount >= 0 ? '+' : ''}${transaction.amount.toFixed(2)}
//                                             </p>
//                                             <p className="text-xs text-gray-500">
//                                               {transaction.status}
//                                             </p>
//                                           </div>
//                                         </div>
//                                       </div>
//                                     ))}
//                                   </div>
//                                 )}
//                               </div>
//                             </div>

//                             {/* Coupon Details */}
//                             {order.coupon && (
//                               <div className="p-3 rounded-lg border-2 border-dashed" style={{ backgroundColor: '#E09F3E15', borderColor: '#E09F3E' }}>
//                                 <div className="flex items-center justify-between">
//                                   <div className="flex items-center space-x-2">
//                                     <Tag className="h-4 w-4" style={{ color: '#E09F3E' }} />
//                                     <span className="text-sm font-medium" style={{ color: '#E09F3E' }}>
//                                       Coupon Applied: {order.coupon.code}
//                                     </span>
//                                   </div>
//                                   <span className="text-sm font-bold" style={{ color: '#E09F3E' }}>
//                                     -₹{order.coupon.discount.toFixed(2)}
//                                   </span>
//                                 </div>
//                               </div>
//                             )}
//                           </div>
//                         </td>
//                       </tr>
//                     )}
//                   </React.Fragment>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default OrderManagement;

import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Package, Tag, User, Calendar, MapPin, ShoppingCart, DollarSign, Clock, TrendingUp } from 'lucide-react';
import { axiosInstance } from '../../axiosInstance';

const OrderManagement = () => {
  const [expandedRows, setExpandedRows] = useState({});
  const [activeAccordion, setActiveAccordion] = useState({});
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch orders from backend
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true);
        const response = await axiosInstance('/orders');
        if (response.status!=200) {
          throw new Error('Failed to fetch orders');
        }
        const data = response.data;
        setOrders(data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  const toggleRow = (orderId) => {
    setExpandedRows(prev => ({
      ...prev,
      [orderId]: !prev[orderId]
    }));
  };

  const toggleAccordion = (orderId, type) => {
    setActiveAccordion(prev => ({
      ...prev,
      [`${orderId}-${type}`]: !prev[`${orderId}-${type}`]
    }));
  };

  // Calculate metrics
  const metrics = [
    {
      title: 'Total Orders',
      value: orders.length,
      icon: ShoppingCart,
      color: '#335C67'
    },
    {
      title: 'Total Revenue',
      value: `₹${orders.reduce((sum, order) => sum + (order.totalAmount || 0), 0).toFixed(2)}`,
      icon: DollarSign,
      color: '#E09F3E'
    },
    {
      title: 'Avg Order Value',
      value: `₹${orders.length ? (orders.reduce((sum, order) => sum + (order.totalAmount || 0), 0) / orders.length).toFixed(2) : '0.00'}`,
      icon: TrendingUp,
      color: '#9E2A2B'
    },
    {
      title: 'Pending Orders',
      value: orders.filter(order => order.status === 'PENDING').length,
      icon: Clock,
      color: '#540B0E'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'DELIVERED': return 'bg-green-100 text-green-800 border-green-200';
      case 'PROCESSING': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'PENDING': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Calculate coupon discount (assuming backend provides discountValue and discountType)
  const calculateCouponDiscount = (order) => {
    if (!order.couponCode) return 0;
    // Placeholder: Assume backend provides discountValue and discountType
    // This requires Coupon entity details to be fetched or included in OrderDTO
    return 0; // Replace with actual logic if Coupon details are available
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 flex items-center justify-center">
        <p className="text-gray-600">Loading orders...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 flex items-center justify-center">
        <p className="text-red-600">Error: {error}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
            Order Management Dashboard
          </h1>
          <p className="text-sm text-gray-600">
            Executive Overview • Real-time Order Tracking
          </p>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                    {metric.title}
                  </p>
                  <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
                    {metric.value}
                  </p>
                </div>
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
                  <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Orders Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">Recent Orders</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Order Details
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {orders.map((order) => (
                  <React.Fragment key={order.id}>
                    <tr className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <Package className="h-4 w-4" style={{ color: '#540B0E' }} />
                          <div>
                            <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                              {order.id}
                            </p>
                            <p className="text-xs text-gray-500">
                              {order.items.length} item(s)
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-1">
                          <User className="h-3 w-3" style={{ color: '#9E2A2B' }} />
                          <span className="text-sm" style={{ color: '#9E2A2B' }}>
                            {order.userName || 'Unknown'}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-3 w-3" style={{ color: '#335C67' }} />
                          <span className="text-sm" style={{ color: '#335C67' }}>
                            {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'N/A'}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(order.status)}`}>
                            {order.status}
                          </span>
                          {order.couponCode && (
                            <div className="flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium text-white" style={{ backgroundColor: '#E09F3E' }}>
                              <Tag className="h-2 w-2" />
                              <span>{order.couponCode}</span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-sm font-bold" style={{ color: '#540B0E' }}>
                          ₹{order.totalAmount.toFixed(2)}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => toggleRow(order.id)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors"
                          style={{ color: '#335C67', borderColor: '#335C67' }}
                        >
                          {expandedRows[order.id] ? (
                            <>
                              <ChevronUp className="h-3 w-3 inline mr-1" />
                              Hide
                            </>
                          ) : (
                            <>
                              <ChevronDown className="h-3 w-3 inline mr-1" />
                              View
                            </>
                          )}
                        </button>
                      </td>
                    </tr>
                    
                    {/* Expanded Row Content */}
                    {expandedRows[order.id] && (
                      <tr>
                        <td colSpan="6" className="px-4 py-4 bg-gray-50">
                          <div className="space-y-4">
                            {/* Address */}
                            <div className="flex items-center space-x-2 text-sm" style={{ color: '#9E2A2B' }}>
                              <MapPin className="h-4 w-4" />
                              <span>{order.shippingAddress}</span>
                            </div>

                            {/* Products Accordion */}
                            <div className="border rounded-lg overflow-hidden">
                              <button
                                onClick={() => toggleAccordion(order.id, 'products')}
                                className="w-full px-4 py-3 bg-white border-b text-left flex items-center justify-between hover:bg-gray-50"
                              >
                                <div className="flex items-center space-x-2">
                                  <Package className="h-4 w-4" style={{ color: '#540B0E' }} />
                                  <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
                                    Products ({order.items.length})
                                  </span>
                                </div>
                                {activeAccordion[`${order.id}-products`] ? (
                                  <ChevronUp className="h-4 w-4" style={{ color: '#335C67' }} />
                                ) : (
                                  <ChevronDown className="h-4 w-4" style={{ color: '#335C67' }} />
                                )}
                              </button>
                              
                              {activeAccordion[`${order.id}-products`] && (
                                <div className="bg-white">
                                  {order.items.map((item, index) => (
                                    <div key={item.id || index} className={`px-4 py-3 ${index !== order.items.length - 1 ? 'border-b' : ''}`}>
                                      <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-3">
                                          <span className="text-lg">📦</span>
                                          <div>
                                            <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                                              {item.productName || 'Unknown Product'}
                                            </p>
                                            <p className="text-xs text-gray-500">ID: {item.productId}</p>
                                          </div>
                                        </div>
                                        <div className="text-right">
                                          <p className="text-sm" style={{ color: '#9E2A2B' }}>
                                            {item.quantity} × ₹{item.price.toFixed(2)}
                                          </p>
                                          <p className="text-sm font-bold" style={{ color: '#335C67' }}>
                                            ₹{(item.quantity * item.price).toFixed(2)}
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Coupon Details */}
                            {order.couponCode && (
                              <div className="p-3 rounded-lg border-2 border-dashed" style={{ backgroundColor: '#E09F3E15', borderColor: '#E09F3E' }}>
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-2">
                                    <Tag className="h-4 w-4" style={{ color: '#E09F3E' }} />
                                    <span className="text-sm font-medium" style={{ color: '#E09F3E' }}>
                                      Coupon Applied: {order.couponCode}
                                    </span>
                                  </div>
                                  <span className="text-sm font-bold" style={{ color: '#E09F3E' }}>
                                    -₹{calculateCouponDiscount(order).toFixed(2)}
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderManagement;