

import React, { useState, useEffect, useCallback } from 'react';
import { Tag, Trash, Upload, X } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useNavigate, useParams } from 'react-router-dom';
import { axiosInstance } from '../../axiosInstance';
import CustomDropdown from '../modals/CustomDropdown';

const AddProduct = () => {
  const { id } = useParams();
  const isEditing = !!id;
  const [product, setProduct] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    sku: '',
    isFeatured: false,
    brand: '',
    status: 'Active',
    categoryId: '',
    shopId: '',
    tags: [''],
    mediaFiles: [],
    variants: [{ attributes: {}, stock: '', price: '' }],
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [categories, setCategories] = useState([]);
  const [categoryLoading, setCategoryLoading] = useState(false);
  const [categorySearch, setCategorySearch] = useState('');
  const [variantAttributes, setVariantAttributes] = useState<string[]>([]);
  const navigate=useNavigate();

  // Fetch initial categories
  const fetchCategories = useCallback(async (query = '') => {
    setCategoryLoading(true);
    try {
      const params = { page: 0, size: 10, ...(query && { q: query }) };
      const res = await axiosInstance.get('/categories', { params });
      if (res.status === 200) {
        console.log('Fetched categories:', res.data.content);
        setCategories(res.data.content);
      }
    } catch (err) {
      console.error('Error fetching categories:', err);
      toast.error('Failed to fetch categories');
    } finally {
      setCategoryLoading(false);
    }
  }, []);

  // Fetch category details to get variantAttributes
  const fetchCategoryDetails = useCallback(async (categoryId: string) => {
    if (!categoryId) {
      setVariantAttributes([]);
      return;
    }
    try {
      const res = await axiosInstance.get(`/categories/${categoryId}`);
      if (res.status === 200) {
        console.log('Fetched variantAttributes:', res.data.variantAttributes);
        setVariantAttributes(res.data.variantAttributes || []);
      }
    } catch (err) {
      console.error('Error fetching category details:', err);
      toast.error('Failed to fetch category details');
    }
  }, []);

  // Fetch product details for editing
  const fetchProductDetails = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const res = await axiosInstance.get(`/products/${id}`);
      if (res.status === 200) {
        const productData = res.data;
        console.log('Fetched product data:', productData);
        setProduct({
          name: productData.name || '',
          description: productData.description || '',
          price: productData.price ? productData.price.toString() : '',
          stock: productData.stock ? productData.stock.toString() : '',
          sku: productData.sku || '',
          isFeatured: productData.isFeatured || false,
          brand: productData.brand || '',
          status: productData.status || 'Active',
          categoryId: productData.categoryId ? productData.categoryId.toString() : '',
          shopId: productData.shopId ? productData.shopId.toString() : '',
          tags: productData.tags && productData.tags.length > 0 ? productData.tags : [''],
          mediaFiles: productData.mediaUrls
            ? productData.mediaUrls.map((url: string, index: number) => ({
                file: null,
                preview: url,
                name: `Image ${index + 1}`,
              }))
            : [],
          variants: productData.variants && productData.variants.length > 0
            ? productData.variants.map((variant: any) => ({
                attributes: variant.attributes || {},
                stock: variant.stock ? variant.stock.toString() : '',
                price: variant.price ? variant.price.toString() : '',
              }))
            : [{ attributes: {}, stock: '', price: '' }],
        });
      }
    } catch (err) {
      console.error('Error fetching product details:', err);
      toast.error('Failed to fetch product details');
    } finally {
      setLoading(false);
    }
  }, [id]);

  // Initial fetch for categories and product details
  useEffect(() => {
    fetchCategories();
    if (isEditing) {
      fetchProductDetails();
    }
    return () => {
      product.mediaFiles.forEach((file: any) => {
        if (file.preview && file.file) {
          URL.revokeObjectURL(file.preview);
        }
      });
    };
  }, [fetchCategories, fetchProductDetails, isEditing]);

  // Fetch variant attributes when categoryId changes
  useEffect(() => {
    if (product.categoryId) {
      fetchCategoryDetails(product.categoryId);
    } else {
      setVariantAttributes([]);
    }
  }, [product.categoryId, fetchCategoryDetails]);

  // Handle category search
  useEffect(() => {
    const debounce = setTimeout(() => {
      fetchCategories(categorySearch);
    }, 300);
    return () => clearTimeout(debounce);
  }, [categorySearch, fetchCategories]);

  // Handle category change
  const handleProductChange = (field: any, value: any) => {
    setProduct((prev) => {
      const updatedProduct = { ...prev, [field]: value };
      if (field === 'categoryId' && value !== prev.categoryId) {
        updatedProduct.variants = [{ attributes: {}, stock: '', price: '' }];
      }
      return updatedProduct;
    });
  };

  const handleTagChange = (index: any, value: any) => {
    const newTags = [...product.tags];
    newTags[index] = value;
    setProduct((prev) => ({ ...prev, tags: newTags }));
  };

  const addTag = () => {
    setProduct((prev) => ({ ...prev, tags: [...prev.tags, ''] }));
  };

  const removeTag = (index: any) => {
    setProduct((prev) => ({
      ...prev,
      tags: prev.tags.filter((_, i) => i !== index),
    }));
  };

  const handleFileUpload = (event: any) => {
    const files = Array.from(event.target.files);
    const newFiles = files.map((file: any) => ({
      file,
      preview: URL.createObjectURL(file),
      name: file.name,
    }));
    setProduct((prev: any) => ({
      ...prev,
      mediaFiles: [...prev.mediaFiles, ...newFiles],
    }));
  };

  const removeMediaFile = (index: any) => {
    setProduct((prev) => {
      const fileToRemove: any = prev.mediaFiles[index];
      if (fileToRemove.file) {
        URL.revokeObjectURL(fileToRemove.preview);
      }
      return {
        ...prev,
        mediaFiles: prev.mediaFiles.filter((_, i) => i !== index),
      };
    });
  };

  const handleVariantChange = (index: any, field: any, value: any) => {
    const newVariants = [...product.variants];
    if (field.startsWith('attributes.')) {
      const attributeKey = field.split('.')[1];
      newVariants[index] = {
        ...newVariants[index],
        attributes: { ...newVariants[index].attributes, [attributeKey]: value },
      };
    } else {
      newVariants[index] = { ...newVariants[index], [field]: value };
    }
    setProduct((prev) => ({ ...prev, variants: newVariants }));
  };

  const addVariant = () => {
    setProduct((prev) => ({
      ...prev,
      variants: [...prev.variants, { attributes: {}, stock: '', price: '' }],
    }));
  };

  const removeVariant = (index: any) => {
    setProduct((prev) => ({
      ...prev,
      variants: prev.variants.filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async () => {
    if (!product.name || !product.price || !product.stock || !product.sku) {
      toast.error('Please fill in all required fields: Name, Price, Stock, and SKU');
      return;
    }
    for (const variant of product.variants) {
      for (const attr of variantAttributes) {
        if (!variant.attributes[attr] || variant.attributes[attr].trim() === '') {
          toast.error(`Please fill in all variant attributes for Variant ${product.variants.indexOf(variant) + 1}`);
          return;
        }
      }
    }

    setLoading(true);
    setError(null);

    try {
      const formData = new FormData();
      const productDTO = {
        name: product.name,
        description: product.description,
        price: parseFloat(product.price) || 0,
        stock: parseInt(product.stock) || 0,
        sku: product.sku,
        isFeatured: product.isFeatured,
        brand: product.brand,
        status: product.status,
        categoryId: product.categoryId ? parseInt(product.categoryId) : null,
        shopId: product.shopId ? parseInt(product.shopId) : null,
        tags: product.tags.filter((tag) => tag.trim() !== ''),
        variants: product.variants.map((variant) => ({
          attributes: variant.attributes,
          stock: parseInt(variant.stock) || 0,
          price: parseFloat(variant.price) || 0,
        })),
      };

      formData.append('product', JSON.stringify(productDTO));
      product.mediaFiles.forEach((fileObj: any) => {
        if (fileObj.file) {
          formData.append('images', fileObj.file);
        }
      });

      let response;
      if (isEditing) {
        response = await axiosInstance.put(`/products/${id}`, formData);
      } else {
        response = await axiosInstance.post('/products', formData);
      }

      if (response.status === 200 || response.status === 201) {
        toast.success(isEditing ? 'Product updated successfully!' : 'Product created successfully!');
        navigate("/dashboard/products")
        setProduct({
          name: '',
          description: '',
          price: '',
          stock: '',
          sku: '',
          isFeatured: false,
          brand: '',
          status: 'Active',
          categoryId: '',
          shopId: '',
          tags: [''],
          mediaFiles: [],
          variants: [{ attributes: {}, stock: '', price: '' }],
        });
        setVariantAttributes([]);
        setCategorySearch('');
      }
    } catch (err: any) {
      console.error(`Error ${isEditing ? 'updating' : 'creating'} product:`, err);
      setError(err.response?.data?.message || `Failed to ${isEditing ? 'update' : 'create'} product`);
      toast.error(err.response?.data?.message || `Failed to ${isEditing ? 'update' : 'create'} product`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2" style={{ color: '#540B0E' }}>
            {isEditing ? 'Edit Product' : 'Add New Product'}
          </h1>
          <p className="text-gray-600">
            {isEditing ? 'Update your product details and variants' : 'Create and manage your product catalog with detailed information and variants'}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
                <h2 className="text-lg font-semibold text-white flex items-center">
                  <Tag className="h-5 w-5 mr-2" />
                  Basic Information
                </h2>
              </div>
              <div className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                    Product Name *
                  </label>
                  <input
                    type="text"
                    value={product.name}
                    onChange={(e) => handleProductChange('name', e.target.value)}
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 border-secondary focus:ring-secondary"
                    placeholder="Enter product name"
                    disabled={loading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                    Description
                  </label>
                  <textarea
                    value={product.description}
                    onChange={(e) => handleProductChange('description', e.target.value)}
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 border-secondary focus:ring-secondary"
                    rows={4}
                    placeholder="Product description..."
                    disabled={loading}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                      Price (₹) *
                    </label>
                    <input
                      type="number"
                      value={product.price}
                      onChange={(e) => handleProductChange('price', e.target.value)}
                      className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 border-secondary focus:ring-secondary"
                      step="0.01"
                      placeholder="0.00"
                      disabled={loading}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                      Stock Quantity *
                    </label>
                    <input
                      type="number"
                      value={product.stock}
                      onChange={(e) => handleProductChange('stock', e.target.value)}
                      className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 border-secondary focus:ring-secondary"
                      placeholder="0"
                      disabled={loading}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                      SKU *
                    </label>
                    <input
                      type="text"
                      value={product.sku}
                      onChange={(e) => handleProductChange('sku', e.target.value)}
                      className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 border-secondary focus:ring-secondary"
                      placeholder="SKU-001"
                      disabled={loading}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                      Brand
                    </label>
                    <input
                      type="text"
                      value={product.brand}
                      onChange={(e) => handleProductChange('brand', e.target.value)}
                      className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 border-secondary focus:ring-secondary"
                      placeholder="Brand name"
                      disabled={loading}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
                <h2 className="text-lg font-semibold text-white flex items-center">
                  <Upload className="h-5 w-5 mr-2" />
                  Product Images
                </h2>
              </div>
              <div className="p-6">
                <div className="border-2 border-dashed rounded-lg p-8 text-center" style={{ borderColor: '#335C67' }}>
                  <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 mb-4">
                    Drop your images here, or <span className="font-medium" style={{ color: '#335C67' }}>browse</span>
                  </p>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                    disabled={loading}
                  />
                  <label
                    htmlFor="file-upload"
                    className="inline-block px-4 py-2 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                    style={{ borderColor: '#335C67', color: '#335C67' }}
                  >
                    Select Images
                  </label>
                </div>
                {product?.mediaFiles?.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                    {product?.mediaFiles?.map((file: any, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={file?.preview}
                          alt={file?.name}
                          className="w-full h-32 object-cover rounded-lg border"
                        />
                        <button
                          onClick={() => removeMediaFile(index)}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          disabled={loading}
                        >
                          <X className="h-4 w-4" />
                        </button>
                        <p className="text-xs text-gray-500 mt-1 truncate">{file.name}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
                <h2 className="text-lg font-semibold text-white flex items-center">
                  <Tag className="h-5 w-5 mr-2" />
                  Product Variants
                </h2>
              </div>
              <div className="p-6 space-y-6">
                {product.variants.map((variant, index) => (
                  <div key={index} className="border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-medium" style={{ color: '#540B0E' }}>
                        Variant {index + 1}
                      </h3>
                      {product.variants.length > 1 && (
                        <button
                          onClick={() => removeVariant(index)}
                          className="p-2 hover:bg-gray-200 rounded-full transition-colors"
                          style={{ color: '#9E2A2B' }}
                          disabled={loading}
                        >
                          <Trash className="h-5 w-5" />
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {variantAttributes.map((attribute) => (
                        <div key={attribute}>
                          <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                            {attribute}
                          </label>
                          <input
                            type="text"
                            value={variant.attributes[attribute] || ''}
                            onChange={(e) => handleVariantChange(index, `attributes.${attribute}`, e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary"
                            placeholder={`Enter ${attribute}`}
                            disabled={loading}
                          />
                        </div>
                      ))}
                      <div>
                        <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                          Stock
                        </label>
                        <input
                          type="number"
                          value={variant.stock}
                          onChange={(e) => handleVariantChange(index, 'stock', e.target.value)}
                          className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary"
                          placeholder="0"
                          disabled={loading}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                          Price (₹)
                        </label>
                        <input
                          type="number"
                          value={variant.price}
                          onChange={(e) => handleVariantChange(index, 'price', e.target.value)}
                          className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary"
                          step="0.01"
                          placeholder="0.00"
                          disabled={loading}
                        />
                      </div>
                    </div>
                  </div>
                ))}
                <button
                  onClick={addVariant}
                  className="w-full py-3 border-2 border-dashed rounded-lg hover:bg-gray-50 transition-colors"
                  style={{ borderColor: '#335C67', color: '#335C67' }}
                  disabled={loading || !product.categoryId}
                >
                  + Add New Variant
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
                <h2 className="text-lg font-semibold text-white">Settings</h2>
              </div>
              <div className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                    Status
                  </label>
                  <select
                    value={product.status}
                    onChange={(e) => handleProductChange('status', e.target.value)}
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary"
                    disabled={loading}
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
                <CustomDropdown
                  categories={categories}
                  product={product}
                  handleProductChange={handleProductChange}
                  setCategorySearch={setCategorySearch}
                  categorySearch={categorySearch}
                  loading={loading}
                  categoryLoading={categoryLoading}
                />
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
                    Shop ID
                  </label>
                  <input
                    type="text"
                    value={product.shopId}
                    onChange={(e) => handleProductChange('shopId', e.target.value)}
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary"
                    placeholder="SHOP-001"
                    disabled={loading}
                  />
                </div>
                <div>
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={product.isFeatured}
                      onChange={(e) => handleProductChange('isFeatured', e.target.checked)}
                      className="h-5 w-5 rounded border-gray-300 focus:ring-2 focus:ring-opacity-50"
                      style={{ accentColor: '#335C67' }}
                      disabled={loading}
                    />
                    <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
                      Featured Product
                    </span>
                  </label>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
                <h2 className="text-lg font-semibold text-white">Tags</h2>
              </div>
              <div className="p-6 space-y-4">
                {product.tags.map((tag, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={tag}
                      onChange={(e) => handleTagChange(index, e.target.value)}
                      className="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary"
                      placeholder="Tag name"
                      disabled={loading}
                    />
                    {product.tags.length > 1 && (
                      <button
                        onClick={() => removeTag(index)}
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                        style={{ color: '#9E2A2B' }}
                        disabled={loading}
                      >
                        <Trash className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  onClick={addTag}
                  className="w-full py-2 border border-dashed rounded-lg hover:bg-gray-50 transition-colors"
                  style={{ borderColor: '#335C67', color: '#335C67' }}
                  disabled={loading}
                >
                  + Add Tag
                </button>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="p-6 space-y-4">
                <button
                  onClick={handleSubmit}
                  className="w-full py-3 px-4 rounded-lg font-medium text-white hover:opacity-90 transition-opacity disabled:opacity-50"
                  style={{ backgroundColor: '#335C67' }}
                  disabled={loading}
                >
                  {loading ? 'Saving...' : isEditing ? 'Update Product' : 'Save Product'}
                </button>
                <button
                  className="w-full py-3 px-4 border rounded-lg font-medium hover:bg-gray-50 transition-colors disabled:opacity-50"
                  style={{ borderColor: '#335C67', color: '#335C67' }}
                  disabled={loading}
                >
                  Save as Draft
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddProduct;