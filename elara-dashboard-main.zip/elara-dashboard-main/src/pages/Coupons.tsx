import  { useState, useEffect } from 'react';
import { Tag, DollarSign, Clock, Trash2, Edit, Search } from 'lucide-react';
import CouponModal from './../modals/Coupon';
import ConfirmationModal from '../modals/ConfirmationDialog';
import { axiosInstance } from '../../axiosInstance';

const Coupons = () => {
  const [coupons, setCoupons] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' or 'edit'
  const [currentCoupon, setCurrentCoupon] = useState({
    id: '',
    code: '',
    discountType: 'PERCENTAGE',
    discountValue: 0,
    validFrom: '',
    validTo: '',
    maxUses: 0,
    usesPerUser: 0,
    minOrderValue: 0,
    status: 'Active',
  });
  const [selectedCouponId, setSelectedCouponId] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [discountTypeFilter, setDiscountTypeFilter] = useState('All');

  const openModal = (mode, coupon = {
    id: '',
    code: '',
    discountType: 'PERCENTAGE',
    discountValue: 0,
    validFrom: '',
    validTo: '',
    maxUses: 0,
    usesPerUser: 0,
    minOrderValue: 0,
    status: 'Active',
  }) => {
    setModalMode(mode);
    setCurrentCoupon(coupon);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentCoupon({
      id: '',
      code: '',
      discountType: 'PERCENTAGE',
      discountValue: 0,
      validFrom: '',
      validTo: '',
      maxUses: 0,
      usesPerUser: 0,
      minOrderValue: 0,
      status: 'Active',
    });
  };

  const getAllCoupons = async () => {
    try {
      let url = '/coupons';
      if (statusFilter !== 'All') {
        url = `/coupons/status/${statusFilter}`;
      }
      const res = await axiosInstance.get(url);
      if (res.status === 200) {
        let filteredCoupons = res.data;
        if (discountTypeFilter !== 'All') {
          filteredCoupons = res.data.filter(coupon => coupon.discountType === discountTypeFilter);
        }
        setCoupons(filteredCoupons);
      }
    } catch (error) {
      console.error('Error fetching coupons:', error);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      getAllCoupons();
      return;
    }
    try {
      const res = await axiosInstance.get(`/coupons/code?code=${encodeURIComponent(searchQuery)}`);
      if (res.status === 200) {
        setCoupons([res.data]);
      } else if (res.status === 404) {
        setCoupons([]);
      }
    } catch (error) {
      console.error('Error searching coupons:', error);
      setCoupons([]);
    }
  };

  const handleSave = async () => {
    try {
      if (modalMode === 'add') {
        const newCoupon = {
          code: currentCoupon.code,
          discountType: currentCoupon.discountType,
          discountValue: currentCoupon.discountValue,
          validFrom: currentCoupon.validFrom,
          validTo: currentCoupon.validTo,
          maxUses: currentCoupon.maxUses,
          usesPerUser: currentCoupon.usesPerUser,
          minOrderValue: currentCoupon.minOrderValue,
          status: currentCoupon.status,
 
       };
        const res = await axiosInstance.post('/coupons', newCoupon);
        if (res.status === 201) {
          setCoupons([...coupons, res.data]);
        }
      } else {
        const updatedCoupon = {
          code: currentCoupon.code,
          discountType: currentCoupon.discountType,
          discountValue: currentCoupon.discountValue,
          validFrom: currentCoupon.validFrom,
          validTo: currentCoupon.validTo,
          maxUses: currentCoupon.maxUses,
          usesPerUser: currentCoupon.usesPerUser,
          minOrderValue: currentCoupon.minOrderValue,
          status: currentCoupon.status,
        };
        const res = await axiosInstance.put(`/coupons/${currentCoupon.id}`, updatedCoupon);
        if (res.status === 200) {
          setCoupons(coupons.map(cpn => (cpn.id === currentCoupon.id ? res.data : cpn)));
        }
      }
      closeModal();
    } catch (error) {
      console.error('Error saving coupon:', error);
    }
  };

  const handleDelete = (id) => {
    setSelectedCouponId(id);
    setShowDeleteModal(true);
  };

  const deleteCouponById = async () => {
    try {
      const res = await axiosInstance.delete(`/coupons/${selectedCouponId}`);
      if (res.status === 204) {
        setCoupons(coupons.filter(cpn => cpn.id !== selectedCouponId));
        setShowDeleteModal(false);
        setSelectedCouponId(null);
      }
    } catch (error) {
      console.error('Error deleting coupon:', error);
      setShowDeleteModal(false);
    }
  };

  useEffect(() => {
    getAllCoupons();
  }, [statusFilter, discountTypeFilter]);

  const metrics = [
    {
      title: 'Total Coupons',
      value: coupons.length,
      icon: Tag,
      color: '#335C67',
    },
    {
      title: 'Active Coupons',
      value: coupons.filter(cpn => cpn.status === 'Active').length,
      icon: DollarSign,
      color: '#E09F3E',
    },
    {
      title: 'Expired Coupons',
      value: coupons.filter(cpn => cpn.status === 'Expired').length,
      icon: Clock,
      color: '#9E2A2B',
    },
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Expired':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Inactive':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bgtournaments bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
              Coupon Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Promotions Overview • Real-time Coupon Tracking
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Search className="h-5 w-5 text-gray-400 absolute right-[27%]" />
              <input
                type="text"
                placeholder="Search by coupon code"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Expired">Expired</option>
              <option value="Inactive">Inactive</option>
            </select>
            <select
              value={discountTypeFilter}
              onChange={(e) => setDiscountTypeFilter(e.target.value)}
              className="px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="All">All Types</option>
              <option value="PERCENTAGE">Percentage</option>
              <option value="FIXED">Fixed Amount</option>
            </select>
            <button
              onClick={() => openModal('add')}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
              style={{ color: '#335C67', borderColor: '#335C67' }}
            >
              <Tag className="h-4 w-4 mr-2" style={{ color: '#335C67' }} />
              Add Coupon
            </button>
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                    {metric.title}
                  </p>
                  <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
                    {metric.value}
                  </p>
                </div>
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
                  <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Coupons Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">Coupon List</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Coupon Code
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Discount
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Validity
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Usage Limits
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Min Order
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {coupons.map((coupon) => (
                  <tr key={coupon.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <Tag className="h-4 w-4" style={{ color: '#540B0E' }} />
                        <div>
                          <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                            {coupon.code}
                          </p>
                          <p className="text-xs text-gray-500">
                            ID: {coupon.id}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                        {coupon.discountType === 'PERCENTAGE' ? `${coupon.discountValue}%` : `₹${coupon.discountValue}`}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#335C67' }}>
                        {coupon.validFrom} - {coupon.validTo}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                        Max: {coupon.maxUses}, Per User: {coupon.usesPerUser}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-bold" style={{ color: '#540B0E' }}>
                        ₹{coupon.minOrderValue.toFixed(2)}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(coupon.status)}`}>
                        {coupon.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => openModal('edit', coupon)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#335C67', borderColor: '#335C67' }}
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(coupon.id)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Coupon Modal */}
      {
        isModalOpen &&   <CouponModal
          isOpen={isModalOpen}
          onClose={closeModal}
          mode={modalMode}
          coupon={currentCoupon}
          setCoupon={setCurrentCoupon}
          onSave={handleSave}
        />
      }

        {/* Confirmation Modal for Delete */}
        {showDeleteModal && <ConfirmationModal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          confirmationText="Are you sure you want to delete this coupon? This action cannot be undone."
          actionText="Delete"
          action={deleteCouponById}
          title="Confirm Delete"
        />}
      </div>
    </div>
  );
};

export default Coupons;