import React, { useState } from 'react';
import { Tag, AlertCircle, Clock, X, Edit, Trash } from 'lucide-react';

const Support = () => {
  const [tickets, setTickets] = useState([
    {
      id: 'TKT-001',
      userId: 'USR-001',
      subject: 'Issue with Order Delivery',
      description: 'Order ORD-001 was not delivered on time. Please check status.',
      status: 'OPEN',
      priority: 'HIGH'
    },
    {
      id: 'TKT-002',
      userId: 'USR-002',
      subject: 'Defective Product Received',
      description: 'The Sapphire Necklace (PRD-002) arrived with a scratched gemstone.',
      status: 'IN_PROGRESS',
      priority: 'MEDIUM'
    },
    {
      id: 'TKT-003',
      userId: 'USR-003',
      subject: 'Billing Query',
      description: 'Charged twice for Handbound Leather Journal (PRD-003). Need refund.',
      status: 'RESOLVED',
      priority: 'LOW'
    }
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' or 'edit'
  const [currentTicket, setCurrentTicket] = useState({
    id: '',
    userId: '',
    subject: '',
    description: '',
    status: 'OPEN',
    priority: 'LOW'
  });

  const openModal = (mode, ticket = {
    id: '',
    userId: '',
    subject: '',
    description: '',
    status: 'OPEN',
    priority: 'LOW'
  }) => {
    setModalMode(mode);
    setCurrentTicket(ticket);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentTicket({
      id: '',
      userId: '',
      subject: '',
      description: '',
      status: 'OPEN',
      priority: 'LOW'
    });
  };

  const handleSave = () => {
    if (modalMode === 'add') {
      const newTicket = {
        ...currentTicket,
        id: `TKT-${(tickets.length + 1).toString().padStart(3, '0')}`
      };
      setTickets([...tickets, newTicket]);
    } else {
      setTickets(tickets.map(tkt => (tkt.id === currentTicket.id ? currentTicket : tkt)));
    }
    closeModal();
  };

  const handleDelete = (id) => {
    setTickets(tickets.filter(tkt => tkt.id !== id));
  };

  const metrics = [
    {
      title: 'Total Tickets',
      value: tickets.length,
      icon: Tag,
      color: '#335C67'
    },
    {
      title: 'Open Tickets',
      value: tickets.filter(tkt => tkt.status === 'OPEN').length,
      icon: AlertCircle,
      color: '#E09F3E'
    },
    {
      title: 'Resolved Tickets',
      value: tickets.filter(tkt => tkt.status === 'RESOLVED').length,
      icon: Clock,
      color: '#9E2A2B'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'OPEN': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'IN_PROGRESS': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'RESOLVED': return 'bg-green-100 text-green-800 border-green-200';
      case 'CLOSED': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'HIGH': return 'bg-red-100 text-red-800 border-red-200';
      case 'MEDIUM': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'LOW': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
              Support Ticket Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Customer Support Overview • Real-time Ticket Tracking
            </p>
          </div>
      
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                    {metric.title}
                  </p>
                  <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
                    {metric.value}
                  </p>
                </div>
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
                  <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tickets Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">Ticket List</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ticket Details
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User ID
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Priority
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {tickets.map((ticket) => (
                  <tr key={ticket.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <AlertCircle className="h-4 w-4" style={{ color: '#540B0E' }} />
                        <div>
                          <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                            {ticket.subject}
                          </p>
                          <p className="text-sm text-gray-600">
                            {ticket.description}
                          </p>
                          <p className="text-xs text-gray-500">
                            ID: {ticket.id}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                        {ticket.userId}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(ticket.status)}`}>
                        {ticket.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(ticket.priority)}`}>
                        {ticket.priority}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => openModal('edit', ticket)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#335C67', borderColor: '#335C67' }}
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(ticket.id)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                        >
                          <Trash className="h-3 w-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
                  {modalMode === 'add' ? 'Add Ticket' : 'Edit Ticket'}
                </h2>
                <button onClick={closeModal}>
                  <X className="h-5 w-5" style={{ color: '#335C67' }} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    User ID
                  </label>
                  <input
                    type="text"
                    value={currentTicket.userId}
                    onChange={(e) => setCurrentTicket({ ...currentTicket, userId: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Subject
                  </label>
                  <input
                    type="text"
                    value={currentTicket.subject}
                    onChange={(e) => setCurrentTicket({ ...currentTicket, subject: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Description
                  </label>
                  <textarea
                    value={currentTicket.description}
                    onChange={(e) => setCurrentTicket({ ...currentTicket, description: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                    rows="4"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Status
                  </label>
                  <select
                    value={currentTicket.status}
                    onChange={(e) => setCurrentTicket({ ...currentTicket, status: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  >
                    <option value="OPEN">Open</option>
                    <option value="IN_PROGRESS">In Progress</option>
                    <option value="RESOLVED">Resolved</option>
                    <option value="CLOSED">Closed</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Priority
                  </label>
                  <select
                    value={currentTicket.priority}
                    onChange={(e) => setCurrentTicket({ ...currentTicket, priority: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  >
                    <option value="LOW">Low</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="HIGH">High</option>
                  </select>
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={closeModal}
                    className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
                    style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
                    style={{ color: '#335C67', borderColor: '#335C67' }}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Support;