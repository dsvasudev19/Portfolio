import React, { useState, useEffect } from 'react';
import { Store, Edit, Trash2, Filter, Users } from 'lucide-react';
import { axiosInstance } from '../../axiosInstance';
import VendorModal from '../modals/Vendor';

const VendorManagement = () => {
  const [vendors, setVendors] = useState([]);
  const [metrics, setMetrics] = useState({ totalVendors: 0, approvedVendors: 0, pendingVendors: 0 });
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(10);
  const [totalPages, setTotalPages] = useState(0);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [approved, setApproved] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' or 'edit'
  const [currentVendor, setCurrentVendor] = useState({
    id: '',
    businessName: '',
    email: '',
    phoneNumber: '',
    address: '',
    taxId: '',
    status: 'PENDING',
    approved: false,
    document: null
  });

  const colors = {
    teal: '#335C67',
    butter: '#FFF3B0',
    gold: '#E09F3E',
    crimson: '#9E2A2B',
    burgundy: '#540B0E'
  };

  const fetchVendors = async () => {
    const params = {
      page,
      size,
      ...(status && { status }),
      ...(approved !== '' && { approved }),
      ...(search && { search })
    };
    try {
      const response = await axiosInstance.get('/vendors', { params });
      setVendors(response.data.content);
      setTotalPages(response.data.totalPages);
    } catch (error) {
      console.error('Error fetching vendors:', error);
    }
  };

  const fetchMetrics = async () => {
    try {
      const response = await axiosInstance.get('/vendors/metrics');
      setMetrics(response.data);
    } catch (error) {
      console.error('Error fetching metrics:', error);
    }
  };

  useEffect(() => {
    fetchVendors();
    fetchMetrics();
  }, [page, size, status, approved, search]);

  const handleSearch = (e) => {
    setSearch(e.target.value);
    setPage(0);
  };

  const handleFilterChange = () => {
    setPage(0);
    fetchVendors();
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 0 && newPage < totalPages) {
      setPage(newPage);
    }
  };

  const openModal = (mode, vendor = {
    id: '',
    businessName: '',
    email: '',
    phoneNumber: '',
    address: '',
    taxId: '',
    status: 'PENDING',
    approved: false,
    document: null
  }) => {
    setModalMode(mode);
    setCurrentVendor(vendor);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentVendor({
      id: '',
      businessName: '',
      email: '',
      phoneNumber: '',
      address: '',
      taxId: '',
      status: 'PENDING',
      approved: false,
      document: null
    });
  };

  const handleSave = () => {
    fetchVendors();
    fetchMetrics();
    closeModal();
  };

  const handleDelete = async (id) => {
    try {
      await axiosInstance.delete(`/vendors/${id}`, { params: { deletedBy: 'admin' } });
      fetchVendors();
      fetchMetrics();
    } catch (error) {
      console.error('Error deleting vendor:', error);
    }
  };

  const handleStatusChange = async (vendorId, newStatus) => {
    try {
      const vendor = vendors.find((v) => v.id === vendorId);
      if (vendor) {
        const formData = new FormData();
        formData.append('vendor', new Blob([JSON.stringify({ ...vendor, status: newStatus })], { type: 'application/json' }));
        await axiosInstance.put(`/vendors/${vendorId}`, formData);
        fetchVendors();
        fetchMetrics();
      }
    } catch (error) {
      console.error(`Error updating vendor status to ${newStatus}:`, error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ACTIVE': return 'bg-green-100 text-green-800 border-green-200';
      case 'INACTIVE': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'PENDING': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const metricsData = [
    { title: 'Total Vendors', value: metrics.totalVendors, icon: Users, color: colors.gold },
    { title: 'Approved Vendors', value: metrics.approvedVendors, icon: Filter, color: colors.crimson },
    { title: 'Pending Vendors', value: metrics.pendingVendors, icon: Store, color: colors.burgundy }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: colors.burgundy }}>
              Vendor Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Vendor Overview • Real-time Status Tracking
            </p>
          </div>
          <button
            onClick={() => openModal('add')}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
            style={{ color: colors.teal, borderColor: colors.teal }}
          >
            <Store className="h-4 w-4 mr-2" style={{ color: colors.teal }} />
            Add Vendor
          </button>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {metricsData.map((metric, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                    {metric.title}
                  </p>
                  <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
                    {metric.value}
                  </p>
                </div>
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
                  <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Filters and Search */}
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <input
              type="text"
              placeholder="Search by Business Name or Email"
              value={search}
              onChange={handleSearch}
              className="border border-gray-300 rounded-lg p-2 flex-1"
              style={{ borderColor: colors.teal }}
            />
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="border border-gray-300 rounded-lg p-2"
              style={{ borderColor: colors.teal }}
            >
              <option value="">All Statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
              <option value="PENDING">Pending</option>
            </select>
            <select
              value={approved}
              onChange={(e) => setApproved(e.target.value)}
              className="border border-gray-300 rounded-lg p-2"
              style={{ borderColor: colors.teal }}
            >
              <option value="">All Approval Statuses</option>
              <option value="true">Approved</option>
              <option value="false">Not Approved</option>
            </select>
            <button
              onClick={handleFilterChange}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
              style={{ color: colors.teal, borderColor: colors.teal }}
            >
              <Filter className="h-4 w-4 mr-2" style={{ color: colors.teal }} />
              Apply Filters
            </button>
          </div>
        </div>

        {/* Vendors Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: colors.teal }}>
            <h2 className="text-sm font-semibold text-white">Vendor List</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Vendor ID
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Business Name
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>

                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {vendors.map((vendor) => (
                  <tr key={vendor.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <Store className="h-4 w-4" style={{ color: colors.burgundy }} />
                        <div>
                          <p className="text-sm font-medium" style={{ color: colors.burgundy }}>
                            {vendor.businessName}
                          </p>
                          <p className="text-xs text-gray-500">
                            ID: {vendor.id}
                          </p>
                        </div>
                      </div>
                      </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: colors.crimson }}>
                        {vendor.businessName}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: colors.crimson }}>
                        {vendor.email}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(vendor.status)}`}>
                        {vendor.status}
                      </span>
                    </td>
     
                    <td className="px-4 py-3">
                      <div className="flex space-x-2 flex-wrap gap-2">
                       <button
  onClick={() => handleStatusChange(vendor.id, 'ACTIVE')}
  disabled={vendor.status === 'ACTIVE'}
  className="text-sm px-3 py-1.5 rounded-md hover:bg-gray-50 border transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed font-medium"
  style={{ 
    color: colors.teal, 
    borderColor: colors.teal 
  }}
>
  <span className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: colors.teal }} />
  Activate
</button>

<button
  onClick={() => handleStatusChange(vendor.id, 'INACTIVE')}
  disabled={vendor.status === 'INACTIVE'}
  className="text-sm px-3 py-1.5 rounded-md hover:bg-gray-50 border transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed font-medium"
  style={{ 
    color: colors.crimson, 
    borderColor: colors.crimson 
  }}
>
  <span className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: colors.crimson }} />
  Deactivate
</button>
                
                        <button
                          onClick={() => openModal('edit', vendor)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: colors.teal, borderColor: colors.teal }}
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(vendor.id)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: colors.crimson, borderColor: colors.crimson }}
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-between items-center px-4 py-3 border-t border-gray-200">
            <button
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 0}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center disabled:opacity-50"
              style={{ color: colors.teal, borderColor: colors.teal }}
            >
              Previous
            </button>
            <span className="text-sm text-gray-600">
              Page {page + 1} of {totalPages}
            </span>
            <button
              onClick={() => handlePageChange(page + 1)}
              disabled={page >= totalPages - 1}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center disabled:opacity-50"
              style={{ color: colors.teal, borderColor: colors.teal }}
            >
              Next
            </button>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && (
          <VendorModal
            mode={modalMode}
            vendor={currentVendor}
            onSave={handleSave}
            onClose={closeModal}
            colors={colors}
          />
        )}
      </div>
    </div>
  );
};

export default VendorManagement;