// import React, { useEffect, useInsertionEffect, useState } from 'react';
// import { ChevronDown, ChevronUp, User, Mail, Shield, Clock, Calendar, Key, Edit, Trash2 } from 'lucide-react';
// import { axiosInstance } from '../../axiosInstance';
// import toast from 'react-hot-toast';
// import ConfirmationModal from '../modals/ConfirmationDialog';

// const Users = () => {
//   const [expandedRows, setExpandedRows] = useState({});
//   const [activeAccordion, setActiveAccordion] = useState({});
//   const [users,setUsers]=useState([])
//   const [showDeleteModal,setShowDeleteModal]=useState(false)
//   const [selectedUserId,setSelectedUserId]=useState<any>()

//   const getAllUsers=async()=>{
//     try {
//       const res=await axiosInstance.get("/users")
//       if(res.status===200){
//         setUsers(res?.data)
//       }
//     } catch (error) {
//       console.log(error)
//     }
//   }

//   const handleDeleteUser=(userId:any)=>{
//     setShowDeleteModal(true)
//     setSelectedUserId(userId)
//   }

//   const deleteUserById=async()=>{
//     try {
//       const res=await axiosInstance.delete(`/users/${selectedUserId}`)
//       if(res.status===204){
//         toast.success("User Deleted Successfully")
//         getAllUsers()
//       }
//     } catch (error) {
//       console.log(error)
//     }
//   }

//   useEffect(()=>{
//     getAllUsers()
//   },[])


//   const metrics = [
//     {
//       title: 'Total Users',
//       value: users.length,
//       icon: User,
//       color: '#335C67'
//     },
//     {
//       title: 'Admin Users',
//       value: users.filter(user => user.role === 'ADMIN').length,
//       icon: Shield,
//       color: '#E09F3E'
//     },
//     {
//       title: 'MFA Enabled',
//       value: users.filter(user => user.mfaEnabled).length,
//       icon: Key,
//       color: '#9E2A2B'
//     },
//     {
//       title: 'Recent Registrations',
//       value: users.filter(user => new Date(user.createdAt) > new Date('2024-07-10')).length,
//       icon: Clock,
//       color: '#540B0E'
//     }
//   ];

//   const getRoleColor = (role:any) => {
//     switch (role) {
//       case 'ADMIN': return 'bg-blue-100 text-blue-800 border-blue-200';
//       case 'VENDOR': return 'bg-green-100 text-green-800 border-green-200';
//       case 'USER': return 'bg-accent-100 text-accent-800 border-accent-200';
//       default: return 'bg-gray-100 text-gray-800 border-gray-200';
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-50 p-4">
//       <div className="mx-auto">
//         {/* Header */}
//         <div className="mb-6">
//           <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
//             User Management Dashboard
//           </h1>
//           <p className="text-sm text-gray-600">
//             Administrative Overview • Real-time User Monitoring
//           </p>
//         </div>

//         {/* Metrics Cards */}
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
//           {metrics.map((metric, index) => (
//             <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
//                     {metric.title}
//                   </p>
//                   <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
//                     {metric.value}
//                   </p>
//                 </div>
//                 <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
//                   <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
//                 </div>
//               </div>
//             </div>
//           ))}
//         </div>

//         {/* Users Table */}
//         <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
//           <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
//             <h2 className="text-sm font-semibold text-white">User Accounts</h2>
//           </div>
          
//           <div className="overflow-x-auto">
//             <table className="w-full">
//               <thead className="bg-gray-50">
//                 <tr>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     User Details
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Email
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Role
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     MFA Status
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Created At
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Actions
//                   </th>
//                 </tr>
//               </thead>
//               <tbody className="bg-white divide-y divide-gray-200">
//                 {users.map((user:any) => (
//                   <React.Fragment key={user.id}>
//                     <tr className="hover:bg-gray-50">
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-2">
//                           <User className="h-4 w-4" style={{ color: '#540B0E' }} />
//                           <div>
//                             <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                               {user.fullName}
//                             </p>
//                             <p className="text-xs text-gray-500">
//                               ID: {user.id}
//                             </p>
//                           </div>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-1">
//                           <Mail className="h-3 w-3" style={{ color: '#9E2A2B' }} />
//                           <span className="text-sm" style={{ color: '#9E2A2B' }}>
//                             {user.email}
//                           </span>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getRoleColor(user.role)}`}>
//                           {user.role}
//                         </span>
//                       </td>
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-2">
//                           <span className={`px-2 py-1 rounded-full text-xs font-medium border ${user.mfaEnabled ? 'bg-green-100 text-green-800 border-green-200' : 'bg-red-100 text-red-800 border-red-200'}`}>
//                             {user.mfaEnabled ? 'Enabled' : 'Disabled'}
//                           </span>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-1">
//                           <Calendar className="h-3 w-3" style={{ color: '#335C67' }} />
//                           <span className="text-sm" style={{ color: '#335C67' }}>
//                             {new Date(user.createdAt).toLocaleString()}
//                           </span>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                       <div className="flex space-x-2">
//                         <button
//                           className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
//                           style={{ color: '#335C67', borderColor: '#335C67' }}
//                         >
//                           <Edit className="h-3 w-3 mr-1" />
//                           Edit
//                         </button>
//                         <button
//                           onClick={()=>{handleDeleteUser(user.id)}}
//                           className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
//                           style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
//                         >
//                           <Trash2 className="h-3 w-3 mr-1" />
//                           Delete
//                         </button>
//                       </div>
//                       </td>
//                     </tr>
                 
//                   </React.Fragment>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </div>
//         {
//           showDeleteModal && <ConfirmationModal isOpen={showDeleteModal} onClose={()=>{setShowDeleteModal(false)}} confirmationText='Are you sure to Delete ? This action cannot be undone' action={deleteUserById} actionText='Confirm' />
//         }
//       </div>
//     </div>
//   );
// };

// export default Users;

import React, { useState, useEffect } from 'react';
import { User, Mail, Shield, Clock, Calendar, Key, Edit, Trash2, Search } from 'lucide-react';
import { axiosInstance } from '../../axiosInstance';
import toast from 'react-hot-toast';
import ConfirmationModal from '../modals/ConfirmationDialog';
import UserModal from '../modals/User';

const Users = () => {
  const [users, setUsers] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' or 'edit'
  const [currentUser, setCurrentUser] = useState({
    id: '',
    fullName: '',
    email: '',
    password: '',
    role: 'USER',
    mfaEnabled: false,
    secret: '',
    createdAt: '',
  });
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [mfaFilter, setMfaFilter] = useState('All');

  const getAllUsers = async () => {
    try {
      let url = '/users';
      if (roleFilter !== 'All') {
        url = `/users/role/${roleFilter}`;
      }
      const res = await axiosInstance.get(url);
      if (res.status === 200) {
        let filteredUsers = res.data;
        if (mfaFilter !== 'All') {
          filteredUsers = res.data.filter(user => user.mfaEnabled === (mfaFilter === 'Enabled'));
        }
        setUsers(filteredUsers);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Failed to fetch users');
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      getAllUsers();
      return;
    }
    try {
      const res = await axiosInstance.get(`/users/email?email=${encodeURIComponent(searchQuery)}`);
      if (res.status === 200) {
        setUsers([res.data]);
      } else if (res.status === 404) {
        setUsers([]);
        toast.error('No user found with that email');
      }
    } catch (error) {
      console.error('Error searching users:', error);
      setUsers([]);
      toast.error('Error searching users');
    }
  };

  const handleSave = async () => {
    try {
      if (modalMode === 'add') {
        const newUser = {
          fullName: currentUser.fullName,
          email: currentUser.email,
          password: currentUser.password,
          role: currentUser.role,
          mfaEnabled: currentUser.mfaEnabled,
          secret: currentUser.secret,
        };
        const res = await axiosInstance.post('/users', newUser);
        if (res.status === 201) {
          setUsers([...users, res.data]);
          toast.success('User created successfully');
        }
      } else {
        const updatedUser = {
          fullName: currentUser.fullName,
          role: currentUser.role,
          mfaEnabled: currentUser.mfaEnabled,
        };
        const res = await axiosInstance.put(`/users/${currentUser.id}`, updatedUser);
        if (res.status === 200) {
          setUsers(users.map(user => (user.id === currentUser.id ? res.data : user)));
          toast.success('User updated successfully');
        }
      }
      closeModal();
    } catch (error) {
      console.error('Error saving user:', error);
      toast.error(`Failed to ${modalMode === 'add' ? 'create' : 'update'} user`);
    }
  };

  const handleDeleteUser = (userId: number) => {
    setSelectedUserId(userId);
    setShowDeleteModal(true);
  };

  const deleteUserById = async () => {
    try {
      const res = await axiosInstance.delete(`/users/${selectedUserId}`);
      if (res.status === 204) {
        toast.success('User deleted successfully');
        getAllUsers();
        setShowDeleteModal(false);
        setSelectedUserId(null);
      }
    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error('Failed to delete user');
      setShowDeleteModal(false);
    }
  };

  const openModal = (mode: 'add' | 'edit', user = {
    id: '',
    fullName: '',
    email: '',
    password: '',
    role: 'USER',
    mfaEnabled: false,
    secret: '',
    createdAt: '',
  }) => {
    setModalMode(mode);
    setCurrentUser(user);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentUser({
      id: '',
      fullName: '',
      email: '',
      password: '',
      role: 'USER',
      mfaEnabled: false,
      secret: '',
      createdAt: '',
    });
  };

  useEffect(() => {
    getAllUsers();
  }, [roleFilter, mfaFilter]);

  const metrics = [
    {
      title: 'Total Users',
      value: users.length,
      icon: User,
      color: '#335C67',
    },
    {
      title: 'Admin Users',
      value: users.filter((user:any) => user.role === 'ADMIN').length,
      icon: Shield,
      color: '#E09F3E',
    },
    {
      title: 'MFA Enabled',
      value: users.filter((user:any) => user.mfaEnabled).length,
      icon: Key,
      color: '#9E2A2B',
    },
    {
      title: 'Recent Registrations',
      value: users.filter((user:any) => new Date(user.createdAt) > new Date('2024-07-10')).length,
      icon: Clock,
      color: '#540B0E',
    },
  ];

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'VENDOR':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'USER':
        return 'bg-accent-100 text-accent-800 border-accent-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
              User Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Administrative Overview • Real-time User Monitoring
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Search className="h-5 w-5 text-gray-400 absolute right-[25%]" />
              <input
                type="text"
                placeholder="Search by email"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="All">All Roles</option>
              <option value="ADMIN">Admin</option>
              <option value="VENDOR">Vendor</option>
              <option value="USER">User</option>
            </select>
            <select
              value={mfaFilter}
              onChange={(e) => setMfaFilter(e.target.value)}
              className="px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="All">All MFA Status</option>
              <option value="Enabled">MFA Enabled</option>
              <option value="Disabled">MFA Disabled</option>
            </select>
            <button
              onClick={() => openModal('add')}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
              style={{ color: '#335C67', borderColor: '#335C67' }}
            >
              <User className="h-4 w-4 mr-2" style={{ color: '#335C67' }} />
              Add User
            </button>
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                    {metric.title}
                  </p>
                  <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
                    {metric.value}
                  </p>
                </div>
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
                  <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Users Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">User Accounts</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User Details
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Role
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    MFA Status
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Created At
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {users.map((user: any) => (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4" style={{ color: '#540B0E' }} />
                        <div>
                          <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                            {user.fullName}
                          </p>
                          <p className="text-xs text-gray-500">
                            ID: {user.id}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-1">
                        <Mail className="h-3 w-3" style={{ color: '#9E2A2B' }} />
                        <span className="text-sm" style={{ color: '#9E2A2B' }}>
                          {user.email}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getRoleColor(user.role)}`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${user.mfaEnabled ? 'bg-green-100 text-green-800 border-green-200' : 'bg-red-100 text-red-800 border-red-200'}`}>
                        {user.mfaEnabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-3 w-3" style={{ color: '#335C67' }} />
                        <span className="text-sm" style={{ color: '#335C67' }}>
                          {new Date(user.createdAt).toLocaleString()}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => openModal('edit', user)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#335C67', borderColor: '#335C67' }}
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeleteUser(user.id)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* User Modal */}
       {
        isModalOpen &&  <UserModal
          isOpen={isModalOpen}
          onClose={closeModal}
          mode={modalMode}
          user={currentUser}
          setUser={setCurrentUser}
          onSave={handleSave}
        />
       }

        {/* Confirmation Modal */}
        {
          showDeleteModal && <ConfirmationModal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          confirmationText="Are you sure you want to delete this user? This action cannot be undone."
          actionText="Confirm"
          action={deleteUserById}
          title="Confirm Delete"
        />
        }
      </div>
    </div>
  );
};

export default Users;