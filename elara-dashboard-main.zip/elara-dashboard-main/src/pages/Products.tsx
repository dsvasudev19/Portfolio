// import React, { useState, useEffect } from 'react';
// import { ChevronDown, ChevronUp, Package, DollarSign, Tag, Clock, Image, Search, Trash, Edit } from 'lucide-react';
// import { useNavigate } from 'react-router-dom';
// import { toast } from 'react-hot-toast';
// import { axiosInstance } from '../../axiosInstance';
// import ConfirmationModal from '../modals/ConfirmationDialog';

// const Products = () => {
//   const [expandedRows, setExpandedRows] = useState({});
//   const [products, setProducts] = useState([]);
//   const [metrics, setMetrics] = useState({
//     totalProducts: 0,
//     totalInventoryValue: 0,
//     categories: 0,
//     lowStockVariants: 0,
//   });
//   const [page, setPage] = useState(0);
//   const [size] = useState(10);
//   const [totalPages, setTotalPages] = useState(0);
//   const [searchQuery, setSearchQuery] = useState('');
//   const [showDeleteModal,setShowDeleteModal]=useState(false);
//   const [selectedProductId,setSelectedProductId]=useState<any>()

//   const navigate = useNavigate();

//   const toggleRow = (productId) => {
//     setExpandedRows((prev) => ({
//       ...prev,
//       [productId]: !prev[productId],
//     }));
//   };

//   const fetchProducts = async () => {
//     try {
//       const params = { page, size, ...(searchQuery && { q: searchQuery }) };
//       const res = await axiosInstance.get('/products', { params });
//       if (res.status === 200) {
//         setProducts(res.data.content);
//         setTotalPages(res.data.totalPages);
//       }
//     } catch (error) {
//       console.error('Error fetching products:', error);
//       toast.error('Failed to fetch products');
//     }
//   };

//   const fetchMetrics = async () => {
//     try {
//       const res = await axiosInstance.get('/products/metrics');
//       if (res.status === 200) {
//         setMetrics(res.data);
//       }
//     } catch (error) {
//       console.error('Error fetching metrics:', error);
//       toast.error('Failed to fetch product metrics');
//     }
//   };

//   const handleDelete = async (productId) => {
//     setShowDeleteModal(true)
//     setSelectedProductId(productId);

//   };

//   const deleteProductById=async()=>{
//     try {
//       const res = await axiosInstance.delete(`/products/${selectedProductId}`);
//       if (res.status === 204) {
//         toast.success('Product deleted successfully!');
//         fetchProducts(); // Refresh the product list
//       }
//     } catch (error:any) {
//       console.error('Error deleting product:', error);
//       toast.error(error.response?.data?.message || 'Failed to delete product');
//     }
//   }

//   const handleEdit = (productId) => {
//     window.location.href = `/dashboard/products/update-details/${productId}`;
//   };

//   const handlePageChange = (newPage) => {
//     if (newPage >= 0 && newPage < totalPages) {
//       setPage(newPage);
//     }
//   };

//   const handleSearch = (e) => {
//     setSearchQuery(e.target.value);
//     setPage(0); // Reset to first page on search
//   };

//   useEffect(() => {
//     fetchProducts();
//     fetchMetrics();
//   }, [page, searchQuery]);

//   const metricsData = [
//     {
//       title: 'Total Products',
//       value: metrics.totalProducts,
//       icon: Package,
//       color: '#335C67',
//     },
//     {
//       title: 'Total Inventory Value',
//       value: `$${metrics?.totalInventoryValue?.toFixed(2)}`,
//       icon: DollarSign,
//       color: '#E09F3E',
//     },
//     {
//       title: 'Categories',
//       value: metrics.categories,
//       icon: Tag,
//       color: '#9E2A2B',
//     },
//     {
//       title: 'Low Stock Variants',
//       value: metrics.lowStockVariants,
//       icon: Clock,
//       color: '#540B0E',
//     },
//   ];

//   const getStockColor = (stock: any) => {
//     if (stock < 10) return 'bg-red-100 text-red-800 border-red-200';
//     if (stock < 20) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
//     return 'bg-green-100 text-green-800 border-green-200';
//   };

//   return (
//     <div className="min-h-screen bg-gray-50 p-4">
//       <div className="mx-auto">
//         {/* Header */}
//         <div className="mb-6 flex justify-between items-center">
//           <div>
//             <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
//               Product Management Dashboard
//             </h1>
//             <p className="text-sm text-gray-600">
//               Inventory Overview • Real-time Product Tracking
//             </p>
//           </div>
//           <button
//             onClick={() => navigate('/dashboard/products/add-product')}
//             className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
//             style={{ color: '#335C67', borderColor: '#335C67' }}
//           >
//             <Package className="h-4 w-4 mr-2" style={{ color: '#335C67' }} />
//             Add Product
//           </button>
//         </div>

//         {/* Search */}
//         <div className="mb-6">
//           <div className="relative">
//             <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
//             <input
//               type="text"
//               value={searchQuery}
//               onChange={handleSearch}
//               placeholder="Search products..."
//               className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2"
//               style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
//             />
//           </div>
//         </div>

//         {/* Metrics Cards */}
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
//           {metricsData.map((metric, index) => (
//             <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
//               <div className="flex items-center justify-between">
//                 <div>
//                   <p className="text-xs font-medium text-gray-600 uppercase">
//                     {metric.title}
//                   </p>
//                   <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
//                     {metric.value}
//                   </p>
//                 </div>
//                 <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
//                   <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
//                 </div>
//               </div>
//             </div>
//           ))}
//         </div>

//         {/* Products Table */}
//         <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
//           <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
//             <h2 className="text-sm font-semibold text-white">Product Catalog</h2>
//           </div>

//           <div className="overflow-x-auto">
//             <table className="w-full">
//               <thead className="bg-gray-50">
//                 <tr>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Product Details
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     SKU
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Category
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Base Price
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Total Stock
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Created At
//                   </th>
//                   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
//                     Actions
//                   </th>
//                 </tr>
//               </thead>
//               <tbody className="bg-white divide-y divide-gray-200">
//                 {products.map((product: any) => (
//                   <React.Fragment key={product.id}>
//                     <tr className="hover:bg-gray-50">
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-2">
//                           {product.mediaUrls && product.mediaUrls.length > 0 ? (
//                             <img
//                               src={`${product.mediaUrls[0]}`}
//                               alt={product.name}
//                               className="w-8 h-8 object-cover rounded"
//                             />
//                           ) : (
//                             <Image className="h-6 w-6 text-gray-400" />
//                           )}
//                           <div>
//                             <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                               {product.name}
//                             </p>
//                             <p className="text-xs text-gray-500">
//                               ID: {product.id}
//                             </p>
//                           </div>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <span className="text-sm" style={{ color: '#9E2A2B' }}>
//                           {product.sku}
//                         </span>
//                       </td>
//                       <td className="px-4 py-3">
//                         <span className="text-sm" style={{ color: '#335C67' }}>
//                           {product.category || 'N/A'}
//                         </span>
//                       </td>
//                       <td className="px-4 py-3">
//                         <span className="text-sm font-bold" style={{ color: '#540B0E' }}>
//                           ${product.price.toFixed(2)}
//                         </span>
//                       </td>
//                       <td className="px-4 py-3">
//                         <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStockColor(product.stock)}`}>
//                           {product.stock}
//                         </span>
//                       </td>
//                       <td className="px-4 py-3">
//                         <div className="flex items-center space-x-1">
//                           <Clock className="h-3 w-3" style={{ color: '#335C67' }} />
//                           <span className="text-sm" style={{ color: '#335C67' }}>
//                             {new Date(product.createdAt).toLocaleString()}
//                           </span>
//                         </div>
//                       </td>
//                       <td className="px-4 py-3">
//                         <div className="flex space-x-2">
//                           <button
//                             onClick={() => handleEdit(product.id)}
//                             className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors"
//                             style={{ color: '#335C67', borderColor: '#335C67' }}
//                           >
//                             <Edit className="h-3 w-3 inline mr-1" />
//                             Edit
//                           </button>
//                           <button
//                             onClick={() => handleDelete(product.id)}
//                             className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors"
//                             style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
//                           >
//                             <Trash className="h-3 w-3 inline mr-1" />
//                             Delete
//                           </button>
//                           <button
//                             onClick={() => toggleRow(product.id)}
//                             className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors"
//                             style={{ color: '#335C67', borderColor: '#335C67' }}
//                           >
//                             {expandedRows[product.id] ? (
//                               <>
//                                 <ChevronUp className="h-3 w-3 inline mr-1" />
//                                 Hide
//                               </>
//                             ) : (
//                               <>
//                                 <ChevronDown className="h-3 w-3 inline mr-1" />
//                                 View
//                               </>
//                             )}
//                           </button>
//                         </div>
//                       </td>
//                     </tr>

//                     {expandedRows[product.id] && (
//                       <tr>
//                         <td colSpan="7" className="px-4 py-4 bg-gray-50">
//                           <div className="space-y-4">
//                             <div className="border rounded-lg overflow-hidden">
//                               <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
//                                 <Tag className="h-4 w-4" style={{ color: '#540B0E' }} />
//                                 <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                                   Variants ({product.variants.length})
//                                 </span>
//                               </div>
//                               <div className="bg-white">
//                                 {product.variants.map((variant, index) => (
//                                   <div key={variant.id} className={`px-4 py-3 ${index !== product.variants.length - 1 ? 'border-b' : ''}`}>
//                                     <div className="flex items-center justify-between">
//                                       <div>
//                                         <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                                           Variant ID: {variant.id}
//                                         </p>
//                                         {variant.attributes && Object.entries(variant.attributes).map(([key, value]) => (
//                                           <p key={key} className="text-sm" style={{ color: '#9E2A2B' }}>
//                                             {key}: {value || 'N/A'}
//                                           </p>
//                                         ))}
//                                       </div>
//                                       <div className="text-right">
//                                         <p className="text-sm font-bold" style={{ color: '#335C67' }}>
//                                           ${variant.price.toFixed(2)}
//                                         </p>
//                                         <p className={`text-sm px-2 py-1 rounded-full border ${getStockColor(variant.stock)}`}>
//                                           Stock: {variant.stock}
//                                         </p>
//                                       </div>
//                                     </div>
//                                   </div>
//                                 ))}
//                               </div>
//                             </div>
//                             <div className="border rounded-lg overflow-hidden">
//                               <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
//                                 <Image className="h-4 w-4" style={{ color: '#540B0E' }} />
//                                 <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                                   Media ({product.mediaUrls.length})
//                                 </span>
//                               </div>
//                               <div className="bg-white p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
//                                 {product.mediaUrls.map((media: any, index) => (
//                                   <div key={index}>
//                                     <img
//                                       src={`${media}`}
//                                       alt={product.name}
//                                       className="w-full h-24 object-cover rounded border"
//                                     />
//                                     <p className="text-xs text-gray-500 mt-1 truncate">
//                                       Image {index + 1}
//                                     </p>
//                                   </div>
//                                 ))}
//                               </div>
//                             </div>
//                             <div className="border rounded-lg overflow-hidden">
//                               <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
//                                 <Tag className="h-4 w-4" style={{ color: '#540B0E' }} />
//                                 <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
//                                   Tags ({product?.tags.length})
//                                 </span>
//                               </div>
//                               <div className="bg-white p-4 flex flex-wrap gap-2">
//                                 {product?.tags?.map((tag, index) => (
//                                   <span
//                                     key={index}
//                                     className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 border"
//                                     style={{ borderColor: '#335C67', color: '#335C67' }}
//                                   >
//                                     {tag}
//                                   </span>
//                                 ))}
//                               </div>
//                             </div>
//                           </div>
//                         </td>
//                       </tr>
//                     )}
//                   </React.Fragment>
//                 ))}
//               </tbody>
//             </table>
//           </div>

//           {/* Pagination Controls */}
//           <div className="px-4 py-3 border-t border-gray-200 flex justify-between items-center">
//             <button
//               onClick={() => handlePageChange(page - 1)}
//               disabled={page === 0}
//               className="px-4 py-2 border rounded-lg disabled:opacity-50"
//               style={{ borderColor: '#335C67', color: '#335C67' }}
//             >
//               Previous
//             </button>
//             <span className="text-sm text-gray-600">
//               Page {page + 1} of {totalPages}
//             </span>
//             <button
//               onClick={() => handlePageChange(page + 1)}
//               disabled={page >= totalPages - 1}
//               className="px-4 py-2 border rounded-lg disabled:opacity-50"
//               style={{ borderColor: '#335C67', color: '#335C67' }}
//             >
//               Next
//             </button>
//           </div>
//         </div>
//       </div>

//       {showDeleteModal && (
//           <ConfirmationModal
//             isOpen={showDeleteModal}
//             onClose={() => setShowDeleteModal(false)}
//             confirmationText="Are you sure you want to delete this Product? This action cannot be undone."
//             actionText="Delete"
//             action={deleteProductById}
//             title="Confirm Delete"
//           />
//         )}
//     </div>
//   );
// };

// export default Products;

import React, { useState, useEffect } from "react";
import {
  ChevronDown,
  ChevronUp,
  Package,
  DollarSign,
  Tag,
  Clock,
  Image,
  Search,
  Trash,
  Edit,
  Eye,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { axiosInstance } from "../../axiosInstance";
import ConfirmationModal from "../modals/ConfirmationDialog";

const Products = () => {
  const [expandedRows, setExpandedRows] = useState({});
  const [products, setProducts] = useState([]);
  const [metrics, setMetrics] = useState({
    totalProducts: 0,
    totalInventoryValue: 0,
    categories: 0,
    lowStockVariants: 0,
  });
  const [page, setPage] = useState(0);
  const [size] = useState(10);
  const [totalPages, setTotalPages] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<any>();

  const navigate = useNavigate();

  const toggleRow = (productId) => {
    setExpandedRows((prev) => ({
      ...prev,
      [productId]: !prev[productId],
    }));
  };

  const fetchProducts = async () => {
    try {
      const params = { page, size, ...(searchQuery && { q: searchQuery }) };
      const res = await axiosInstance.get("/products", { params });
      if (res.status === 200) {
        setProducts(res.data.content);
        setTotalPages(res.data.totalPages);
      }
    } catch (error) {
      console.error("Error fetching products:", error);
      toast.error("Failed to fetch products");
    }
  };

  const fetchMetrics = async () => {
    try {
      const res = await axiosInstance.get("/products/metrics");
      if (res.status === 200) {
        setMetrics(res.data);
      }
    } catch (error) {
      console.error("Error fetching metrics:", error);
      toast.error("Failed to fetch product metrics");
    }
  };

  const handleDelete = async (productId) => {
    setShowDeleteModal(true);
    setSelectedProductId(productId);
  };

  const deleteProductById = async () => {
    try {
      const res = await axiosInstance.delete(`/products/${selectedProductId}`);
      if (res.status === 204) {
        toast.success("Product deleted successfully!");
        fetchProducts();
      }
    } catch (error: any) {
      console.error("Error deleting product:", error);
      toast.error(error.response?.data?.message || "Failed to delete product");
    }
  };

  const handleEdit = (productId) => {
    window.location.href = `/dashboard/products/update-details/${productId}`;
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 0 && newPage < totalPages) {
      setPage(newPage);
    }
  };

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
    setPage(0);
  };

  useEffect(() => {
    fetchProducts();
    fetchMetrics();
  }, [page, searchQuery]);

  const metricsData = [
    {
      title: "Total Products",
      value: metrics.totalProducts,
      icon: Package,
      color: "#335C67",
    },
    {
      title: "Total Inventory Value",
      value: `₹${metrics?.totalInventoryValue?.toFixed(2)}`,
      icon: DollarSign,
      color: "#E09F3E",
    },
    {
      title: "Categories",
      value: metrics.categories,
      icon: Tag,
      color: "#9E2A2B",
    },
    {
      title: "Low Stock Variants",
      value: metrics.lowStockVariants,
      icon: Clock,
      color: "#540B0E",
    },
  ];

  const getStockColor = (stock: any) => {
    if (stock < 10) return "bg-red-100 text-red-800 border-red-200";
    if (stock < 20) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    return "bg-green-100 text-green-800 border-green-200";
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1
              className="text-2xl font-bold mb-2"
              style={{ color: "#540B0E" }}
            >
              Product Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Inventory Overview • Real-time Product Tracking
            </p>
          </div>
          <button
            onClick={() => navigate("/dashboard/products/add-product")}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
            style={{ color: "#335C67", borderColor: "#335C67" }}
          >
            <Package className="h-4 w-4 mr-2" style={{ color: "#335C67" }} />
            Add Product
          </button>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearch}
              placeholder="Search products..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2"
              style={{ borderColor: "#335C67", focusRingColor: "#335C67" }}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {metricsData.map((metric, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-4 shadow-sm border border-gray-200"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase">
                    {metric.title}
                  </p>
                  <p
                    className="text-xl font-bold mt-1"
                    style={{ color: metric.color }}
                  >
                    {metric.value}
                  </p>
                </div>
                <div
                  className="p-2 rounded-lg"
                  style={{ backgroundColor: `${metric.color}15` }}
                >
                  <metric.icon
                    className="h-5 w-5"
                    style={{ color: metric.color }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div
            className="px-4 py-3 border-b border-gray-200"
            style={{ backgroundColor: "#335C67" }}
          >
            <h2 className="text-sm font-semibold text-white">
              Product Catalog
            </h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Product Details
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    SKU
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Base Price
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total Stock
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Created At
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {products.map((product: any) => (
                  <React.Fragment key={product.id}>
                    <tr className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          {product.mediaUrls && product.mediaUrls.length > 0 ? (
                            <img
                              src={`${product.mediaUrls[0]}`}
                              alt={product.name}
                              className="w-8 h-8 object-cover rounded"
                            />
                          ) : (
                            <Image className="h-6 w-6 text-gray-400" />
                          )}
                          <div>
                            <p
                              className="text-sm font-medium"
                              style={{ color: "#540B0E" }}
                            >
                              {product.name}
                            </p>
                            <p className="text-xs text-gray-500">
                              ID: {product.id}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-sm" style={{ color: "#9E2A2B" }}>
                          {product.sku}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-sm" style={{ color: "#335C67" }}>
                          {product.category || "N/A"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className="text-sm font-bold"
                          style={{ color: "#540B0E" }}
                        >
                          ₹{product.price.toFixed(2)}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium border ${getStockColor(
                            product.stock
                          )}`}
                        >
                          {product.stock}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-1">
                          <Clock
                            className="h-3 w-3"
                            style={{ color: "#335C67" }}
                          />
                          <span
                            className="text-sm"
                            style={{ color: "#335C67" }}
                          >
                            {new Date(product.createdAt).toLocaleString()}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleEdit(product.id)}
                            className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors"
                            style={{ color: "#335C67", borderColor: "#335C67" }}
                          >
                            <Edit className="h-3 w-3 inline mr-1" />
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(product.id)}
                            className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors"
                            style={{ color: "#9E2A2B", borderColor: "#9E2A2B" }}
                          >
                            <Trash className="h-3 w-3 inline mr-1" />
                            Delete
                          </button>

                          <button
                            onClick={() => toggleRow(product.id)}
                            className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors"
                            style={{ color: "#335C67", borderColor: "#335C67" }}
                          >
                            {expandedRows[product.id] ? (
                              <>
                                <ChevronUp className="h-3 w-3 inline mr-1" />
                                Hide
                              </>
                            ) : (
                              <>
                                <ChevronDown className="h-3 w-3 inline mr-1" />
                                View
                              </>
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>

                    {expandedRows[product.id] && (
                      <tr>
                        <td colSpan="7" className="px-4 py-4 bg-gray-50">
                          <div className="space-y-4">
                            <div className="flex justify-end">
                              <button
                                onClick={() =>
                                  navigate(
                                    `/dashboard/products/view-details/${product.id}`
                                  )
                                }
                                className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                                style={{
                                  color: "#335C67",
                                  borderColor: "#335C67",
                                }}
                              >
                                <Eye className="h-3 w-3 inline mr-1" />
                                View Details
                              </button>
                            </div>
                            <div className="border rounded-lg overflow-hidden">
                              <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
                                <Tag
                                  className="h-4 w-4"
                                  style={{ color: "#540B0E" }}
                                />
                                <span
                                  className="text-sm font-medium"
                                  style={{ color: "#540B0E" }}
                                >
                                  Variants ({product.variants.length})
                                </span>
                              </div>
                              <div className="bg-white">
                                {product.variants.map((variant, index) => (
                                  <div
                                    key={variant.id}
                                    className={`px-4 py-3 ${
                                      index !== product.variants.length - 1
                                        ? "border-b"
                                        : ""
                                    }`}
                                  >
                                    <div className="flex items-center justify-between">
                                      <div>
                                        <p
                                          className="text-sm font-medium"
                                          style={{ color: "#540B0E" }}
                                        >
                                          Variant ID: {variant.id}
                                        </p>
                                        {variant.attributes &&
                                          Object.entries(
                                            variant.attributes
                                          ).map(([key, value]) => (
                                            <p
                                              key={key}
                                              className="text-sm"
                                              style={{ color: "#9E2A2B" }}
                                            >
                                              {key}: {value || "N/A"}
                                            </p>
                                          ))}
                                      </div>
                                      <div className="text-right">
                                        <p
                                          className="text-sm font-bold"
                                          style={{ color: "#335C67" }}
                                        >
                                          ₹{variant.price.toFixed(2)}
                                        </p>
                                        <p
                                          className={`text-sm px-2 py-1 rounded-full border ${getStockColor(
                                            variant.stock
                                          )}`}
                                        >
                                          Stock: {variant.stock}
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                            <div className="border rounded-lg overflow-hidden">
                              <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
                                <Image
                                  className="h-4 w-4"
                                  style={{ color: "#540B0E" }}
                                />
                                <span
                                  className="text-sm font-medium"
                                  style={{ color: "#540B0E" }}
                                >
                                  Media ({product.mediaUrls.length})
                                </span>
                              </div>
                              <div className="bg-white p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                                {product.mediaUrls.map((media: any, index) => (
                                  <div key={index}>
                                    <img
                                      src={`${media}`}
                                      alt={product.name}
                                      className="w-full h-24 object-cover rounded border"
                                    />
                                    <p className="text-xs text-gray-500 mt-1 truncate">
                                      Image {index + 1}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            </div>
                            <div className="border rounded-lg overflow-hidden">
                              <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
                                <Tag
                                  className="h-4 w-4"
                                  style={{ color: "#540B0E" }}
                                />
                                <span
                                  className="text-sm font-medium"
                                  style={{ color: "#540B0E" }}
                                >
                                  Tags ({product?.tags.length})
                                </span>
                              </div>
                              <div className="bg-white p-4 flex flex-wrap gap-2">
                                {product?.tags?.map((tag, index) => (
                                  <span
                                    key={index}
                                    className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 border"
                                    style={{
                                      borderColor: "#335C67",
                                      color: "#335C67",
                                    }}
                                  >
                                    {tag}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-4 py-3 border-t border-gray-200 flex justify-between items-center">
            <button
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 0}
              className="px-4 py-2 border rounded-lg disabled:opacity-50"
              style={{ borderColor: "#335C67", color: "#335C67" }}
            >
              Previous
            </button>
            <span className="text-sm text-gray-600">
              Page {page + 1} of {totalPages}
            </span>
            <button
              onClick={() => handlePageChange(page + 1)}
              disabled={page >= totalPages - 1}
              className="px-4 py-2 border rounded-lg disabled:opacity-50"
              style={{ borderColor: "#335C67", color: "#335C67" }}
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {showDeleteModal && (
        <ConfirmationModal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          confirmationText="Are you sure you want to delete this Product? This action cannot be undone."
          actionText="Delete"
          action={deleteProductById}
          title="Confirm Delete"
        />
      )}
    </div>
  );
};

export default Products;
