
import { useEffect, useState } from 'react';
import {  Star, X, Edit, Trash } from 'lucide-react';
import { axiosInstance } from '../../axiosInstance';

const Reviews = () => {
  const [reviews, setReviews] = useState([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [pageSize] = useState(10);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' or 'edit'
  const [currentReview, setCurrentReview] = useState({
    id: '',
    productId: '',
    userId: '',
    rating: 1,
    comment: '',
    status: 'PENDING'
  });

  const openModal = (mode:string, review = {
    id: '',
    productId: '',
    userId: '',
    rating: 1,
    comment: '',
    status: 'PENDING'
  }) => {
    setModalMode(mode);
    setCurrentReview(review);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentReview({
      id: '',
      productId: '',
      userId: '',
      rating: 1,
      comment: '',
      status: 'PENDING'
    });
  };

  const handleSave = () => {
    if (modalMode === 'add') {
      const newReview = {
        ...currentReview,
        id: `REV-${(reviews.length + 1).toString().padStart(3, '0')}`
      };
      setReviews([...reviews, newReview]);
    } else {
      setReviews(reviews.map(rev => (rev.id === currentReview.id ? currentReview : rev)));
    }
    closeModal();
  };

  const handleDelete = (id) => {
    setReviews(reviews.filter(rev => rev.id !== id));
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 0 && newPage < totalPages) {
      setPage(newPage);
    }
  };

  const getAllReviews = async () => {
    try {
      const res = await axiosInstance.get(`/reviews?page=${page}&size=${pageSize}`);
      if (res.status === 200) {
        setReviews(res.data.content);
        setTotalPages(res.data.totalPages);
      }
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  useEffect(() => {
    getAllReviews();
  }, [page]);




  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
              Review Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Customer Feedback Overview • Real-time Review Tracking
            </p>
          </div>
        </div>


        {/* Reviews Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">Review List</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Review Details
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Product (SKU)
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rating
                  </th>
       
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {reviews.map((review) => (
                  <tr key={review.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <Star className="h-4 w-4" style={{ color: '#540B0E' }} />
                        <div>
                          <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                            {review.comment}
                          </p>
                          <p className="text-xs text-gray-500">
                            ID: {review.id}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                        {review?.product?.name}{` `}{`(${review?.product?.sku})`}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                        {review?.user?.fullName}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-bold" style={{ color: '#E09F3E' }}>
                        {review.rating}/5
                      </p>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => openModal('edit', review)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#335C67', borderColor: '#335C67' }}
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(review.id)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                        >
                          <Trash className="h-3 w-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="px-4 py-3 border-t border-gray-200 flex justify-between items-center">
            <button
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 0}
              className="px-4 py-2 border rounded-lg disabled:opacity-50"
              style={{ borderColor: '#335C67', color: '#335C67' }}
            >
              Previous
            </button>
            <span className="text-sm text-gray-600">
              Page {page + 1} of {totalPages}
            </span>
            <button
              onClick={() => handlePageChange(page + 1)}
              disabled={page >= totalPages - 1}
              className="px-4 py-2 border rounded-lg disabled:opacity-50"
              style={{ borderColor: '#335C67', color: '#335C67' }}
            >
              Next
            </button>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
                  {modalMode === 'add' ? 'Add Review' : 'Edit Review'}
                </h2>
                <button onClick={closeModal}>
                  <X className="h-5 w-5" style={{ color: '#335C67' }} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Product ID
                  </label>
                  <input
                    type="text"
                    value={currentReview.productId}
                    onChange={(e) => setCurrentReview({ ...currentReview, productId: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    User ID
                  </label>
                  <input
                    type="text"
                    value={currentReview.userId}
                    onChange={(e) => setCurrentReview({ ...currentReview, userId: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Rating
                  </label>
                  <select
                    value={currentReview.rating}
                    onChange={(e) => setCurrentReview({ ...currentReview, rating: parseInt(e.target.value) })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  >
                    {[1, 2, 3, 4, 5].map(num => (
                      <option key={num} value={num}>{num}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Comment
                  </label>
                  <textarea
                    value={currentReview.comment}
                    onChange={(e) => setCurrentReview({ ...currentReview, comment: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                    rows="4"
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <button
                    onClick={closeModal}
                    className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
                    style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
                    style={{ color: '#335C67', borderColor: '#335C67' }}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Reviews;