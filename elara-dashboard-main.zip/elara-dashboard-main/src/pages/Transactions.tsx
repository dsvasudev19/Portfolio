import React, { useState } from 'react';
import { Tag, DollarSign, Clock, X, Edit, Trash } from 'lucide-react';

const Transactions = () => {
  const [transactions, setTransactions] = useState([
    {
      id: 'TXN-001',
      type: 'ORDER_PAYMENT',
      amount: 1299.99,
      orderId: 'ORD-001',
      userId: 'USR-001',
      status: 'SUCCESS',
      transactionDate: '2025-07-14 10:15:30',
      description: 'Payment via Credit Card for Sapphire Pendant Necklace'
    },
    {
      id: 'TXN-002',
      type: 'WALLET_CREDIT',
      amount: 500.00,
      orderId: null,
      userId: 'USR-002',
      status: 'SUCCESS',
      transactionDate: '2025-07-13 14:22:45',
      description: 'Gift Card Redemption'
    },
    {
      id: 'TXN-003',
      type: 'WALLET_DEBIT',
      amount: -89.99,
      orderId: null,
      userId: 'USR-003',
      status: 'PENDING',
      transactionDate: '2025-07-15 09:10:12',
      description: 'Wallet Payment for Handbound Leather Journal'
    }
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' or 'edit'
  const [currentTransaction, setCurrentTransaction] = useState({
    id: '',
    type: 'ORDER_PAYMENT',
    amount: 0,
    orderId: '',
    userId: '',
    status: 'SUCCESS',
    transactionDate: '',
    description: ''
  });

  const openModal = (mode, transaction = {
    id: '',
    type: 'ORDER_PAYMENT',
    amount: 0,
    orderId: '',
    userId: '',
    status: 'SUCCESS',
    transactionDate: '',
    description: ''
  }) => {
    setModalMode(mode);
    setCurrentTransaction(transaction);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentTransaction({
      id: '',
      type: 'ORDER_PAYMENT',
      amount: 0,
      orderId: '',
      userId: '',
      status: 'SUCCESS',
      transactionDate: '',
      description: ''
    });
  };

  const handleSave = () => {
    if (modalMode === 'add') {
      const newTransaction = {
        ...currentTransaction,
        id: `TXN-${(transactions.length + 1).toString().padStart(3, '0')}`
      };
      setTransactions([...transactions, newTransaction]);
    } else {
      setTransactions(transactions.map(txn => (txn.id === currentTransaction.id ? currentTransaction : txn)));
    }
    closeModal();
  };

  const handleDelete = (id) => {
    setTransactions(transactions.filter(txn => txn.id !== id));
  };

  const metrics = [
    {
      title: 'Total Transactions',
      value: transactions.length,
      icon: Tag,
      color: '#335C67'
    },
    {
      title: 'Successful Transactions',
      value: transactions.filter(txn => txn.status === 'SUCCESS').length,
      icon: DollarSign,
      color: '#E09F3E'
    },
    {
      title: 'Failed Transactions',
      value: transactions.filter(txn => txn.status === 'FAILED').length,
      icon: Clock,
      color: '#9E2A2B'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'SUCCESS': return 'bg-green-100 text-green-800 border-green-200';
      case 'PENDING': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'FAILED': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'ORDER_PAYMENT': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'WALLET_CREDIT': return 'bg-green-100 text-green-800 border-green-200';
      case 'WALLET_DEBIT': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
              Transaction Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Financial Overview • Real-time Transaction Tracking
            </p>
          </div>

        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                    {metric.title}
                  </p>
                  <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
                    {metric.value}
                  </p>
                </div>
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
                  <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Transactions Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">Transaction List</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Transaction Details
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Order ID
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User ID
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Transaction Date
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {transactions.map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <Tag className="h-4 w-4" style={{ color: '#540B0E' }} />
                        <div>
                          <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                            {transaction.description}
                          </p>
                          <p className="text-xs text-gray-500">
                            ID: {transaction.id}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getTypeColor(transaction.type)}`}>
                        {transaction.type}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-bold" style={{ color: transaction.amount < 0 ? '#9E2A2B' : '#540B0E' }}>
                        ₹{Math.abs(transaction.amount).toFixed(2)}{transaction.amount < 0 ? ' (Debit)' : ''}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#335C67' }}>
                        {transaction.orderId || '-'}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                        {transaction.userId}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(transaction.status)}`}>
                        {transaction.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-3 w-3" style={{ color: '#335C67' }} />
                        <p className="text-sm" style={{ color: '#335C67' }}>
                          {transaction.transactionDate}
                        </p>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => openModal('edit', transaction)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#335C67', borderColor: '#335C67' }}
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(transaction.id)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                        >
                          <Trash className="h-3 w-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
                  {modalMode === 'add' ? 'Add Transaction' : 'Edit Transaction'}
                </h2>
                <button onClick={closeModal}>
                  <X className="h-5 w-5" style={{ color: '#335C67' }} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Transaction Type
                  </label>
                  <select
                    value={currentTransaction.type}
                    onChange={(e) => setCurrentTransaction({ ...currentTransaction, type: e.target.value, orderId: e.target.value !== 'ORDER_PAYMENT' ? '' : currentTransaction.orderId })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  >
                    <option value="ORDER_PAYMENT">Order Payment</option>
                    <option value="WALLET_CREDIT">Wallet Credit</option>
                    <option value="WALLET_DEBIT">Wallet Debit</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Amount
                  </label>
                  <input
                    type="number"
                    value={currentTransaction.amount}
                    onChange={(e) => setCurrentTransaction({ ...currentTransaction, amount: parseFloat(e.target.value) })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                    step="0.01"
                  />
                </div>
                {currentTransaction.type === 'ORDER_PAYMENT' && (
                  <div>
                    <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                      Order ID
                    </label>
                    <input
                      type="text"
                      value={currentTransaction.orderId}
                      onChange={(e) => setCurrentTransaction({ ...currentTransaction, orderId: e.target.value })}
                      className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                      style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                    />
                  </div>
                )}
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    User ID
                  </label>
                  <input
                    type="text"
                    value={currentTransaction.userId}
                    onChange={(e) => setCurrentTransaction({ ...currentTransaction, userId: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Status
                  </label>
                  <select
                    value={currentTransaction.status}
                    onChange={(e) => setCurrentTransaction({ ...currentTransaction, status: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  >
                    <option value="SUCCESS">Success</option>
                    <option value="PENDING">Pending</option>
                    <option value="FAILED">Failed</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Transaction Date
                  </label>
                  <input
                    type="datetime-local"
                    value={currentTransaction.transactionDate}
                    onChange={(e) => setCurrentTransaction({ ...currentTransaction, transactionDate: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                    Description
                  </label>
                  <textarea
                    value={currentTransaction.description}
                    onChange={(e) => setCurrentTransaction({ ...currentTransaction, description: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2"
                    style={{ borderColor: '#335C67', focusRingColor: '#335C67' }}
                    rows="4"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={closeModal}
                    className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
                    style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
                    style={{ color: '#335C67', borderColor: '#335C67' }}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Transactions;