
import React, { useEffect, useState } from 'react';
import { Tag, DollarSign, Package, Trash2, Edit, Search, Image } from 'lucide-react';
import CategoryModal from '../modals/Category';
import { axiosInstance } from '../../axiosInstance';
import ConfirmationModal from '../modals/ConfirmationDialog';
import toast from 'react-hot-toast';

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [metrics, setMetrics] = useState({
    totalCategories: 0,
    activeCategories: 0,
    deletedCategories: 0,
    categoriesWithProducts: 0,
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add');
  const [currentCategory, setCurrentCategory] = useState({ 
    id: null, 
    name: '', 
    description: '', 
    status: 'Active', 
    images: [], 
    variantAttributes: [] 
  });
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(10);
  const [totalPages, setTotalPages] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [productCountFilter, setProductCountFilter] = useState('');
  const [includeMedia, setIncludeMedia] = useState(false);

  const getAllCategories = async () => {
    try {
      const params = { page, size, includeMedia, ...(searchQuery && { q: searchQuery }) };
      let res;
      if (statusFilter) {
        res = await axiosInstance.get(`/categories/status/${statusFilter}`, { params });
      } else if (productCountFilter) {
        res = await axiosInstance.get(`/categories/products/count/${productCountFilter}`, { params });
      } else {
        res = await axiosInstance.get('/categories', { params });
      }
      if (res.status === 200) {
        setCategories(res.data.content);
        setTotalPages(res.data.totalPages);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast.error('Failed to fetch categories');
    }
  };

  const getGlobalMetrics = async () => {
    try {
      const res = await axiosInstance.get('/categories/metrics');
      if (res.status === 200) {
        setMetrics(res.data);
      }
    } catch (error) {
      console.error('Error fetching metrics:', error);
      toast.error('Failed to fetch category metrics');
    }
  };

  const handleSave = async () => {
    try {
      const formData = new FormData();
      const categoryData = {
        name: currentCategory.name,
        description: currentCategory.description,
        status: currentCategory.status,
        variantAttributes: currentCategory.variantAttributes,
      };
      formData.append('category', new Blob([JSON.stringify(categoryData)], { type: 'application/json' }));
      if (currentCategory.images && currentCategory.images.length > 0) {
        currentCategory.images.forEach((image) => {
          formData.append('images', image);
        });
      }

      if (modalMode === 'add') {
        const res = await axiosInstance.post('/categories', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        if (res.status === 201) {
          setCategories(prev => [...prev, res.data]);
          toast.success('Category created successfully');
        }
      } else {
        const res = await axiosInstance.put(`/categories/${currentCategory.id}`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        if (res.status === 200) {
          setCategories(categories.map(cat => (cat.id === currentCategory.id ? res.data : cat)));
          toast.success('Category updated successfully');
        }
      }
      closeModal();
      getGlobalMetrics();
    } catch (error) {
      console.error('Error saving category:', error);
      toast.error(error.response?.data?.message || 'Failed to save category');
    }
  };

  const handleDelete = (id) => {
    setIsModalOpen(false);
    setSelectedCategoryId(id);
    setShowDeleteModal(true);
  };

  const deleteCategoryById = async () => {
    try {
      const res = await axiosInstance.delete(`/categories/${selectedCategoryId}`);
      if (res.status === 204) {
        setCategories(categories.filter(cat => cat.id !== selectedCategoryId));
        setShowDeleteModal(false);
        setSelectedCategoryId(null);
        toast.success("Category deleted successfully");
        getGlobalMetrics();
      }
    } catch (error) {
      console.error('Error deleting category:', error);
      toast.error('Failed to delete category');
      setShowDeleteModal(false);
    }
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 0 && newPage < totalPages) {
      setPage(newPage);
    }
  };

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
    setPage(0);
  };

  const handleStatusFilter = (e) => {
    setStatusFilter(e.target.value);
    setPage(0);
  };

  const handleProductCountFilter = (e) => {
    setProductCountFilter(e.target.value);
    setPage(0);
  };

  const handleIncludeMediaChange = (e) => {
    setIncludeMedia(e.target.checked);
    setPage(0);
  };

  useEffect(() => {
    getAllCategories();
    getGlobalMetrics();
  }, [page, size, searchQuery, statusFilter, productCountFilter, includeMedia]);

  const metricsData = [
    {
      title: 'Total Categories',
      value: metrics.totalCategories,
      icon: Tag,
      color: '#335C67',
    },
    {
      title: 'Active Categories',
      value: metrics.activeCategories,
      icon: Package,
      color: '#E09F3E',
    },
    {
      title: 'Deleted Categories',
      value: metrics.deletedCategories,
      icon: Trash2,
      color: '#9E2A2B',
    },
    {
      title: 'Categories with Products',
      value: metrics.categoriesWithProducts,
      icon: DollarSign,
      color: '#540B0E',
    },
  ];

  const openModal = (mode, category = { id: null, name: '', description: '', status: 'Active', images: [], variantAttributes: [] }) => {
    setModalMode(mode);
    setCurrentCategory(category);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentCategory({ id: null, name: '', description: '', status: 'Active', images: [], variantAttributes: [] });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Inactive':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
              Category Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Catalog Overview • Real-time Category Tracking
            </p>
          </div>
          <button
            onClick={() => openModal('add')}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
            style={{ color: '#335C67', borderColor: '#335C67' }}
          >
            <Tag className="h-4 w-4 mr-2" style={{ color: '#335C67' }} />
            Add Category
          </button>
        </div>

        {/* Filters and Search */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearch}
              placeholder="Search categories..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-secondary border-secondary"
            />
          </div>
          <select
            value={statusFilter}
            onChange={handleStatusFilter}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-secondary border-secondary"
          >
            <option value="">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
          <div className="flex items-center">
            <input
              type="checkbox"
              checked={includeMedia}
              onChange={handleIncludeMediaChange}
              className="mr-2"
            />
            <label className="text-sm text-gray-600">Include Media</label>
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {metricsData.map((metric, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                    {metric.title}
                  </p>
                  <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
                    {metric.value}
                  </p>
                </div>
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
                  <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Categories Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">Category List</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category Details
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Variant Attributes
                  </th>
                {
                  includeMedia &&   <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Media
                  </th>
                }
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {categories.map((category) => (
                  <tr key={category.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <Tag className="h-4 w-4" style={{ color: '#540B0E' }} />
                        <div>
                          <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                            {category.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            ID: {category.id}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                        {category.description}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(category.status)}`}>
                        {category.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm text-gray-600">
                        {category.variantAttributes && category.variantAttributes.length > 0 
                          ? category.variantAttributes.join(', ') 
                          : 'None'}
                      </p>
                    </td>
                    {
                      includeMedia && <td className="px-4 py-3">
                      {includeMedia && category.mediaUrls && category.mediaUrls.length > 0 ? (
                        <div className="flex space-x-2">
                          {category.mediaUrls.map((url, index) => (
                            <img
                              key={index}
                              src={url}
                              alt={`Category ${category.name} media ${index + 1}`}
                              className="h-10 w-10 object-cover rounded"
                            />
                          ))}
                        </div>
                      ) : (
                        <span className="text-xs text-gray-500">No media</span>
                      )}
                    </td>
                    }
                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => openModal('edit', { ...category, images: [] })}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#335C67', borderColor: '#335C67' }}
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(category.id)}
                          className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                          style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <div className="px-4 py-3 border-t border-gray-200 flex justify-between items-center">
            <button
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 0}
              className="px-4 py-2 border rounded-lg disabled:opacity-50"
              style={{ borderColor: '#335C67', color: '#335C67' }}
            >
              Previous
            </button>
            <span className="text-sm text-gray-600">
              Page {page + 1} of {totalPages}
            </span>
            <button
              onClick={() => handlePageChange(page + 1)}
              disabled={page >= totalPages - 1}
              className="px-4 py-2 border rounded-lg disabled:opacity-50"
              style={{ borderColor: '#335C67', color: '#335C67' }}
            >
              Next
            </button>
          </div>
        </div>

        {/* Category Modal */}
        {isModalOpen && (
          <CategoryModal
            isOpen={isModalOpen}
            onClose={closeModal}
            mode={modalMode}
            category={currentCategory}
            setCategory={setCurrentCategory}
            onSave={handleSave}
          />
        )}

        {/* Confirmation Modal for Delete */}
        {showDeleteModal && (
          <ConfirmationModal
            isOpen={showDeleteModal}
            onClose={() => setShowDeleteModal(false)}
            confirmationText="Are you sure you want to delete this category? This action cannot be undone."
            actionText="Delete"
            action={deleteCategoryById}
            title="Confirm Delete"
          />
        )}
      </div>
    </div>
  );
};

export default Categories;