import React, { useState } from 'react';
import { DollarSign, ShoppingCart, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Users, Package, CreditCard, Eye } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Area, AreaChart, ComposedChart, RadialBarChart, RadialBar, Legend } from 'recharts';

const Dashboard = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('today');

  // Essential metrics
  const metrics = {
    todayRevenue: { value: 12450, change: 8.3, trend: 'up' },
    todayOrders: { value: 23, change: -2.1, trend: 'down' },
    avgOrderValue: { value: 541, change: 12.4, trend: 'up' },
    pendingOrders: { value: 7, change: 0, trend: 'neutral' },
    totalCustomers: { value: 1547, change: 5.2, trend: 'up' },
    conversionRate: { value: 3.8, change: 0.5, trend: 'up' }
  };

  // Chart data
  const dailyRevenue = [
    { day: 'Mon', revenue: 8400, orders: 18, customers: 15 },
    { day: 'Tue', revenue: 9200, orders: 21, customers: 18 },
    { day: 'Wed', revenue: 7800, orders: 16, customers: 14 },
    { day: 'Thu', revenue: 11600, orders: 25, customers: 22 },
    { day: 'Fri', revenue: 12450, orders: 23, customers: 20 },
    { day: 'Sat', revenue: 15200, orders: 32, customers: 28 },
    { day: 'Sun', revenue: 13800, orders: 28, customers: 25 }
  ];

  const monthlyTrends = [
    { month: 'Jan', revenue: 125000, orders: 342, growth: 8.5 },
    { month: 'Feb', revenue: 138000, orders: 389, growth: 10.4 },
    { month: 'Mar', revenue: 142000, orders: 401, growth: 2.9 },
    { month: 'Apr', revenue: 156000, orders: 445, growth: 9.9 },
    { month: 'May', revenue: 168000, orders: 478, growth: 7.7 },
    { month: 'Jun', revenue: 184000, orders: 521, growth: 9.5 }
  ];

  const ordersByCategory = [
    { name: 'Electronics', value: 45, color: '#335C67', amount: 89400 },
    { name: 'Fashion', value: 35, color: '#E09F3E', amount: 67300 },
    { name: 'Home & Decor', value: 12, color: '#9E2A2B', amount: 23100 },
    { name: 'Jewelry', value: 8, color: '#540B0E', amount: 18200 }
  ];

  const hourlyOrders = [
    { hour: '9AM', orders: 2, revenue: 1200 },
    { hour: '10AM', orders: 4, revenue: 2400 },
    { hour: '11AM', orders: 3, revenue: 1800 },
    { hour: '12PM', orders: 6, revenue: 3600 },
    { hour: '1PM', orders: 5, revenue: 2700 },
    { hour: '2PM', orders: 3, revenue: 1650 },
    { hour: '3PM', orders: 4, revenue: 2100 },
    { hour: '4PM', orders: 7, revenue: 3850 },
    { hour: '5PM', orders: 5, revenue: 2950 },
    { hour: '6PM', orders: 3, revenue: 1800 }
  ];

  const topProducts = [
    { name: 'Premium Headphones', sales: 156, revenue: 46800, profit: 18720 },
    { name: 'Leather Handbag', sales: 89, revenue: 35600, profit: 14240 },
    { name: 'Smart Watch', sales: 134, revenue: 40200, profit: 16080 },
    { name: 'Wireless Earbuds', sales: 198, revenue: 29700, profit: 11880 },
    { name: 'Designer Sunglasses', sales: 76, revenue: 22800, profit: 9120 }
  ];

  const customerAcquisition = [
    { source: 'Direct', value: 35, color: '#335C67' },
    { source: 'Social Media', value: 28, color: '#E09F3E' },
    { source: 'Google Ads', value: 22, color: '#9E2A2B' },
    { source: 'Email', value: 10, color: '#540B0E' },
    { source: 'Referral', value: 5, color: '#7A1F20' }
  ];

  const paymentMethods = [
    { method: 'Credit Card', percentage: 65, fill: '#335C67' },
    { method: 'PayPal', percentage: 20, fill: '#E09F3E' },
    { method: 'Bank Transfer', percentage: 10, fill: '#9E2A2B' },
    { method: 'Crypto', percentage: 5, fill: '#540B0E' }
  ];


  const recentOrders = [
    { id: '#ORD-2341', customer: 'Sarah Mitchell', amount: 1249, product: 'Premium Leather Handbag', status: 'Processing', time: '2 min ago' },
    { id: '#ORD-2340', customer: 'James Liu', amount: 789, product: 'Wireless Headphones', status: 'Shipped', time: '15 min ago' },
    { id: '#ORD-2339', customer: 'Maria Gonzalez', amount: 2156, product: 'Diamond Bracelet', status: 'Completed', time: '32 min ago' },
    { id: '#ORD-2338', customer: 'David Roberts', amount: 543, product: 'Silk Scarf Set', status: 'Processing', time: '1 hour ago' }
  ];

  const lowStockProducts = [
  { name: 'Wireless Earbuds', currentStock: 5, minStock: 20, sales: 198, status: 'critical' },
  { name: 'Leather Handbag', currentStock: 12, minStock: 25, sales: 89, status: 'warning' },
  { name: 'Smart Watch', currentStock: 8, minStock: 15, sales: 134, status: 'warning' },
  { name: 'Designer Sunglasses', currentStock: 3, minStock: 10, sales: 76, status: 'critical' },
  { name: 'Premium Headphones', currentStock: 18, minStock: 30, sales: 156, status: 'warning' }
];

  const MetricCard = ({ title, value, change, trend, prefix = '', suffix = '', icon: Icon }) => (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300 p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-teal to-secondary-600 rounded-lg">
            <Icon className="w-4 h-4 text-white" />
          </div>
          <h3 className="text-sm font-medium text-gray-700">{title}</h3>
        </div>
        {trend !== 'neutral' && (
          <div className={`flex items-center text-xs px-2 py-1 rounded-full ${
            trend === 'up' 
              ? 'bg-green-50 text-green-700 border border-green-200' 
              : 'bg-red-50 text-red-700 border border-red-200'
          }`}>
            {trend === 'up' ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
            <span className="font-medium">{Math.abs(change)}%</span>
          </div>
        )}
      </div>
      <div className="mt-2">
        <span className="text-2xl font-bold text-gray-900">
          {prefix}{typeof value === 'number' ? value.toLocaleString() : value}{suffix}
        </span>
      </div>
    </div>
  );

  const getStatusColor = (status) => {
    switch (status) {
      case 'Processing': return 'bg-yellow-50 text-yellow-700 border border-yellow-200';
      case 'Shipped': return 'bg-blue-50 text-blue-700 border border-blue-200';
      case 'Completed': return 'bg-green-50 text-green-700 border border-green-200';
      default: return 'bg-gray-50 text-gray-700 border border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header with gradient */}
      {/* <div className="bg-gradient-to-r from-teal via-secondary-600 to-primary-800 text-white px-6 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Analytics Dashboard</h1>
              <p className="text-secondary-100 text-sm">Comprehensive business insights and performance metrics</p>
            </div>
            <select 
              value={selectedPeriod} 
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-sm text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50 backdrop-blur-sm"
            >
              <option value="today" className="text-gray-900">Today</option>
              <option value="yesterday" className="text-gray-900">Yesterday</option>
              <option value="7d" className="text-gray-900">Last 7 days</option>
              <option value="30d" className="text-gray-900">Last 30 days</option>
            </select>
          </div>
        </div>
      </div> */}

      <div className="mx-auto px-6 py-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
          <MetricCard title="Revenue" value={metrics.todayRevenue.value} change={metrics.todayRevenue.change} trend={metrics.todayRevenue.trend} prefix="₹" icon={DollarSign} />
          <MetricCard title="Orders" value={metrics.todayOrders.value} change={metrics.todayOrders.change} trend={metrics.todayOrders.trend} icon={ShoppingCart} />
          <MetricCard title="AOV" value={metrics.avgOrderValue.value} change={metrics.avgOrderValue.change} trend={metrics.avgOrderValue.trend} prefix="₹" icon={TrendingUp} />
          <MetricCard title="Pending" value={metrics.pendingOrders.value} change={metrics.pendingOrders.change} trend={metrics.pendingOrders.trend} icon={Package} />
          <MetricCard title="Customers" value={metrics.totalCustomers.value} change={metrics.totalCustomers.change} trend={metrics.totalCustomers.trend} icon={Users} />
          <MetricCard title="Conv. Rate" value={metrics.conversionRate.value} change={metrics.conversionRate.change} trend={metrics.conversionRate.trend} suffix="%" icon={Eye} />
        </div>

        {/* Main Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Revenue & Orders Trend */}
          <div className="lg:col-span-2 bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Revenue & Orders Trend</h2>
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-teal rounded-full"></div>
                  <span className="text-gray-600">Revenue</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-gold rounded-full"></div>
                  <span className="text-gray-600">Orders</span>
                </div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={dailyRevenue}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis yAxisId="left" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Area yAxisId="left" type="monotone" dataKey="revenue" fill="#335C67" fillOpacity={0.1} stroke="#335C67" strokeWidth={3} />
                <Bar yAxisId="right" dataKey="orders" fill="#E09F3E" radius={[3, 3, 0, 0]} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Category Distribution */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-6">Category Performance</h2>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={ordersByCategory}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {ordersByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-3">
              {ordersByCategory.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color }}></div>
                    <span className="text-sm font-medium text-gray-700">{item.name}</span>
                  </div>
                  <span className="text-sm font-semibold text-gray-900">₹{item.amount.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Second Row Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Monthly Growth */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Monthly Growth Trends</h2>
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-teal rounded-full"></div>
                  <span className="text-gray-600">Revenue</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-gold rounded-full"></div>
                  <span className="text-gray-600">Orders</span>
                </div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={monthlyTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Line type="monotone" dataKey="revenue" stroke="#335C67" strokeWidth={3} dot={{ fill: '#335C67', strokeWidth: 2, r: 5 }} />
                <Line type="monotone" dataKey="orders" stroke="#E09F3E" strokeWidth={3} dot={{ fill: '#E09F3E', strokeWidth: 2, r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Hourly Performance */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-6">Hourly Performance</h2>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={hourlyOrders}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Bar dataKey="orders" fill="#E09F3E" radius={[4, 4, 0, 0]} />
                <Bar dataKey="revenue" fill="#335C67" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Third Row Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          {/* Customer Acquisition */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Traffic Sources</h2>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={customerAcquisition}
                  cx="50%"
                  cy="50%"
                  outerRadius={70}
                  dataKey="value"
                >
                  {customerAcquisition.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              {customerAcquisition.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                    <span className="text-xs text-gray-700">{item.source}</span>
                  </div>
                  <span className="text-xs font-medium text-gray-900">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Methods */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment Methods</h2>
            <ResponsiveContainer width="100%" height={200}>
              <RadialBarChart cx="50%" cy="50%" innerRadius="30%" outerRadius="80%" data={paymentMethods}>
                <RadialBar dataKey="percentage" cornerRadius={10} fill="#335C67" />
              </RadialBarChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              {paymentMethods.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.fill }}></div>
                    <span className="text-xs text-gray-700">{item.method}</span>
                  </div>
                  <span className="text-xs font-medium text-gray-900">{item.percentage}%</span>
                </div>
              ))}
            </div>
          </div>

 

           <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Low Stock Alerts</h2>
            <div className="space-y-4">
              {lowStockProducts.map((product, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <div className={`w-2 h-2 rounded-full ${
                        product.status === 'critical' ? 'bg-red-500' : 'bg-yellow-500'
                      }`}></div>
                      <p className="text-sm font-medium text-gray-900 truncate">{product.name}</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      {product.currentStock} left • {product.sales} sold
                    </p>
                  </div>
                  <div className="text-right">
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                      product.status === 'critical' 
                        ? 'bg-red-50 text-red-700 border border-red-200' 
                        : 'bg-yellow-50 text-yellow-700 border border-yellow-200'
                    }`}>
                      {product.status === 'critical' ? 'Critical' : 'Low'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top Products */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Top Products</h2>
            <div className="space-y-4">
              {topProducts.slice(0, 5).map((product, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 truncate">{product.name}</p>
                    <p className="text-xs text-gray-500">{product.sales} sales</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-gray-900">${product.revenue.toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Recent Orders</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left py-3 px-6 font-medium text-gray-600 text-sm">Order ID</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-600 text-sm">Customer</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-600 text-sm">Product</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-600 text-sm">Amount</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-600 text-sm">Status</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-600 text-sm">Time</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                    <td className="py-4 px-6 text-sm font-medium text-gray-900">{order.id}</td>
                    <td className="py-4 px-6 text-sm text-gray-700">{order.customer}</td>
                    <td className="py-4 px-6 text-sm text-gray-700">{order.product}</td>
                    <td className="py-4 px-6 text-sm font-semibold text-gray-900">${order.amount.toLocaleString()}</td>
                    <td className="py-4 px-6">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-sm text-gray-500">{order.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;