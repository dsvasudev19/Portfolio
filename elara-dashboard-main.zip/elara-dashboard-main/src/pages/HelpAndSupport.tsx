import React, { useState } from 'react';
import { Tag, HelpCircle } from 'lucide-react';
import ComplaintModal from './../modals/Complaint';

const HelpSupport = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentComplaint, setCurrentComplaint] = useState({
    subject: '',
    description: '',
    priority: 'Medium'
  });

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentComplaint({
      subject: '',
      description: '',
      priority: 'Medium'
    });
  };

  const handleSave = () => {
    // In a real application, this would send the complaint to the Admin dashboard
    console.log('Complaint submitted:', currentComplaint);
    closeModal();
  };

  const helpResources = [
    {
      title: 'Vendor Dashboard Guide',
      description: 'Comprehensive guide on using the vendor dashboard effectively.',
      link: '#'
    },
    {
      title: 'FAQ',
      description: 'Frequently asked questions about managing categories, coupons, and deals.',
      link: '#'
    },
    {
      title: 'Contact Support',
      description: 'Reach out to our support team for personalized assistance.',
      link: '#'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
              Help & Support
            </h1>
            <p className="text-sm text-gray-600">
              Vendor Assistance • Support Resources & Complaint Submission
            </p>
          </div>
          <button
            onClick={openModal}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
            style={{ color: '#335C67', borderColor: '#335C67' }}
          >
            <Tag className="h-4 w-4 mr-2" style={{ color: '#335C67' }} />
            Raise Complaint
          </button>
        </div>

        {/* Help Resources */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">Support Resources</h2>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {helpResources.map((resource, index) => (
                <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                        {resource.title}
                      </p>
                      <p className="text-sm text-gray-600 mt-1" style={{ color: '#9E2A2B' }}>
                        {resource.description}
                      </p>
                      <a
                        href={resource.link}
                        className="text-sm mt-2 inline-block"
                        style={{ color: '#335C67' }}
                      >
                        Learn More
                      </a>
                    </div>
                    <div className="p-2 rounded-lg" style={{ backgroundColor: '#335C6715' }}>
                      <HelpCircle className="h-5 w-5" style={{ color: '#335C67' }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Complaint Modal */}
        <ComplaintModal
          isOpen={isModalOpen}
          onClose={closeModal}
          complaint={currentComplaint}
          setComplaint={setCurrentComplaint}
          onSave={handleSave}
        />
      </div>
    </div>
  );
};

export default HelpSupport;