
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Package, Tag, Image as ImageIcon, ArrowLeft, Star, Edit, Trash2 } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { axiosInstance } from '../../axiosInstance';
import ConfirmationModal from './../modals/ConfirmationDialog';

interface Attribute {
  Type: string;
  Model: string;
}

interface Variant {
  id: number;
  stock: number;
  price: number;
  sku: string | null;
  productId: number;
  attributes: Attribute;
}

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  stock: number;
  sku: string;
  isFeatured: boolean;
  brand: string;
  status: string;
  category: string;
  tags: string[];
  mediaUrls: string[];
  variants: Variant[];
}

const ProductViewDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);

  const fetchProduct = async () => {
    try {
      const res = await axiosInstance.get(`/products/${id}`);
      if (res.status === 200) {
        setProduct(res.data);
      }
    } catch (error) {
      console.error('Error fetching product:', error);
      toast.error('Failed to fetch product details');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    navigate(`/dashboard/products/update-details/${id}`);
  };

  const handleDelete = async () => {
    setShowDeleteModal(true);
    setSelectedProductId(id);
  };

  const deleteProductById = async () => {
    try {
      const res = await axiosInstance.delete(`/products/${selectedProductId}`);
      if (res.status === 204) {
        toast.success('Product deleted successfully!');
        navigate('/dashboard/products');
      }
    } catch (error: any) {
      console.error('Error deleting product:', error);
      toast.error(error.response?.data?.message || 'Failed to delete product');
    }
    setShowDeleteModal(false);
  };

  useEffect(() => {
    fetchProduct();
  }, [id]);

  const getStockStatus = (stock: number) => {
    if (stock === 0) return { label: 'Out of Stock', color: 'bg-red-50 text-red-700 border-red-200' };
    if (stock < 10) return { label: 'Low Stock', color: 'bg-orange-50 text-orange-700 border-orange-200' };
    if (stock < 20) return { label: 'Medium Stock', color: 'bg-amber-50 text-amber-700 border-amber-200' };
    return { label: 'In Stock', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'active': 'bg-emerald-50 text-emerald-700 border-emerald-200',
      'inactive': 'bg-slate-50 text-slate-700 border-slate-200',
      'draft': 'bg-amber-50 text-amber-700 border-amber-200',
      'archived': 'bg-rose-50 text-rose-700 border-rose-200'
    };
    return statusMap[status.toLowerCase()] || 'bg-slate-50 text-slate-700 border-slate-200';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 mx-auto mb-4" style={{ borderColor: '#335C67' }}></div>
          <p className="text-slate-600 font-medium">Loading product details...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4 mx-auto">
            <Package className="h-8 w-8 text-gray-400" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Product Not Found</h2>
          <p className="text-gray-600 mb-4">The product you're looking for doesn't exist or has been removed.</p>
          <button
            onClick={() => navigate('/dashboard/products')}
            className="px-4 py-2 text-white rounded-lg hover:opacity-90 transition-colors"
            style={{ backgroundColor: '#335C67' }}
          >
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  const stockStatus = getStockStatus(product.stock);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard/products')}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 hover:border-gray-400 transition-all duration-200"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Products
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <h1 className="text-xl font-bold text-gray-900">{product.name}</h1>
              {product.isFeatured && (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium text-white border"
                      style={{ backgroundColor: '#E09F3E' }}>
                  <Star className="h-3 w-3 mr-1 fill-current" />
                  Featured
                </span>
              )}
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={handleEdit}
                className="inline-flex items-center px-4 py-2 border rounded-lg text-sm font-medium text-white hover:opacity-90 transition-all duration-200"
                style={{ backgroundColor: '#335C67', borderColor: '#335C67' }}
              >
                <Edit className="h-4 w-4 mr-2" />
                Edit Product
              </button>
              <button
                onClick={handleDelete}
                className="inline-flex items-center px-4 py-2 border rounded-lg text-sm font-medium text-white hover:opacity-90 transition-all duration-200"
                style={{ backgroundColor: '#9E2A2B', borderColor: '#9E2A2B' }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Media */}
          <div className="space-y-4">
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <div className="aspect-square bg-gradient-to-br from-gray-50 to-slate-100 rounded-xl overflow-hidden mb-4 border border-gray-100">
                {product.mediaUrls && product.mediaUrls.length > 0 ? (
                  <img
                    src={product.mediaUrls[selectedImage]}
                    alt={product.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <div className="text-center">
                      <ImageIcon className="h-16 w-16 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-500">No image available</p>
                    </div>
                  </div>
                )}
              </div>
              {product.mediaUrls && product.mediaUrls.length > 1 && (
                <div className="grid grid-cols-5 gap-3">
                  {product.mediaUrls.map((media, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(index)}
                      className={`aspect-square rounded-lg overflow-hidden border-2 transition-all duration-200 ${
                        selectedImage === index 
                          ? 'border-opacity-100 ring-2 ring-opacity-30 shadow-md' 
                          : 'border-gray-200 hover:border-gray-300 hover:shadow-sm'
                      }`}
                      style={selectedImage === index ? { 
                        borderColor: '#335C67', 
                        '--tw-ring-color': '#335C67' 
                      } : {}}
                    >
                      <img
                        src={media}
                        alt={`${product.name} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Product Information */}
          <div className="space-y-6">
            {/* Basic Info */}
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <p className="text-sm text-slate-500 mb-1">Product ID: {product.id}</p>
                  <h2 className="text-2xl font-bold text-gray-900">{product.name}</h2>
                </div>
                <span className={`px-4 py-2 rounded-full text-sm font-medium border ${getStatusBadge(product.status)}`}>
                  {product.status}
                </span>
              </div>
              
              <div className="space-y-6">
                <div className="rounded-lg p-4 border-2"
                     style={{ backgroundColor: '#335C67', borderColor: '#335C67' }}>
                  <p className="text-3xl font-bold text-white">₹{product.price.toFixed(2)}</p>
                  <p className="text-sm text-gray-200 mt-1">Current price</p>
                </div>
                
                <div className="flex items-center space-x-4">
                  <span className={`px-4 py-2 rounded-full text-sm font-medium border ${stockStatus.color}`}>
                    {stockStatus.label} ({product.stock})
                  </span>
                </div>

                {product.description && (
                  <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                    <h3 className="text-sm font-semibold text-gray-900 mb-2">Description</h3>
                    <p className="text-slate-700 leading-relaxed">{product.description}</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm font-semibold text-gray-900 mb-1">SKU</p>
                    <p className="text-sm text-gray-600">{product.sku || 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm font-semibold text-gray-900 mb-1">Brand</p>
                    <p className="text-sm text-gray-600">{product.brand || 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm font-semibold text-gray-900 mb-1">Category</p>
                    <p className="text-sm text-gray-600">{product.category || 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm font-semibold text-gray-900 mb-1">Stock</p>
                    <p className="text-sm text-gray-600">{product.stock} units</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Tags */}
            {product.tags && product.tags.length > 0 && (
              <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-4">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center"
                         style={{ backgroundColor: '#E09F3E' }}>
                      <Tag className="h-5 w-5 text-white" />
                    </div>
                  </div>
                  <div className="flex-grow">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">
                      Tags
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {product.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 rounded-full text-sm font-medium text-white hover:opacity-90 transition-all duration-200"
                          style={{ backgroundColor: '#335C67' }}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Variants */}
        {product.variants && product.variants.length > 0 && (
          <div className="mt-8">
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200"
                   style={{ backgroundColor: 'rgba(51, 92, 103, 0.05)' }}>
                <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center mr-3"
                       style={{ backgroundColor: '#335C67' }}>
                    <Package className="h-5 w-5 text-white" />
                  </div>
                  Product Variants ({product.variants.length})
                </h3>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {product.variants.map((variant) => {
                    const variantStock = getStockStatus(variant.stock);
                    return (
                      <div key={variant.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow duration-200 bg-gradient-to-br from-white to-gray-50">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <p className="text-sm font-semibold text-gray-900">Variant #{variant.id}</p>
                            {variant.sku && (
                              <p className="text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded mt-1">SKU: {variant.sku}</p>
                            )}
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium border ${variantStock.color}`}>
                            {variant.stock}
                          </span>
                        </div>
                        
                        <div className="space-y-2 mb-3">
                          {variant.attributes && Object.entries(variant.attributes).map(([key, value]) => (
                            <div key={key} className="flex justify-between text-sm bg-gray-50 px-3 py-2 rounded">
                              <span className="text-gray-600 font-medium">{key}:</span>
                              <span className="font-semibold text-gray-900">{value || 'N/A'}</span>
                            </div>
                          ))}
                        </div>
                        
                        <div className="pt-3 border-t border-gray-200">
                          <p className="text-xl font-bold" style={{ color: '#335C67' }}>${variant.price.toFixed(2)}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Confirmation Modal */}
        {showDeleteModal && (
          <ConfirmationModal
            isOpen={showDeleteModal}
            onClose={() => setShowDeleteModal(false)}
            confirmationText="Are you sure you want to delete this product? This action cannot be undone."
            actionText="Delete"
            action={deleteProductById}
            title="Confirm Delete"
          />
        )}
      </div>
    
    </div>
  );
};

export default ProductViewDetails;