import React, { useState } from 'react';
import { Tag, User } from 'lucide-react';

const Settings = () => {
  const [shopDetails, setShopDetails] = useState({
    name: 'Main Boutique',
    address: '123 Luxury Lane, Cityville',
    contact: '+1-234-567-8900',
    email: 'contact@mainboutique.com'
  });

  const [userProfile, setUserProfile] = useState({
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1-987-654-3210',
    role: 'Vendor Admin'
  });

  const handleShopChange = (field: string, value: string) => {
    setShopDetails(prev => ({ ...prev, [field]: value }));
  };

  const handleUserChange = (field: string, value: string) => {
    setUserProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleShopSubmit = () => {
    // In a real application, this would send the updated shop details to the backend
    console.log('Updated Shop Details:', shopDetails);
  };

  const handleUserSubmit = () => {
    // In a real application, this would send the updated user profile to the backend
    console.log('Updated User Profile:', userProfile);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
            Settings
          </h1>
          <p className="text-sm text-gray-600">
            Manage Shop & User Profile Details
          </p>
        </div>

        {/* Shop Details Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="px-4 py-3 border-b border-gray-200 flex items-center space-x-2" style={{ backgroundColor: '#335C67' }}>
            <Tag className="h-4 w-4 text-white" />
            <h2 className="text-sm font-semibold text-white">Shop Details</h2>
          </div>
          <div className="p-4 space-y-4">
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Shop Name
              </label>
              <input
                type="text"
                value={shopDetails.name}
                onChange={(e) => handleShopChange('name', e.target.value)}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Address
              </label>
              <textarea
                value={shopDetails.address}
                onChange={(e) => handleShopChange('address', e.target.value)}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
                rows={3}
              />
            </div>
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Contact Number
              </label>
              <input
                type="tel"
                value={shopDetails.contact}
                onChange={(e) => handleShopChange('contact', e.target.value)}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Email
              </label>
              <input
                type="email"
                value={shopDetails.email}
                onChange={(e) => handleShopChange('email', e.target.value)}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <div className="flex justify-end">
              <button
                onClick={handleShopSubmit}
                className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
                style={{ color: '#335C67', borderColor: '#335C67' }}
              >
                Save Shop Details
              </button>
            </div>
          </div>
        </div>

        {/* User Profile Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-4 py-3 border-b border-gray-200 flex items-center space-x-2" style={{ backgroundColor: '#335C67' }}>
            <User className="h-4 w-4 text-white" />
            <h2 className="text-sm font-semibold text-white">User Profile</h2>
          </div>
          <div className="p-4 space-y-4">
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Full Name
              </label>
              <input
                type="text"
                value={userProfile.name}
                onChange={(e) => handleUserChange('name', e.target.value)}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Email
              </label>
              <input
                type="email"
                value={userProfile.email}
                onChange={(e) => handleUserChange('email', e.target.value)}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Phone Number
              </label>
              <input
                type="tel"
                value={userProfile.phone}
                onChange={(e) => handleUserChange('phone', e.target.value)}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Role
              </label>
              <input
                type="text"
                value={userProfile.role}
                onChange={(e) => handleUserChange('role', e.target.value)}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
            </div>
            <div className="flex justify-end">
              <button
                onClick={handleUserSubmit}
                className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
                style={{ color: '#335C67', borderColor: '#335C67' }}
              >
                Save User Profile
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;