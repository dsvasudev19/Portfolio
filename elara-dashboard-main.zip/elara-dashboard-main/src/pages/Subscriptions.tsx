import { useEffect, useState } from "react";
import { axiosInstance } from "../../axiosInstance";
import ClockLoader from "react-spinners/ClockLoader";
import { Unlink } from "lucide-react";
import toast from "react-hot-toast";

const Subscriptions = () => {
  const [subscriptions, setSubscriptions] = useState<any[]>([]);
  const [loading, setLoading] = useState<any>(false);

  const getAllSubscriptions = async () => {
    try {
      setLoading(true);
      const res = await axiosInstance.get("/news-letter");
      if (res.status === 200) {
        setSubscriptions(res.data.data);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getAllSubscriptions();
  }, []);

  const unSubscribe=async(email:any)=>{
    try {
      const res=await axiosInstance.post("/news-letter/unsubscribe",{email})
      if(res.status===200){
        toast.success("User Un-Subscribed Successfully")
        getAllSubscriptions()
      }
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div className="w-full h-full">
      <div className="relative overflow-x-auto w-full h-full">
        <div className="mb-4">
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-rose-800 to-amber-700 hover:from-amber-700 hover:to-rose-800 transition-all duration-300 drop-shadow-lg">
            Subscription Management
          </h1>
        </div>
        {loading ? (
          <div className="flex justify-center text-center items-center w-full !h-[90%]">
            <ClockLoader color="#085387" size={200} />
          </div>
        ) : (
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="overflow-x-auto custom-scrollbar max-h-[85vh]">
              <table className="w-full text-sm">
                <thead className="bg-gray-100 sticky top-0 z-10">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider text-right">Actions</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {Array.from({ length: Math.ceil(subscriptions.length / 2) }).map((_, rowIndex) => (
                    <tr key={rowIndex} className="bg-white border-b ">
                      
                      <td scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap text-left">
                        {subscriptions[rowIndex * 2]?.email}
                      </td>
                      <td className="px-6 py-4">
                        {subscriptions[rowIndex * 2]?.deletedAt === null ? (
                          <span className="bg-green-100 rounded p-1 text-green-800">
                            Subscribed
                          </span>
                        ) : (
                          <span className="bg-red-100 rounded p-1 text-red-800">
                            Un-Subscribed
                          </span>
                        )}
                      </td>
                      <td scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap flex justify-end">
                      
                        <a
                            onClick={() => {
                              unSubscribe(subscriptions[rowIndex*2]?.email);
                            }}
                            className="cursor-pointer text-red-600 hover:text-red-800 transition-colors"
                          >
                            <Unlink className="w-5 h-5" />
                          </a>
                      </td>
                      <td scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap text-left">
                        {subscriptions[rowIndex * 2 + 1]?.email}
                      </td>
                      <td className="px-6 py-4">
                        {subscriptions[rowIndex * 2 + 1]?.deletedAt === null ? (
                          <span className="bg-green-100 rounded p-1 text-green-800">
                            Subscribed
                          </span>
                        ) : (
                          <span className="bg-red-100 rounded p-1 text-red-800">
                            Un-Subscribed
                          </span>
                        )}
                      </td>
                      <td scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap flex justify-end">
                      
                        <a
                            onClick={() => {
                              unSubscribe(subscriptions[rowIndex*2]?.email);
                            }}
                            className="cursor-pointer text-red-600 hover:text-red-800 transition-colors"
                          >
                            <Unlink className="w-5 h-5" />
                          </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Subscriptions;