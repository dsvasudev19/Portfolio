
import React, { useState } from 'react';
import { Tag, DollarSign, Clock, ChevronDown, ChevronUp, Edit,Trash2,Package } from 'lucide-react';
import DealModal from '../modals/Deal';

const DealManagement = () => {
  const [expandedRows, setExpandedRows] = useState<any>({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' or 'edit'
  const [currentDeal, setCurrentDeal] = useState({
    id: '',
    name: '',
    dealType: 'DISCOUNT',
    discountValue: 0,
    startDate: '',
    endDate: '',
    maxRedemptions: 0,
    status: 'Active',
    applicableProducts: [],
    applicableCategories: [],
    applicableShops: []
  });

  const toggleRow = (dealId:any) => {
    setExpandedRows((prev:any) => ({
      ...prev,
      [dealId]: !prev[dealId]
    }));
  };

  const openModal = (mode:any, deal = {
    id: '',
    name: '',
    dealType: 'DISCOUNT',
    discountValue: 0,
    startDate: '',
    endDate: '',
    maxRedemptions: 0,
    status: 'Active',
    applicableProducts: [],
    applicableCategories: [],
    applicableShops: []
  }) => {
    setModalMode(mode);
    setCurrentDeal(deal);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentDeal({
      id: '',
      name: '',
      dealType: 'DISCOUNT',
      discountValue: 0,
      startDate: '',
      endDate: '',
      maxRedemptions: 0,
      status: 'Active',
      applicableProducts: [],
      applicableCategories: [],
      applicableShops: []
    });
  };

  const handleSave = () => {
    if (modalMode === 'add') {
      const newDeal = {
        ...currentDeal,
        id: `DEAL-${(deals.length + 1).toString().padStart(3, '0')}`
      };
      setDeals([...deals, newDeal]);
    } else {
      setDeals(deals.map(d => (d.id === currentDeal.id ? currentDeal : d)));
    }
    closeModal();
  };

  const handleDelete = (id) => {
    setDeals(deals.filter(d => d.id !== id));
  };

  const [deals, setDeals] = useState([
    {
      id: 'DEAL-001',
      name: 'Summer Luxury Sale',
      dealType: 'DISCOUNT',
      discountValue: 20.00,
      startDate: '2025-06-01 00:00:00',
      endDate: '2025-08-31 23:59:59',
      maxRedemptions: 100,
      status: 'Active',
      applicableProducts: [
        { id: 'PRD-001', name: 'Rosewood Handcrafted Idol' },
        { id: 'PRD-002', name: 'Sapphire Pendant Necklace' }
      ],
      applicableCategories: [
        { id: 'CAT-001', name: 'Luxury Jewelry' },
        { id: 'CAT-002', name: 'Handcrafts' }
      ],
      applicableShops: [
        { id: 'SHP-001', name: 'Main Boutique' }
      ]
    },
    {
      id: 'DEAL-002',
      name: 'Buy One Get One Free',
      dealType: 'BOGO',
      discountValue: 0,
      startDate: '2025-07-01 00:00:00',
      endDate: '2025-07-31 23:59:59',
      maxRedemptions: 50,
      status: 'Expired',
      applicableProducts: [
        { id: 'PRD-003', name: 'Handbound Leather Journal' }
      ],
      applicableCategories: [
        { id: 'CAT-003', name: 'Stationery' }
      ],
      applicableShops: [
        { id: 'SHP-002', name: 'Online Store' }
      ]
    },
    {
      id: 'DEAL-003',
      name: 'Gift Season Promo',
      dealType: 'DISCOUNT',
      discountValue: 15.00,
      startDate: '2025-07-10 00:00:00',
      endDate: '2025-12-31 23:59:59',
      maxRedemptions: 200,
      status: 'Active',
      applicableProducts: [],
      applicableCategories: [
        { id: 'CAT-002', name: 'Handcrafts' },
        { id: 'CAT-003', name: 'Stationery' }
      ],
      applicableShops: [
        { id: 'SHP-001', name: 'Main Boutique' },
        { id: 'SHP-002', name: 'Online Store' }
      ]
    }
  ]);

  const metrics = [
    {
      title: 'Total Deals',
      value: deals.length,
      icon: Tag,
      color: '#335C67'
    },
    {
      title: 'Active Deals',
      value: deals.filter(d => d.status === 'Active').length,
      icon: DollarSign,
      color: '#E09F3E'
    },
    {
      title: 'Expired Deals',
      value: deals.filter(d => d.status === 'Expired').length,
      icon: Clock,
      color: '#9E2A2B'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800 border-green-200';
      case 'Expired': return 'bg-red-100 text-red-800 border-red-200';
      case 'Inactive': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: '#540B0E' }}>
              Deal Management Dashboard
            </h1>
            <p className="text-sm text-gray-600">
              Promotions Overview • Real-time Deal Tracking
            </p>
          </div>
          <button
            onClick={() => openModal('add')}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors flex items-center"
            style={{ color: '#335C67', borderColor: '#335C67' }}
          >
            <Tag className="h-4 w-4 mr-2" style={{ color: '#335C67' }} />
            Add Deal
          </button>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                    {metric.title}
                  </p>
                  <p className="text-xl font-bold mt-1" style={{ color: metric.color }}>
                    {metric.value}
                  </p>
                </div>
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${metric.color}15` }}>
                  <metric.icon className="h-5 w-5" style={{ color: metric.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Deals Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200" style={{ backgroundColor: '#335C67' }}>
            <h2 className="text-sm font-semibold text-white">Deal List</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Deal Name
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Discount
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Validity
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Max Redemptions
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {deals.map((deal) => (
                  <React.Fragment key={deal.id}>
                    <tr className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <Tag className="h-4 w-4" style={{ color: '#540B0E' }} />
                          <div>
                            <p className="text-sm font-medium" style={{ color: '#540B0E' }}>
                              {deal.name}
                            </p>
                            <p className="text-xs text-gray-500">
                              ID: {deal.id}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-sm" style={{ color: '#9E2A2B' }}>
                          {deal.dealType}
                        </p>
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-sm font-bold" style={{ color: '#540B0E' }}>
                          {deal.dealType === 'DISCOUNT' ? `${deal.discountValue}%` : 'BOGO'}
                        </p>
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-sm" style={{ color: '#335C67' }}>
                          {deal.startDate} - {deal.endDate}
                        </p>
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-sm" style={{ color: '#9E2A2B' }}>
                          {deal.maxRedemptions}
                        </p>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(deal.status)}`}>
                          {deal.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => openModal('edit', deal)}
                            className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                            style={{ color: '#335C67', borderColor: '#335C67' }}
                          >
                            <Edit className="h-3 w-3 mr-1" />
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(deal.id)}
                            className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                            style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
                          >
                            <Trash2 className="h-3 w-3 mr-1" />
                            Delete
                          </button>
                          <button
                            onClick={() => toggleRow(deal.id)}
                            className="text-sm px-3 py-1 rounded hover:bg-gray-100 border transition-colors flex items-center"
                            style={{ color: '#335C67', borderColor: '#335C67' }}
                          >
                            {expandedRows[deal.id] ? (
                              <>
                                <ChevronUp className="h-3 w-3 mr-1" />
                                Hide
                              </>
                            ) : (
                              <>
                                <ChevronDown className="h-3 w-3 mr-1" />
                                View
                              </>
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                    {/* Expanded Row Content */}
                    {expandedRows[deal.id] && (
                      <tr>
                        <td colSpan={7} className="px-4 py-4 bg-gray-50">
                          <div className="space-y-4">
                            {/* Applicable Products */}
                            <div className="border rounded-lg overflow-hidden">
                              <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
                                <Package className="h-4 w-4" style={{ color: '#540B0E' }} />
                                <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
                                  Applicable Products ({deal.applicableProducts.length})
                                </span>
                              </div>
                              <div className="bg-white">
                                {deal.applicableProducts.length > 0 ? (
                                  deal.applicableProducts.map((product, index) => (
                                    <div key={product.id} className={`px-4 py-3 ${index !== deal.applicableProducts.length - 1 ? 'border-b' : ''}`}>
                                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                                        {product.name} (ID: {product.id})
                                      </p>
                                    </div>
                                  ))
                                ) : (
                                  <div className="px-4 py-3">
                                    <p className="text-sm text-gray-500">No products assigned</p>
                                  </div>
                                )}
                              </div>
                            </div>
                            {/* Applicable Categories */}
                            <div className="border rounded-lg overflow-hidden">
                              <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
                                <Tag className="h-4 w-4" style={{ color: '#540B0E' }} />
                                <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
                                  Applicable Categories ({deal.applicableCategories.length})
                                </span>
                              </div>
                              <div className="bg-white">
                                {deal.applicableCategories.length > 0 ? (
                                  deal.applicableCategories.map((category, index) => (
                                    <div key={category.id} className={`px-4 py-3 ${index !== deal.applicableCategories.length - 1 ? 'border-b' : ''}`}>
                                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                                        {category.name} (ID: {category.id})
                                      </p>
                                    </div>
                                  ))
                                ) : (
                                  <div className="px-4 py-3">
                                    <p className="text-sm text-gray-500">No categories assigned</p>
                                  </div>
                                )}
                              </div>
                            </div>
                            {/* Applicable Shops */}
                            <div className="border rounded-lg overflow-hidden">
                              <div className="px-4 py-3 bg-white border-b flex items-center space-x-2">
                                <Tag className="h-4 w-4" style={{ color: '#540B0E' }} />
                                <span className="text-sm font-medium" style={{ color: '#540B0E' }}>
                                  Applicable Shops ({deal.applicableShops.length})
                                </span>
                              </div>
                              <div className="bg-white">
                                {deal.applicableShops.length > 0 ? (
                                  deal.applicableShops.map((shop, index) => (
                                    <div key={shop.id} className={`px-4 py-3 ${index !== deal.applicableShops.length - 1 ? 'border-b' : ''}`}>
                                      <p className="text-sm" style={{ color: '#9E2A2B' }}>
                                        {shop.name} (ID: {shop.id})
                                      </p>
                                    </div>
                                  ))
                                ) : (
                                  <div className="px-4 py-3">
                                    <p className="text-sm text-gray-500">No shops assigned</p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        <DealModal
          isOpen={isModalOpen}
          onClose={closeModal}
          mode={modalMode}
          deal={currentDeal}
          setDeal={setCurrentDeal}
          onSave={handleSave}
        />
      </div>
    </div>
  );
};

export default DealManagement;