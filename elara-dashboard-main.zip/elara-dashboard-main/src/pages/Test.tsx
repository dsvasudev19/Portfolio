import React from 'react';

const LuxeLoader = ({ 
  type = 'spinner', 
  size = 'medium', 
  color = 'teal', 
  text = '', 
  overlay = false,
  className = '',
  speed = 'normal'
}) => {
  
  // Theme colors
  const colors = {
    teal: '#335C67',
    butter: '#FFF3B0',
    gold: '#E09F3E',
    crimson: '#9E2A2B',
    burgundy: '#540B0E',
  };

  // Size configurations
  const sizes = {
    small: { width: '20px', height: '20px', text: 'text-sm' },
    medium: { width: '40px', height: '40px', text: 'text-base' },
    large: { width: '60px', height: '60px', text: 'text-lg' },
    xlarge: { width: '80px', height: '80px', text: 'text-xl' },
  };

  // Speed configurations
  const speeds = {
    slow: '2s',
    normal: '1s',
    fast: '0.5s',
  };

  const currentColor = colors[color];
  const currentSize = sizes[size];
  const currentSpeed = speeds[speed];

  // Spinner Component
  const Spinner = () => (
    <div className="flex flex-col items-center justify-center">
      <div
        className="animate-spin rounded-full border-4 border-gray-200"
        style={{
          width: currentSize.width,
          height: currentSize.height,
          borderTopColor: currentColor,
          animationDuration: currentSpeed,
        }}
      />
      {text && (
        <p className={`mt-3 text-gray-600 ${currentSize.text}`}>
          {text}
        </p>
      )}
    </div>
  );

  // Dots Component
  const Dots = () => (
    <div className="flex flex-col items-center justify-center">
      <div className="flex space-x-1">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="rounded-full animate-bounce"
            style={{
              width: size === 'small' ? '8px' : size === 'medium' ? '12px' : size === 'large' ? '16px' : '20px',
              height: size === 'small' ? '8px' : size === 'medium' ? '12px' : size === 'large' ? '16px' : '20px',
              backgroundColor: currentColor,
              animationDelay: `${i * 0.1}s`,
              animationDuration: currentSpeed,
            }}
          />
        ))}
      </div>
      {text && (
        <p className={`mt-3 text-gray-600 ${currentSize.text}`}>
          {text}
        </p>
      )}
    </div>
  );

  // Pulse Component
  const Pulse = () => (
    <div className="flex flex-col items-center justify-center">
      <div
        className="rounded-full animate-pulse"
        style={{
          width: currentSize.width,
          height: currentSize.height,
          backgroundColor: currentColor,
          animationDuration: currentSpeed,
        }}
      />
      {text && (
        <p className={`mt-3 text-gray-600 ${currentSize.text}`}>
          {text}
        </p>
      )}
    </div>
  );

  // Bars Component
  const Bars = () => (
    <div className="flex flex-col items-center justify-center">
      <div className="flex items-end space-x-1">
        {[0, 1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="animate-pulse"
            style={{
              width: size === 'small' ? '3px' : size === 'medium' ? '4px' : size === 'large' ? '6px' : '8px',
              height: size === 'small' ? '16px' : size === 'medium' ? '24px' : size === 'large' ? '32px' : '40px',
              backgroundColor: currentColor,
              animationDelay: `${i * 0.1}s`,
              animationDuration: currentSpeed,
            }}
          />
        ))}
      </div>
      {text && (
        <p className={`mt-3 text-gray-600 ${currentSize.text}`}>
          {text}
        </p>
      )}
    </div>
  );

  // Ring Component
  const Ring = () => (
    <div className="flex flex-col items-center justify-center">
      <div
        className="animate-spin rounded-full border-4 border-transparent"
        style={{
          width: currentSize.width,
          height: currentSize.height,
          borderTopColor: currentColor,
          borderRightColor: currentColor,
          animationDuration: currentSpeed,
        }}
      />
      {text && (
        <p className={`mt-3 text-gray-600 ${currentSize.text}`}>
          {text}
        </p>
      )}
    </div>
  );

  // Ripple Component
  const Ripple = () => (
    <div className="flex flex-col items-center justify-center">
      <div className="relative" style={{ width: currentSize.width, height: currentSize.height }}>
        {[0, 1].map((i) => (
          <div
            key={i}
            className="absolute inset-0 rounded-full border-2 animate-ping"
            style={{
              borderColor: currentColor,
              animationDelay: `${i * 0.5}s`,
              animationDuration: currentSpeed,
            }}
          />
        ))}
      </div>
      {text && (
        <p className={`mt-3 text-gray-600 ${currentSize.text}`}>
          {text}
        </p>
      )}
    </div>
  );

  // Square Component
  const Square = () => (
    <div className="flex flex-col items-center justify-center">
      <div
        className="animate-spin"
        style={{
          width: currentSize.width,
          height: currentSize.height,
          backgroundColor: currentColor,
          animationDuration: currentSpeed,
        }}
      />
      {text && (
        <p className={`mt-3 text-gray-600 ${currentSize.text}`}>
          {text}
        </p>
      )}
    </div>
  );

  // Heart Component (for luxury feel)
  const Heart = () => (
    <div className="flex flex-col items-center justify-center">
      <div
        className="animate-pulse"
        style={{
          width: currentSize.width,
          height: currentSize.height,
          animationDuration: currentSpeed,
        }}
      >
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
            fill={currentColor}
          />
        </svg>
      </div>
      {text && (
        <p className={`mt-3 text-gray-600 ${currentSize.text}`}>
          {text}
        </p>
      )}
    </div>
  );

  // Render appropriate loader type
  const renderLoader = () => {
    switch (type) {
      case 'spinner':
        return <Spinner />;
      case 'dots':
        return <Dots />;
      case 'pulse':
        return <Pulse />;
      case 'bars':
        return <Bars />;
      case 'ring':
        return <Ring />;
      case 'ripple':
        return <Ripple />;
      case 'square':
        return <Square />;
      case 'heart':
        return <Heart />;
      default:
        return <Spinner />;
    }
  };

  const loaderContent = (
    <div className={`${className}`}>
      {renderLoader()}
    </div>
  );

  // Return with or without overlay
  if (overlay) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 shadow-xl">
          {loaderContent}
        </div>
      </div>
    );
  }

  return loaderContent;
};

// Demo Component to showcase all loader types
const LoaderDemo = () => {
  const [currentLoader, setCurrentLoader] = React.useState('spinner');
  const [currentSize, setCurrentSize] = React.useState('medium');
  const [currentColor, setCurrentColor] = React.useState('teal');
  const [currentSpeed, setCurrentSpeed] = React.useState('normal');
  const [showText, setShowText] = React.useState(true);
  const [showOverlay, setShowOverlay] = React.useState(false);

  const loaderTypes = ['spinner', 'dots', 'pulse', 'bars', 'ring', 'ripple', 'square', 'heart'];
  const sizes = ['small', 'medium', 'large', 'xlarge'];
  const colors = ['teal', 'gold', 'crimson', 'burgundy'];
  const speeds = ['slow', 'normal', 'fast'];

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Luxe Commerce Loader</h1>
          <p className="text-gray-600">Reusable and configurable loading components</p>
        </div>

        {/* Controls */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Configuration</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            {/* Loader Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Type</label>
              <select
                value={currentLoader}
                onChange={(e) => setCurrentLoader(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              >
                {loaderTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* Size */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Size</label>
              <select
                value={currentSize}
                onChange={(e) => setCurrentSize(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              >
                {sizes.map(size => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
            </div>

            {/* Color */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
              <select
                value={currentColor}
                onChange={(e) => setCurrentColor(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              >
                {colors.map(color => (
                  <option key={color} value={color}>{color}</option>
                ))}
              </select>
            </div>

            {/* Speed */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Speed</label>
              <select
                value={currentSpeed}
                onChange={(e) => setCurrentSpeed(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              >
                {speeds.map(speed => (
                  <option key={speed} value={speed}>{speed}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Toggles */}
          <div className="flex space-x-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={showText}
                onChange={(e) => setShowText(e.target.checked)}
                className="mr-2"
              />
              Show Text
            </label>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={showOverlay}
                onChange={(e) => setShowOverlay(e.target.checked)}
                className="mr-2"
              />
              Show as Overlay
            </label>
          </div>
        </div>

        {/* Loader Preview */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Preview</h2>
          <div className="flex items-center justify-center h-32 bg-gray-50 rounded-lg">
            <LuxeLoader
              type={currentLoader}
              size={currentSize}
              color={currentColor}
              speed={currentSpeed}
              text={showText ? 'Loading...' : ''}
              overlay={showOverlay}
            />
          </div>
        </div>

        {/* Usage Examples */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Usage Examples</h2>
          
          <div className="bg-gray-900 text-gray-100 p-4 rounded-lg mb-4">
            <pre className="text-sm">
{`// Basic usage
<LuxeLoader />

// With custom props
<LuxeLoader 
  type="dots" 
  size="large" 
  color="gold" 
  text="Loading products..." 
/>

// As overlay
<LuxeLoader 
  type="spinner" 
  overlay={true} 
  text="Please wait..." 
/>

// Custom styling
<LuxeLoader 
  type="pulse" 
  size="small" 
  color="crimson" 
  speed="fast"
  className="my-4"
/>`}
            </pre>
          </div>
        </div>

        {/* All Loader Types Showcase */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">All Loader Types</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {loaderTypes.map(type => (
              <div key={type} className="text-center">
                <div className="h-20 flex items-center justify-center bg-gray-50 rounded-lg mb-2">
                  <LuxeLoader type={type} size="medium" color="teal" />
                </div>
                <p className="text-sm text-gray-600 capitalize">{type}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoaderDemo;