// import React, { useState, useEffect, useRef } from 'react';
// import { Search, ChevronDown } from 'lucide-react';

// const CustomDropdown = ({ categories, product, handleProductChange, loading, categoryLoading }) => {
//   const [categorySearch, setCategorySearch] = useState('');
//   const [isOpen, setIsOpen] = useState(false);
//   const dropdownRef = useRef(null);

//   // Filter categories based on search input
//   const filteredCategories = categories.filter((category) =>
//     category.name.toLowerCase().includes(categorySearch.toLowerCase())
//   );

//   // Get selected category name
//   const selectedCategory = categories.find((cat) => cat.id === product.categoryId);

//   // Handle clicks outside to close dropdown
//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setIsOpen(false);
//       }
//     };
//     document.addEventListener('mousedown', handleClickOutside);
//     return () => document.removeEventListener('mousedown', handleClickOutside);
//   }, []);

//   // Handle category selection
//   const handleSelect = (categoryId) => {
//     handleProductChange('categoryId', categoryId);
//     setIsOpen(false);
//     setCategorySearch(''); // Clear search after selection
//   };

//   return (
//     <div className="mb-4">
//       <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
//         Category *
//       </label>
//       <div className="relative" ref={dropdownRef}>
//         {/* Display Button */}
//         <button
//           type="button"
//           onClick={() => setIsOpen(!isOpen)}
//           className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary bg-white text-left flex items-center justify-between"
//           disabled={loading || categoryLoading}
//         >
//           <span className={selectedCategory ? 'text-black' : 'text-gray-500'}>
//             {selectedCategory ? selectedCategory.name : 'Search categories...'}
//           </span>
//           <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
//         </button>

//         {/* Dropdown List */}
//         {isOpen && !loading && !categoryLoading && (
//           <div className="absolute z-10 w-full mt-1 bg-white border border-secondary rounded-lg shadow-lg max-h-60 overflow-hidden">
//             {/* Search Input inside dropdown */}
//             <div className="p-3 border-b border-gray-200">
//               <div className="relative">
//                 <input
//                   type="text"
//                   value={categorySearch}
//                   onChange={(e) => setCategorySearch(e.target.value)}
//                   placeholder="Search categories..."
//                   className="w-full px-4 py-2 pl-10 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary"
//                 />
//                 <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
//               </div>
//             </div>

//             {/* Category List */}
//             <div className="max-h-48 overflow-y-auto">
//               {filteredCategories.length > 0 ? (
//                 filteredCategories.map((category) => (
//                   <div
//                     key={category.id}
//                     onClick={() => handleSelect(category.id)}
//                     className={`px-4 py-2 cursor-pointer hover:bg-gray-100 ${
//                       product.categoryId === category.id ? 'bg-gray-200' : ''
//                     }`}
//                   >
//                     {category.name} (ID: {category.id})
//                   </div>
//                 ))
//               ) : (
//                 <div className="px-4 py-2 text-gray-500">No categories found</div>
//               )}
//             </div>
//           </div>
//         )}

//         {/* Loading State */}
//         {categoryLoading && (
//           <p className="text-sm text-gray-500 mt-2">Loading categories...</p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default CustomDropdown;

import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronDown } from 'lucide-react';

const CustomDropdown = ({ categories, product, handleProductChange, categorySearch, setCategorySearch, loading, categoryLoading }:any) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Filter categories based on search input
  const filteredCategories = categories.filter((category) =>
    category.name.toLowerCase().includes(categorySearch.toLowerCase())
  );

  // Get selected category name
  const selectedCategory = categories.find((cat) => cat.id.toString() === product.categoryId);

  // Handle clicks outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle category selection
  const handleSelect = (categoryId:any) => {
    handleProductChange('categoryId', categoryId.toString());
    setIsOpen(false);
    setCategorySearch(''); // Clear search after selection
  };

  return (
    <div className="mb-4">
      <label className="block text-sm font-medium mb-2" style={{ color: '#540B0E' }}>
        Category *
      </label>
      <div className="relative" ref={dropdownRef}>
        {/* Display Button */}
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary bg-white text-left flex items-center justify-between"
          disabled={loading || categoryLoading}
        >
          <span className={selectedCategory ? 'text-black' : 'text-gray-500'}>
            {selectedCategory ? selectedCategory.name : 'Select a category'}
          </span>
          <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>

        {/* Dropdown List */}
        {isOpen && !loading && !categoryLoading && (
          <div className="absolute z-10 w-full mt-1 bg-white border border-secondary rounded-lg shadow-lg max-h-60 overflow-hidden">
            {/* Search Input inside dropdown */}
            <div className="p-3 border-b border-gray-200">
              <div className="relative">
                <input
                  type="text"
                  value={categorySearch}
                  onChange={(e) => setCategorySearch(e.target.value)}
                  placeholder="Search categories..."
                  className="w-full px-4 py-2 pl-10 border rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 focus:ring-secondary border-secondary"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
            </div>

            {/* Category List */}
            <div className="max-h-48 overflow-y-auto">
              {filteredCategories.length > 0 ? (
                filteredCategories?.map((category:any) => (
                  <div
                    key={category.id}
                    onClick={() => handleSelect(category.id)}
                    className={`px-4 py-2 cursor-pointer hover:bg-gray-100 ${
                      product.categoryId === category.id.toString() ? 'bg-gray-200' : ''
                    }`}
                  >
                    {category.name} (ID: {category.id})
                  </div>
                ))
              ) : (
                <div className="px-4 py-2 text-gray-500">No categories found</div>
              )}
            </div>
          </div>
        )}

        {/* Loading State */}
        {categoryLoading && (
          <p className="text-sm text-gray-500 mt-2">Loading categories...</p>
        )}
      </div>
    </div>
  );
};

export default CustomDropdown;