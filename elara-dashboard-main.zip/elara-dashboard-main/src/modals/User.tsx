// import React from 'react';
// import { X, } from 'lucide-react';

// interface UserModalProps {
//   isOpen: boolean;
//   onClose: () => void;
//   mode: 'add' | 'edit';
//   user: {
//     id: string;
//     fullName: string;
//     email: string;
//     password: string;
//     role: string;
//     mfaEnabled: boolean;
//     secret: string;
//     createdAt: string;
//   };
//   setUser: (user: {
//     id: string;
//     fullName: string;
//     email: string;
//     password: string;
//     role: string;
//     mfaEnabled: boolean;
//     secret: string;
//     createdAt: string;
//   }) => void;
//   onSave: () => void;
// }

// const UserModal: React.FC<UserModalProps> = ({ isOpen, onClose, mode, user, setUser, onSave }) => {
//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
//       <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-3xl">
//         <div className="flex justify-between items-center mb-6">
//           <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
//             {mode === 'add' ? 'Add User' : 'Edit User'}
//           </h2>
//           <button onClick={onClose} aria-label="Close">
//             <X className="h-5 w-5" style={{ color: '#335C67' }} />
//           </button>
//         </div>
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               Full Name
//             </label>
//             <input
//               type="text"
//               value={user.fullName}
//               onChange={(e) => setUser({ ...user, fullName: e.target.value })}
//               className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
//               style={{ borderColor: '#335C67' }}
//             />
//           </div>
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               Email
//             </label>
//             <input
//               type="email"
//               value={user.email}
//               disabled
//               className="mt-1 w-full px-3 py-2 border rounded bg-gray-100 cursor-not-allowed"
//               style={{ borderColor: '#335C67' }}
//             />
//           </div>
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               Password
//             </label>
//             <input
//               type="password"
//               value={user.password}
//               disabled
//               className="mt-1 w-full px-3 py-2 border rounded bg-gray-100 cursor-not-allowed"
//               style={{ borderColor: '#335C67' }}
//             />
//           </div>
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               Role
//             </label>
//             <select
//               value={user.role}
//               onChange={(e) => setUser({ ...user, role: e.target.value })}
//               className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
//               style={{ borderColor: '#335C67' }}
//             >
//               <option value="ADMIN">Admin</option>
//               <option value="VENDOR">Vendor</option>
//               <option value="USER">User</option>
//             </select>
//           </div>
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               MFA Enabled
//             </label>
//             <div className="mt-1 flex items-center">
//               <input
//                 type="checkbox"
//                 checked={user.mfaEnabled}
//                 onChange={(e) => setUser({ ...user, mfaEnabled: e.target.checked })}
//                 className="h-4 w-4 text-[#335C67] focus:ring-[#335C67] border-gray-300 rounded"
//               />
//               <span className="ml-2 text-sm" style={{ color: '#540B0E' }}>
//                 {user.mfaEnabled ? 'Enabled' : 'Disabled'}
//               </span>
//             </div>
//           </div>
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               MFA Secret
//             </label>
//             <input
//               type="text"
//               value={user.secret}
//               disabled
//               className="mt-1 w-full px-3 py-2 border rounded bg-gray-100 cursor-not-allowed"
//               style={{ borderColor: '#335C67' }}
//             />
//           </div>
//         </div>
//         <div className="flex justify-end space-x-3 mt-6">
//           <button
//             onClick={onClose}
//             className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
//             style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
//           >
//             Cancel
//           </button>
//           <button
//             onClick={onSave}
//             className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
//             style={{ color: '#335C67', borderColor: '#335C67' }}
//           >
//             Save
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default UserModal;

import React from 'react';
import { X } from 'lucide-react';

interface UserModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'add' | 'edit';
  user: {
    id: string;
    fullName: string;
    email: string;
    password: string;
    role: string;
    mfaEnabled: boolean;
    secret: string;
    createdAt: string;
  };
  setUser: (user: {
    id: string;
    fullName: string;
    email: string;
    password: string;
    role: string;
    mfaEnabled: boolean;
    secret: string;
    createdAt: string;
  }) => void;
  onSave: () => void;
}

const UserModal: React.FC<UserModalProps> = ({ isOpen, onClose, mode, user, setUser, onSave }) => {
  if (!isOpen) return null;

  const isEditMode = mode === 'edit';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-3xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
            {mode === 'add' ? 'Add User' : 'Edit User'}
          </h2>
          <button onClick={onClose} aria-label="Close">
            <X className="h-5 w-5" style={{ color: '#335C67' }} />
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Full Name
            </label>
            <input
              type="text"
              value={user.fullName}
              onChange={(e) => setUser({ ...user, fullName: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Email
            </label>
            <input
              type="email"
              value={user.email}
              onChange={(e) => setUser({ ...user, email: e.target.value })}
              disabled={isEditMode}
              className={`mt-1 w-full px-3 py-2 border rounded focus:outline-none ${isEditMode ? 'bg-gray-100 cursor-not-allowed' : 'focus:ring-2 focus:ring-[#335C67]'}`}
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Password
            </label>
            <input
              type="password"
              value={user.password}
              onChange={(e) => setUser({ ...user, password: e.target.value })}
              disabled={isEditMode}
              className={`mt-1 w-full px-3 py-2 border rounded focus:outline-none ${isEditMode ? 'bg-gray-100 cursor-not-allowed' : 'focus:ring-2 focus:ring-[#335C67]'}`}
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Role
            </label>
            <select
              value={user.role}
              onChange={(e) => setUser({ ...user, role: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="ADMIN">Admin</option>
              <option value="VENDOR">Vendor</option>
              <option value="USER">User</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              MFA Enabled
            </label>
            <div className="mt-1 flex items-center">
              <input
                type="checkbox"
                checked={user.mfaEnabled}
                onChange={(e) => setUser({ ...user, mfaEnabled: e.target.checked })}
                className="h-4 w-4 text-[#335C67] focus:ring-[#335C67] border-gray-300 rounded"
              />
              <span className="ml-2 text-sm" style={{ color: '#540B0E' }}>
                {user.mfaEnabled ? 'Enabled' : 'Disabled'}
              </span>
            </div>
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              MFA Secret
            </label>
            <input
              type="text"
              value={user.secret}
              onChange={(e) => setUser({ ...user, secret: e.target.value })}
              disabled={isEditMode}
              className={`mt-1 w-full px-3 py-2 border rounded focus:outline-none ${isEditMode ? 'bg-gray-100 cursor-not-allowed' : 'focus:ring-2 focus:ring-[#335C67]'}`}
              style={{ borderColor: '#335C67' }}
            />
          </div>
        </div>
        <div className="flex justify-end space-x-3 mt-6">
          <button
            onClick={onClose}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
            style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
          >
            Cancel
          </button>
          <button
            onClick={onSave}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
            style={{ color: '#335C67', borderColor: '#335C67' }}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserModal;