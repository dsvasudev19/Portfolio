import React from 'react';
import { X } from 'lucide-react';

interface ComplaintModalProps {
  isOpen: boolean;
  onClose: () => void;
  complaint: {
    subject: string;
    description: string;
    priority: string;
  };
  setComplaint: (complaint: {
    subject: string;
    description: string;
    priority: string;
  }) => void;
  onSave: () => void;
}

const ComplaintModal: React.FC<ComplaintModalProps> = ({ isOpen, onClose, complaint, setComplaint, onSave }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
            Raise a Complaint
          </h2>
          <button onClick={onClose}>
            <X className="h-5 w-5" style={{ color: '#335C67' }} />
          </button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Subject
            </label>
            <input
              type="text"
              value={complaint.subject}
              onChange={(e) => setComplaint({ ...complaint, subject: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Description
            </label>
            <textarea
              value={complaint.description}
              onChange={(e) => setComplaint({ ...complaint, description: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
              rows={4}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Priority
            </label>
            <select
              value={complaint.priority}
              onChange={(e) => setComplaint({ ...complaint, priority: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </div>
          <div className="flex justify-end space-x-2">
            <button
              onClick={onClose}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
              style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
            >
              Cancel
            </button>
            <button
              onClick={onSave}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
              style={{ color: '#335C67', borderColor: '#335C67' }}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplaintModal;