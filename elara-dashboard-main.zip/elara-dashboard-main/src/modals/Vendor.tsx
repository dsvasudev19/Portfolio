
// import React, { useState } from 'react';
// import { axiosInstance } from '../../axiosInstance';

// const VendorModal = ({ mode, vendor, onSave, onClose, colors }:any) => {
//   const [formData, setFormData] = useState({
//     id: vendor.id || '',
//     businessName: vendor.businessName || '',
//     email: vendor.email || '',
//     phoneNumber: vendor.phoneNumber || '',
//     address: vendor.address || '',
//     taxId: vendor.taxId || '',
//     status: vendor.status || 'PENDING',
//     document: null
//   });

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: name === 'approved' ? value === 'true' : value
//     }));
//   };

//   const handleFileChange = (e) => {
//     setFormData((prev) => ({
//       ...prev,
//       document: e.target.files[0]
//     }));
//   };

//   const handleSubmit = async () => {
//     try {
//       const data = new FormData();
//       data.append('vendor', new Blob([JSON.stringify({
//         id: formData.id,
//         businessName: formData.businessName,
//         email: formData.email,
//         phoneNumber: formData.phoneNumber,
//         address: formData.address,
//         taxId: formData.taxId,
//         status: formData.status
//       })], { type: 'application/json' }));
//       if (formData.document) {
//         data.append('document', formData.document);
//       }

//       if (mode === 'add') {
//         await axiosInstance.post('/vendors', data, {
//           headers: { 'Content-Type': 'multipart/form-data' }
//         });
//       } else {
//         await axiosInstance.put(`/vendors/${formData.id}`, data, {
//           headers: { 'Content-Type': 'multipart/form-data' }
//         });
//       }
//       onSave();
//     } catch (error) {
//       console.error(`Error ${mode === 'add' ? 'creating' : 'updating'} vendor:`, error);
//     }
//   };

//   return (
//     <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50">
//       <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
//         {/* Header */}
//         <div 
//           className="px-8 py-6 border-b border-gray-200 rounded-t-2xl"
//         >
//           <h2 className="text-2xl font-bold text-burgundy">
//             {mode === 'add' ? 'Add New Vendor' : 'Edit Vendor'}
//           </h2>
//           <p className="text-burgundy-200 text-sm mt-1">
//             {mode === 'add' ? 'Enter vendor information to create a new vendor profile' : 'Update vendor information'}
//           </p>
//         </div>

//         {/* Form Content */}
//         <div className="px-8 py-6">
//           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//             {/* Business Name */}
//             <div className="md:col-span-2">
//               <label className="block text-sm font-semibold mb-2" style={{ color: colors.burgundy }}>
//                 Business Name *
//               </label>
//               <input
//                 type="text"
//                 name="businessName"
//                 value={formData.businessName}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-all duration-200"
//                 style={{ 
//                   borderColor: colors.teal,
//                   focusRingColor: colors.teal
//                 }}
//                 placeholder="Enter business name"
//               />
//             </div>

//             {/* Email */}
//             <div>
//               <label className="block text-sm font-semibold mb-2" style={{ color: colors.burgundy }}>
//                 Email Address *
//               </label>
//               <input
//                 type="email"
//                 name="email"
//                 value={formData.email}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-all duration-200"
//                 style={{ 
//                   borderColor: colors.teal,
//                   focusRingColor: colors.teal
//                 }}
//                 placeholder="vendor@company.com"
//               />
//             </div>

//             {/* Phone Number */}
//             <div>
//               <label className="block text-sm font-semibold mb-2" style={{ color: colors.burgundy }}>
//                 Phone Number *
//               </label>
//               <input
//                 type="text"
//                 name="phoneNumber"
//                 value={formData.phoneNumber}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-all duration-200"
//                 style={{ 
//                   borderColor: colors.teal,
//                   focusRingColor: colors.teal
//                 }}
//                 placeholder="+1 (555) 123-4567"
//               />
//             </div>

//             {/* Address */}
//             <div className="md:col-span-2">
//               <label className="block text-sm font-semibold mb-2" style={{ color: colors.burgundy }}>
//                 Business Address
//               </label>
//               <input
//                 type="text"
//                 name="address"
//                 value={formData.address}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-all duration-200"
//                 style={{ 
//                   borderColor: colors.teal,
//                   focusRingColor: colors.teal
//                 }}
//                 placeholder="123 Main St, City, State, ZIP"
//               />
//             </div>

//             {/* Tax ID */}
//             <div>
//               <label className="block text-sm font-semibold mb-2" style={{ color: colors.burgundy }}>
//                 Tax ID/EIN
//               </label>
//               <input
//                 type="text"
//                 name="taxId"
//                 value={formData.taxId}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-all duration-200"
//                 style={{ 
//                   borderColor: colors.teal,
//                   focusRingColor: colors.teal
//                 }}
//                 placeholder="XX-XXXXXXX"
//               />
//             </div>

//             {/* Status */}
//             <div>
//               <label className="block text-sm font-semibold mb-2" style={{ color: colors.burgundy }}>
//                 Status *
//               </label>
//               <select
//                 name="status"
//                 value={formData.status}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-all duration-200"
//                 style={{ 
//                   borderColor: colors.teal,
//                   focusRingColor: colors.teal
//                 }}
//               >
//                 <option value="PENDING">Pending</option>
//                 <option value="ACTIVE">Active</option>
//                 <option value="INACTIVE">Inactive</option>
//               </select>
//             </div>

//             {/* Document Upload */}
//             <div className="md:col-span-2">
//               <label className="block text-sm font-semibold mb-2" style={{ color: colors.burgundy }}>
//                 Supporting Document
//               </label>
//               <div className="relative">
//                 <input
//                   type="file"
//                   name="document"
//                   onChange={handleFileChange}
//                   className="w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-all duration-200 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:cursor-pointer"
//                   style={{ 
//                     borderColor: colors.teal,
//                     focusRingColor: colors.teal
//                   }}
//                 />
//               </div>
//               <p className="text-xs text-gray-500 mt-1">
//                 Upload business license, tax documents, or other relevant files
//               </p>
//             </div>
//           </div>
//         </div>

//         {/* Footer */}
//         <div className="px-8 py-6 bg-gray-50 border-t border-gray-200 rounded-b-2xl">
//           <div className="flex justify-end space-x-4">
//             <button
//               onClick={onClose}
//               className="px-6 py-3 rounded-lg font-semibold text-sm border-2 transition-all duration-200 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-opacity-50"
//               style={{ 
//                 color: colors.crimson,
//                 borderColor: colors.crimson
//               }}
//             >
//               Cancel
//             </button>
//             <button
//               onClick={handleSubmit}
//               className="px-6 py-3 rounded-lg font-semibold text-sm text-teal border-2 transition-all duration-200 hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-opacity-50"
//               style={{ 
//                 borderColor: colors.teal
//               }}
//             >
//               {mode === 'add' ? 'Create Vendor' : 'Update Vendor'}
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default VendorModal;

import React, { useState } from 'react';
import { axiosInstance } from '../../axiosInstance';

const VendorModal = ({ mode, vendor, onSave, onClose, colors }:any) => {
  const [formData, setFormData] = useState({
    id: vendor.id || '',
    businessName: vendor.businessName || '',
    email: vendor.email || '',
    phoneNumber: vendor.phoneNumber || '',
    address: vendor.address || '',
    taxId: vendor.taxId || '',
    status: vendor.status || 'PENDING',
    document: null
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'approved' ? value === 'true' : value
    }));
  };

  const handleFileChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      document: e.target.files[0]
    }));
  };

  const handleSubmit = async () => {
    try {
      const data = new FormData();
      data.append('vendor', new Blob([JSON.stringify({
        id: formData.id,
        businessName: formData.businessName,
        email: formData.email,
        phoneNumber: formData.phoneNumber,
        address: formData.address,
        taxId: formData.taxId,
        status: formData.status
      })], { type: 'application/json' }));
      if (formData.document) {
        data.append('document', formData.document);
      }

      if (mode === 'add') {
        await axiosInstance.post('/vendors', data, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
      } else {
        await axiosInstance.put(`/vendors/${formData.id}`, data, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
      }
      onSave();
    } catch (error) {
      console.error(`Error ${mode === 'add' ? 'creating' : 'updating'} vendor:`, error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[85vh] overflow-y-auto">
        {/* Header */}
        <div className="px-5 py-3 border-b border-gray-200 rounded-t-lg flex justify-between items-center">
          <div>
            <h2 className="text-lg font-semibold text-gray-800">
              {mode === 'add' ? 'Add Vendor' : 'Edit Vendor'}
            </h2>
            <p className="text-gray-500 text-xs mt-0.5">
              {mode === 'add' ? 'Create new vendor profile' : 'Update vendor information'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-md hover:bg-gray-100"
            aria-label="Close modal"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Form Content */}
        <div className="px-5 py-4">
          <div className="space-y-4">
            {/* Business Name */}
            <div>
              <label className="block text-xs font-medium mb-1 text-gray-700">
                Business Name *
              </label>
              <input
                type="text"
                name="businessName"
                value={formData.businessName}
                onChange={handleInputChange}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-burgundy focus:border-burgundy transition-colors"
                placeholder="Enter business name"
              />
            </div>

            {/* Email and Phone in same row */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1 text-gray-700">
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-burgundy focus:border-burgundy transition-colors"
                  placeholder="vendor@company.com"
                />
              </div>

              <div>
                <label className="block text-xs font-medium mb-1 text-gray-700">
                  Phone Number *
                </label>
                <input
                  type="text"
                  name="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-burgundy focus:border-burgundy transition-colors"
                  placeholder="+1 (555) 123-4567"
                />
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-medium mb-1 text-gray-700">
                Business Address
              </label>
              <input
                type="text"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-burgundy focus:border-burgundy transition-colors"
                placeholder="123 Main St, City, State, ZIP"
              />
            </div>

            {/* Tax ID and Status in same row */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1 text-gray-700">
                  Tax ID/EIN
                </label>
                <input
                  type="text"
                  name="taxId"
                  value={formData.taxId}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-burgundy focus:border-burgundy transition-colors"
                  placeholder="XX-XXXXXXX"
                />
              </div>

              <div>
                <label className="block text-xs font-medium mb-1 text-gray-700">
                  Status *
                </label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-burgundy focus:border-burgundy transition-colors"
                >
                  <option value="PENDING">Pending</option>
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                </select>
              </div>
            </div>

            {/* Document Upload */}
            <div>
              <label className="block text-xs font-medium mb-1 text-gray-700">
                Supporting Document
              </label>
              <input
                type="file"
                name="document"
                onChange={handleFileChange}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-burgundy focus:border-burgundy transition-colors file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-medium file:bg-burgundy-50 file:text-burgundy-700 hover:file:bg-burgundy-100 file:cursor-pointer"
              />
              <p className="text-xs text-gray-500 mt-1">
                Upload business license, tax documents, or other relevant files
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-gray-50 border-t border-gray-200 rounded-b-lg">
          <div className="flex justify-end space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-teal bg-white border border-teal rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              className="px-4 py-2 text-sm font-medium text-burdundy border border-burgundy rounded-md hover:bg-burgundy-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-burgundy transition-colors"
            >
              {mode === 'add' ? 'Create Vendor' : 'Update Vendor'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VendorModal;