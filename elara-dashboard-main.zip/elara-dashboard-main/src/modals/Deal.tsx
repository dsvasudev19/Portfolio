import React from 'react';
import { X } from 'lucide-react';

interface DealModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'add' | 'edit';
  deal: {
    id: string;
    name: string;
    dealType: string;
    discountValue: number;
    startDate: string;
    endDate: string;
    maxRedemptions: number;
    status: string;
    applicableProducts: Array<{ id: string; name: string }>;
    applicableCategories: Array<{ id: string; name: string }>;
    applicableShops: Array<{ id: string; name: string }>;
  };
  setDeal: (deal: {
    id: string;
    name: string;
    dealType: string;
    discountValue: number;
    startDate: string;
    endDate: string;
    maxRedemptions: number;
    status: string;
    applicableProducts: Array<{ id: string; name: string }>;
    applicableCategories: Array<{ id: string; name: string }>;
    applicableShops: Array<{ id: string; name: string }>;
  }) => void;
  onSave: () => void;
}

const DealModal: React.FC<DealModalProps> = ({ isOpen, onClose, mode, deal, setDeal, onSave }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
            {mode === 'add' ? 'Add Deal' : 'Edit Deal'}
          </h2>
          <button onClick={onClose}>
            <X className="h-5 w-5" style={{ color: '#335C67' }} />
          </button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Deal Name
            </label>
            <input
              type="text"
              value={deal.name}
              onChange={(e) => setDeal({ ...deal, name: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Deal Type
            </label>
            <select
              value={deal.dealType}
              onChange={(e) => setDeal({ ...deal, dealType: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="DISCOUNT">Discount</option>
              <option value="BOGO">Buy One Get One</option>
            </select>
          </div>
          {deal.dealType === 'DISCOUNT' && (
            <div>
              <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
                Discount Value (%)
              </label>
              <input
                type="number"
                value={deal.discountValue}
                onChange={(e) => setDeal({ ...deal, discountValue: parseFloat(e.target.value) })}
                className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
                step="0.01"
              />
            </div>
          )}
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Start Date
            </label>
            <input
              type="datetime-local"
              value={deal.startDate}
              onChange={(e) => setDeal({ ...deal, startDate: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67'}}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              End Date
            </label>
            <input
              type="datetime-local"
              value={deal.endDate}
              onChange={(e) => setDeal({ ...deal, endDate: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Max Redemptions
            </label>
            <input
              type="number"
              value={deal.maxRedemptions}
              onChange={(e) => setDeal({ ...deal, maxRedemptions: parseInt(e.target.value) })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Status
            </label>
            <select
              value={deal.status}
              onChange={(e) => setDeal({ ...deal, status: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67'}}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Expired">Expired</option>
            </select>
          </div>
          <div className="flex justify-end space-x-2">
            <button
              onClick={onClose}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
              style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
            >
              Cancel
            </button>
            <button
              onClick={onSave}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
              style={{ color: '#335C67', borderColor: '#335C67' }}
            >
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DealModal;