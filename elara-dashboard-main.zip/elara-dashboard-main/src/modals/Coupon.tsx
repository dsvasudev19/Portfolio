
import React from 'react';
import { X } from 'lucide-react';

interface CouponModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'add' | 'edit';
  coupon: {
    id: string;
    code: string;
    discountType: string;
    discountValue: number;
    validFrom: string;
    validTo: string;
    maxUses: number;
    usesPerUser: number;
    minOrderValue: number;
    status: string;
  };
  setCoupon: (coupon: {
    id: string;
    code: string;
    discountType: string;
    discountValue: number;
    validFrom: string;
    validTo: string;
    maxUses: number;
    usesPerUser: number;
    minOrderValue: number;
    status: string;
  }) => void;
  onSave: () => void;
}

const CouponModal: React.FC<CouponModalProps> = ({ isOpen, onClose, mode, coupon, setCoupon, onSave }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-3xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
            {mode === 'add' ? 'Add Coupon' : 'Edit Coupon'}
          </h2>
          <button onClick={onClose} aria-label="Close">
            <X className="h-5 w-5" style={{ color: '#335C67' }} />
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Coupon Code
            </label>
            <input
              type="text"
              value={coupon.code}
              onChange={(e) => setCoupon({ ...coupon, code: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Discount Type
            </label>
            <select
              value={coupon.discountType}
              onChange={(e) => setCoupon({ ...coupon, discountType: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="PERCENTAGE">Percentage</option>
              <option value="FIXED">Fixed Amount</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Discount Value
            </label>
            <input
              type="number"
              value={coupon.discountValue}
              onChange={(e) => setCoupon({ ...coupon, discountValue: parseFloat(e.target.value) })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
              step="0.01"
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Valid From
            </label>
            <input
              type="datetime-local"
              value={coupon.validFrom}
              onChange={(e) => setCoupon({ ...coupon, validFrom: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Valid To
            </label>
            <input
              type="datetime-local"
              value={coupon.validTo}
              onChange={(e) => setCoupon({ ...coupon, validTo: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Max Uses
            </label>
            <input
              type="number"
              value={coupon.maxUses}
              onChange={(e) => setCoupon({ ...coupon, maxUses: parseInt(e.target.value) })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Uses Per User
            </label>
            <input
              type="number"
              value={coupon.usesPerUser}
              onChange={(e) => setCoupon({ ...coupon, usesPerUser: parseInt(e.target.value) })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Minimum Order Value
            </label>
            <input
              type="number"
              value={coupon.minOrderValue}
              onChange={(e) => setCoupon({ ...coupon, minOrderValue: parseFloat(e.target.value) })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
              step="0.01"
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Status
            </label>
            <select
              value={coupon.status}
              onChange={(e) => setCoupon({ ...coupon, status: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="Active">Active</option>
              <option value="Expired">Expired</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>
        <div className="flex justify-end space-x-3 mt-6">
          <button
            onClick={onClose}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
            style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
          >
            Cancel
          </button>
          <button
            onClick={onSave}
            className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
            style={{ color: '#335C67', borderColor: '#335C67' }}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default CouponModal;