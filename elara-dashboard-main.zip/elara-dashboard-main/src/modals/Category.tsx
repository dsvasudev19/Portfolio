

// import React from 'react';
// import { X, Image } from 'lucide-react';

// interface CategoryModalProps {
//   isOpen: boolean;
//   onClose: () => void;
//   mode: 'add' | 'edit';
//   category: { id: string; name: string; description: string; status: string; images: File[] };
//   setCategory: (category: { id: string; name: string; description: string; status: string; images: File[] }) => void;
//   onSave: () => void;
// }

// const CategoryModal: React.FC<CategoryModalProps> = ({ isOpen, onClose, mode, category, setCategory, onSave }) => {
//   if (!isOpen) return null;

//   const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     if (e.target.files) {
//       const files = Array.from(e.target.files);
//       setCategory({ ...category, images: files });
//     }
//   };

//   return (
//     <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
//       <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
//         <div className="flex justify-between items-center mb-4">
//           <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
//             {mode === 'add' ? 'Add Category' : 'Edit Category'}
//           </h2>
//           <button onClick={onClose}>
//             <X className="h-5 w-5" style={{ color: '#335C67' }} />
//           </button>
//         </div>
//         <div className="space-y-4">
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               Name
//             </label>
//             <input
//               type="text"
//               value={category?.name}
//               onChange={(e) => setCategory({ ...category, name: e.target.value })}
//               className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
//               style={{ borderColor: '#335C67' }}
//             />
//           </div>
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               Description
//             </label>
//             <textarea
//               value={category?.description}
//               onChange={(e) => setCategory({ ...category, description: e.target.value })}
//               className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
//               style={{ borderColor: '#335C67' }}
//               rows={4}
//             />
//           </div>
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               Status
//             </label>
//             <select
//               value={category?.status}
//               onChange={(e) => setCategory({ ...category, status: e.target.value })}
//               className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
//               style={{ borderColor: '#335C67' }}
//             >
//               <option value="Active">Active</option>
//               <option value="Inactive">Inactive</option>
//             </select>
//           </div>
//           <div>
//             <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
//               Images
//             </label>
//             <div className="mt-1 flex items-center">
//               <input
//                 type="file"
//                 multiple
//                 accept="image/*"
//                 onChange={handleImageChange}
//                 className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
//                 style={{ borderColor: '#335C67' }}
//               />
//               <Image className="h-5 w-5 ml-2" style={{ color: '#335C67' }} />
//             </div>
//             {category.images && category.images.length > 0 && (
//               <div className="mt-2 flex flex-wrap gap-2">
//                 {category.images.map((file, index) => (
//                   <div key={index} className="text-xs text-gray-600">
//                     {file.name}
//                   </div>
//                 ))}
//               </div>
//             )}
//           </div>
//           <div className="flex justify-end space-x-2">
//             <button
//               onClick={onClose}
//               className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
//               style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
//             >
//               Cancel
//             </button>
//             <button
//               onClick={onSave}
//               className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
//               style={{ color: '#335C67', borderColor: '#335C67' }}
//             >
//               Save
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default CategoryModal;

import React, { useState } from 'react';
import { X, Image } from 'lucide-react';

interface CategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'add' | 'edit';
  category: { id: number | null; name: string; description: string; status: string; images: File[]; variantAttributes: string[] };
  setCategory: (category: { id: number | null; name: string; description: string; status: string; images: File[]; variantAttributes: string[] }) => void;
  onSave: () => void;
}

const CategoryModal: React.FC<CategoryModalProps> = ({ isOpen, onClose, mode, category, setCategory, onSave }) => {
  const [newAttribute, setNewAttribute] = useState('');

  if (!isOpen) return null;

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setCategory({ ...category, images: files });
    }
  };

  const handleAddAttribute = () => {
    if (newAttribute.trim() && !category?.variantAttributes?.includes(newAttribute.trim())) {
      setCategory({ ...category, variantAttributes: [...category.variantAttributes, newAttribute.trim()] });
      setNewAttribute('');
    }
  };

  const handleRemoveAttribute = (attribute: string) => {
    setCategory({ ...category, variantAttributes: category.variantAttributes.filter(attr => attr !== attribute) });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold" style={{ color: '#540B0E' }}>
            {mode === 'add' ? 'Add Category' : 'Edit Category'}
          </h2>
          <button onClick={onClose}>
            <X className="h-5 w-5" style={{ color: '#335C67' }} />
          </button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Name
            </label>
            <input
              type="text"
              value={category.name}
              onChange={(e) => setCategory({ ...category, name: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Description
            </label>
            <textarea
              value={category.description}
              onChange={(e) => setCategory({ ...category, description: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
              rows={4}
            />
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Status
            </label>
            <select
              value={category.status}
              onChange={(e) => setCategory({ ...category, status: e.target.value })}
              className="mt-1 w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
              style={{ borderColor: '#335C67' }}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Variant Attributes
            </label>
            <div className="flex items-center mt-1">
              <input
                type="text"
                value={newAttribute}
                onChange={(e) => setNewAttribute(e.target.value)}
                placeholder="Add attribute (e.g., Color, Size)"
                className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
              <button
                onClick={handleAddAttribute}
                className="ml-2 px-3 py-2 rounded hover:bg-gray-100 border transition-colors"
                style={{ color: '#335C67', borderColor: '#335C67' }}
              >
                Add
              </button>
            </div>
            {category?.variantAttributes?.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {category.variantAttributes.map((attr, index) => (
                  <div
                    key={index}
                    className="flex items-center px-2 py-1 bg-gray-100 rounded text-sm"
                  >
                    {attr}
                    <button
                      onClick={() => handleRemoveAttribute(attr)}
                      className="ml-2 text-red-600 hover:text-red-800"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div>
            <label className="text-sm font-medium" style={{ color: '#540B0E' }}>
              Images
            </label>
            <div className="mt-1 flex items-center">
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageChange}
                className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#335C67]"
                style={{ borderColor: '#335C67' }}
              />
              <Image className="h-5 w-5 ml-2" style={{ color: '#335C67' }} />
            </div>
            {category.images && category.images.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {category.images.map((file, index) => (
                  <div key={index} className="text-xs text-gray-600">
                    {file.name}
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="flex justify-end space-x-2">
            <button
              onClick={onClose}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
              style={{ color: '#9E2A2B', borderColor: '#9E2A2B' }}
            >
              Cancel
            </button>
            <button
              onClick={onSave}
              className="text-sm px-4 py-2 rounded hover:bg-gray-100 border transition-colors"
              style={{ color: '#335C67', borderColor: '#335C67' }}
            >
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryModal;