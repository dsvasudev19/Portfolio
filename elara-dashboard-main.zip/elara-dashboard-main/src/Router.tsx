import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./Layout/Dashboard";
import Vendors from "./pages/Vendors";
import Users from "./pages/Users";
import Coupons from "./pages/Coupons";
import Reviews from "./pages/Reviews";
import Products from "./pages/Products";
import Orders from "./pages/Orders";
import Transactions from "./pages/Transactions";
import Login from "./pages/auth/Login";
import Home from "./pages/DashboardHome";
import Register from "./pages/auth/Register";
import NotFound from "./pages/NotFound";
import Support from "./pages/Support";
import ForgotPassword from "./pages/auth/ForgotPassword";
import ResetPassword from "./pages/auth/ResetPassword";

import Subscriptions from "./pages/Subscriptions";
import Categories from "./pages/Categories";
import DealManagement from "./pages/Deals";
import LoaderDemo from "./pages/Test";
import HelpSupport from "./pages/HelpAndSupport";
import Settings from "./pages/Settings";
import AddProduct from "./pages/AddProduct";
import AuthGuard from "./AuthGuard";
import ReportsDashboard from './pages/ReportsAndAnalytics'
import ProductViewDetails from "./pages/ProductDetails";
import WalletManagement from "./pages/Wallets";
const AppRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/dashboard/*" element={ <AuthGuard><Dashboard /></AuthGuard>}>
          <Route path="home" element={<Home />} />
          <Route path="vendors" element={<Vendors />} />
          <Route path="users" element={<Users />} />
          <Route path="coupons" element={<Coupons />} />
          <Route path="deals" element={<DealManagement />} />
          <Route path="reviews" element={<Reviews />} />
          <Route path="products" element={<Products />} />
          <Route path="products/add-product" element={<AddProduct />} />
          <Route path="products/update-details/:id" element={<AddProduct />} />
          <Route path="products/view-details/:id" element={<ProductViewDetails />} />
          <Route path="orders" element={<Orders />} />
          <Route path="transactions" element={<Transactions />} />
          <Route path="support" element={<Support />} />
          <Route path="subscriptions" element={<Subscriptions />} />
          <Route path="categories" element={<Categories />} />
          <Route path="test" element={<LoaderDemo />} />
          <Route path="reports" element={<ReportsDashboard />} />
          <Route path="help-and-support" element={<HelpSupport />} />
          <Route path="wallets" element={<WalletManagement />} />
          <Route path="settings" element={<Settings />} />
          <Route path="*" element={<NotFound />} />
        </Route>
        <Route path="/auth/*">
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="forgot-password" element={<ForgotPassword />} />
          <Route path="reset-password" element={<ResetPassword />} />
          <Route path="*" element={<NotFound />} />
        </Route>
        <Route path="*" element={<NotFound />} />
        <Route path="/" element={<Navigate to="/auth/login" />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
