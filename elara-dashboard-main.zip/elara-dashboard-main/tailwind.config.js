/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html"
  ],
  theme: {
    extend: {
      colors: {
        // Main palette colors - exact same as your design
        'teal': '#335C67',
        'butter': '#FFF3B0',
        'gold': '#E09F3E',
        'crimson': '#9E2A2B',
        'burgundy': '#540B0E',
        
        // Primary/Secondary system
        primary: {
          DEFAULT: '#540B0E', // burgundy
          50: '#FDF2F2',
          100: '#FCE8E8',
          200: '#F8D5D6',
          300: '#F1B2B4',
          400: '#E78B8E',
          500: '#D85D61',
          600: '#C33B40',
          700: '#9E2A2B', // crimson
          800: '#7A1F20',
          900: '#540B0E', // burgundy
        },
        
        secondary: {
          DEFAULT: '#335C67', // teal
          50: '#F0F7F8',
          100: '#E0EEF1',
          200: '#C2DDE3',
          300: '#9BC4CD',
          400: '#6FA3B0',
          500: '#4F8392',
          600: '#406872',
          700: '#335C67', // teal
          800: '#2A4A53',
          900: '#1F3439',
        },
        
        accent: {
          DEFAULT: '#E09F3E', // gold
          50: '#FEF9F0',
          100: '#FDF2E0',
          200: '#FBE5C1',
          300: '#F8D597',
          400: '#F4C16B',
          500: '#F0AD45',
          600: '#E09F3E', // gold
          700: '#C8882E',
          800: '#A56F25',
          900: '#7A521C',
        },
        
        neutral: {
          DEFAULT: '#FFF3B0', // butter
          50: '#FFFEF9',
          100: '#FFFDF2',
          200: '#FFFBE5',
          300: '#FFF8D1',
          400: '#FFF5B8',
          500: '#FFF3B0', // butter
          600: '#F0E199',
          700: '#E0CF82',
          800: '#D1BD6B',
          900: '#C2AB54',
        },
        
        // Color combinations from your design
        warmth: {
          light: '#FFF3B0', // butter
          DEFAULT: '#E09F3E', // gold
          dark: '#9E2A2B', // crimson
        },
        
        depth: {
          light: '#335C67', // teal
          DEFAULT: '#9E2A2B', // crimson
          dark: '#540B0E', // burgundy
        },
        
        luxury: {
          light: '#FFF3B0', // butter
          DEFAULT: '#E09F3E', // gold
          dark: '#540B0E', // burgundy
        },
        
        contrast: {
          cool: '#335C67', // teal
          warm: '#FFF3B0', // butter
          bold: '#9E2A2B', // crimson
        },
        
        // Gradient stops for your complex gradients
        gradient: {
          'burgundy-crimson': 'linear-gradient(to bottom right, #540B0E, #9E2A2B)',
          'crimson-teal': 'linear-gradient(to bottom right, #9E2A2B, #335C67)',
          'teal-gold': 'linear-gradient(to bottom right, #335C67, #E09F3E)',
          'gold-butter': 'linear-gradient(to bottom right, #E09F3E, #FFF3B0)',
          'butter-burgundy': 'linear-gradient(to bottom right, #FFF3B0, #540B0E)',
          'full-spectrum': 'linear-gradient(to right, #540B0E, #9E2A2B, #E09F3E, #335C67)',
        }
      },
      
      // Extended theme for your dramatic design
      fontFamily: {
        'dramatic': ['Inter', 'system-ui', 'sans-serif'],
      },
      
      boxShadow: {
        'dramatic': '0 25px 50px -12px rgba(84, 11, 14, 0.5)',
        'gold': '0 25px 50px -12px rgba(224, 159, 62, 0.3)',
        'teal': '0 25px 50px -12px rgba(51, 92, 103, 0.3)',
        'crimson': '0 25px 50px -12px rgba(158, 42, 43, 0.4)',
        'inner-dramatic': 'inset 0 2px 4px 0 rgba(84, 11, 14, 0.3)',
      },
      
      backgroundImage: {
        'gradient-dramatic': 'linear-gradient(135deg, #540B0E 0%, #9E2A2B 25%, #E09F3E 50%, #335C67 75%, #FFF3B0 100%)',
        'gradient-warmth': 'linear-gradient(135deg, #FFF3B0 0%, #E09F3E 50%, #9E2A2B 100%)',
        'gradient-depth': 'linear-gradient(135deg, #335C67 0%, #9E2A2B 50%, #540B0E 100%)',
        'gradient-luxury': 'linear-gradient(135deg, #FFF3B0 0%, #E09F3E 50%, #540B0E 100%)',
      },
      
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'bounce-gentle': 'bounce 2s infinite',
      },
      
      scale: {
        '102': '1.02',
        '103': '1.03',
        '108': '1.08',
      },
      
      rotate: {
        '1': '1deg',
        '2': '2deg',
        '3': '3deg',
      },
      
      transitionDuration: {
        '400': '400ms',
        '600': '600ms',
      }
    },
  },
  plugins: [],
}