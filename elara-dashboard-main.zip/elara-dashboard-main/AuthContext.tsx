import { createContext, useState, useContext, useEffect } from "react";
import { axiosInstance } from './axiosInstance';

const AuthContext = createContext<any>(undefined);

export const AuthProvider = ({ children }: any) => {
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [user, setUser] = useState<any>(null);
    const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

    const login = async (data: any) => {
        try {
            setIsLoading(true);
            const res = await axiosInstance.post("/auth/login", data);
            if (res.status === 200 && res.data.token) {
                localStorage.setItem("__auth", res.data.token);
                await getUserByToken(); // fetch and set user
                setIsAuthenticated(true);
            }
        } catch (error: any) {
            console.error("Login failed", error);
            throw new Error(error);
        } finally {
            setIsLoading(false);
        }
    };

    const getUserByToken = async () => {
        try {
            setIsLoading(true);
            const res = await axiosInstance.get("/auth/user/token");
            if (res?.status === 200) {
                setUser(res.data);
                setIsAuthenticated(true);
            } else {
                setUser(null);
                setIsAuthenticated(false);
            }
        } catch (error) {
            console.error("Fetching user failed", error);
            setUser(null);
            setIsAuthenticated(false);
        } finally {
            setIsLoading(false);
        }
    };

    const logout = () => {
        try {
            localStorage.removeItem("__auth");
            setUser(null);
            setIsAuthenticated(false);
        } catch (error) {
            console.error("Logout failed", error);
        }
    };

    useEffect(() => {
        getUserByToken();
    }, []);

    return (
        <AuthContext.Provider value={{
            isLoading,
            user,
            isAuthenticated,
            login,
            logout,
        }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
};
