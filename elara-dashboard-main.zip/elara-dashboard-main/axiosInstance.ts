import axios from "axios";

export const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_RUNTIME === 'production' 
    ? "https://elara.interactweb.agency/api/v1/admin" 
    : "http://localhost:8080/api",
  // withCredentials: true,
});

axiosInstance.interceptors.request.use(
  (config:any) => {
    const token = localStorage.getItem("__auth"); // or get it from another source
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error:any) => {
    return Promise.reject(error);
  }
);
